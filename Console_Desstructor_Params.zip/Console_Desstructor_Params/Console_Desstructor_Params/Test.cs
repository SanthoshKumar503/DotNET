﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Desstructor_Params
{
    class Test
    {
        public Test()
        {
            Console.WriteLine("Test class constructor called");
        }
        ~Test()
        {
            Console.WriteLine("Test class destructor called");
        }
    }
}
