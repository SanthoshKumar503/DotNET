﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Desstructor_Params
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 10, 20, 30 };
            Test2 t = new Test2();
            t.Call(20,30,40,50);
            /*
            for (int i = 0; i < 5; i++)
            {
                Test t1 = new Test();
                if(i==2)
                {
                    GC.SuppressFinalize(t1);
                }
                t1 = null;
            }
            GC.Collect();
            */
            Console.ReadLine();
        }
    }
}
