﻿namespace Win_Customer_Validation
{
    partial class frm_home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_home = new System.Windows.Forms.Label();
            this.lbl_nametag = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_home
            // 
            this.lbl_home.AutoSize = true;
            this.lbl_home.Location = new System.Drawing.Point(404, 126);
            this.lbl_home.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lbl_home.Name = "lbl_home";
            this.lbl_home.Size = new System.Drawing.Size(329, 32);
            this.lbl_home.TabIndex = 0;
            this.lbl_home.Text = "Welcome to Homepage";
            // 
            // lbl_nametag
            // 
            this.lbl_nametag.AutoSize = true;
            this.lbl_nametag.Location = new System.Drawing.Point(525, 252);
            this.lbl_nametag.Name = "lbl_nametag";
            this.lbl_nametag.Size = new System.Drawing.Size(0, 32);
            this.lbl_nametag.TabIndex = 1;
            // 
            // frm_home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1290, 850);
            this.Controls.Add(this.lbl_nametag);
            this.Controls.Add(this.lbl_home);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "frm_home";
            this.Text = "frm_home";
            this.Load += new System.EventHandler(this.frm_home_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_home;
        private System.Windows.Forms.Label lbl_nametag;
    }
}