﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day1_Words_String_prgm4
{
    class Program
    {
        static void Main(string[] args)
        {
            int count=0;
            Console.WriteLine("Enter the sentence");
            string str = Console.ReadLine();
            char[] ch = str.ToCharArray();
            for(int i=0;i<ch.Length;i++)
            {
                if(ch[i]==' ')
                {
                    count++;
                }
            }
            count = count + 1;
            Console.WriteLine("Number of word is:"+count);
            Console.ReadLine();
        }
    }
}
