﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Threading;

namespace Console_Mutex_Semaphore
{
    class Program
    {
        static void Main(string[] args)
        {
            bool status;
            Mutex m = new Mutex(false, "abc", out status);
            Semaphore sm = new Semaphore(2, 2);

            Console.WriteLine("Is it new Mutex");

            Task t1 = Task.Run(() =>
            {
                //m.WaitOne();
                sm.WaitOne();
                Console.WriteLine("Task1 started");
                Thread.Sleep(10000);
                Console.WriteLine("Task1 completed");
                //m.ReleaseMutex();
                sm.Release();
            });

            Task t2 = Task.Run(() =>
            {
                //m.WaitOne();
                sm.WaitOne();
                Console.WriteLine("Task2 started");
                Thread.Sleep(10000);
                Console.WriteLine("Task2 completed");
                //m.ReleaseMutex();
                sm.Release();
            });

            Task t3 = Task.Run(() =>
            {
                //m.WaitOne();
                sm.WaitOne();
                Console.WriteLine("Task3 started");
                Thread.Sleep(10000);
                Console.WriteLine("Task3 completed");
                //m.ReleaseMutex();
                sm.Release();
            });

            Console.ReadLine();
            
        }
    }
}
