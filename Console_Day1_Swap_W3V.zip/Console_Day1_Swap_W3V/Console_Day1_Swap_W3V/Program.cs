﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day1_Swap_W3V
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the first number");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the second number");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Before swapping of first number:" + a);
            Console.WriteLine("Before swapping of second number:" + b);
            a = a + b;
            b = a - b;
            a = a - b;
            Console.WriteLine("After swapping of first number:" + a);
            Console.WriteLine("After swapping of second number:" + b);
            Console.ReadLine();
        }
    }
}
