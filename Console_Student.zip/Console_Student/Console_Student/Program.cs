﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Student
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Student ID");
            int id=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Student Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Student Department");
            string dept = Console.ReadLine();
            Console.WriteLine("Enter Student Marks");
            int marks = Convert.ToInt32(Console.ReadLine());

            Student s = new Student(id, name, dept, marks);

            Console.WriteLine("Enter Updated Student Marks");
            int marks1 = Convert.ToInt32(Console.ReadLine());

            bool status=s.UpdateMarks(marks1);
            if(status==true)
            {
                Console.WriteLine("Marks UpDated");
            }
            else
            {
                Console.WriteLine("Invalid Marks");
            }

            int mr=s.GetMarks();
            Console.WriteLine("Updated Marks is:" + mr);

            s.GetDetails();

            Console.ReadLine();
        }
    }
}
