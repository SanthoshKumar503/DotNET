﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Student
{
    class Student
    {
        private int StudentId;
        private string StudentName;
        private string StudentDept;
        private int StudentMarks;
        public Student(int StudentId,string StudentName,string StudentDept,int StudentMarks)
        {
            this.StudentId = StudentId;
            this.StudentName = StudentName;
            this.StudentDept = StudentDept;
            this.StudentMarks = StudentMarks;
        }
        public bool UpdateMarks(int NewMarks)
        {
            if(NewMarks>=0 && NewMarks<=100)
            {
                this.StudentMarks = NewMarks;
                return true;
            }
            else
            {
                return false;
            }
        }
        public int GetMarks()
        {
            return this.StudentMarks;
        }
        public void GetDetails()
        {
            Console.WriteLine("Student Id:"+StudentId);
            Console.WriteLine("Student Name:"+StudentName);
            Console.WriteLine("Student Department:"+StudentDept);
            Console.WriteLine("Student Marks:" + StudentMarks);
        }
    }
}
