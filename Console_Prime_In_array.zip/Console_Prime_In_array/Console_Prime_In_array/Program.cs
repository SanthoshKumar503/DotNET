﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Prime_In_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[5];
            Console.WriteLine("Enter the array elements");
            for (int i=0;i<arr.Length;i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("Array elements are");
            foreach (int k in arr)
            {
                Console.Write(" "+k);
            }
            Console.WriteLine();
            Console.WriteLine("Prime number are");
            for (int j = 0; j < arr.Length; j++)
            {
                int c = 0;
                int num = arr[j];
                for (int i = 1; i < num; i++)
                {
                    if (num % i == 0)
                    {
                        c++;
                    }
                }
                if (c == 1)
                {
                    Console.Write(" "+num);
                }

            }
            Console.ReadLine();
        }
    }
}
