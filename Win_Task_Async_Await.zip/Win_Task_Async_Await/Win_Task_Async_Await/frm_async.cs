﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Task_Async_Await
{
    public partial class frm_async : Form
    {
        public frm_async()
        {
            InitializeComponent();
        }

        private async void btn_task_Click(object sender, EventArgs e)
        {
            TestDAL dal = new TestDAL();
            Task<int> t=dal.GetSumAsync(10, 20);

            MessageBox.Show("Other Work");

            int r = await t;
            MessageBox.Show(r.ToString());
        }

        private void btn_main_Click(object sender, EventArgs e)
        {
            MessageBox.Show("My other work");
        }
    }
}
