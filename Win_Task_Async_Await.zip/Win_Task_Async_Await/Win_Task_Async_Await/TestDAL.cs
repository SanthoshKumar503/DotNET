﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Task_Async_Await
{
    class TestDAL
    {
        public Task<int> GetSumAsync(int n1,int n2)
        {
            Task<int> t = Task.Run(() =>
            {
                int total = n1 + n2;
                System.Threading.Thread.Sleep(2000);
                return total;

            });
            return t;
        }
    }
}
