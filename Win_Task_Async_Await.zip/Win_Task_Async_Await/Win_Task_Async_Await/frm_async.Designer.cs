﻿namespace Win_Task_Async_Await
{
    partial class frm_async
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_task = new System.Windows.Forms.Button();
            this.btn_main = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_task
            // 
            this.btn_task.Location = new System.Drawing.Point(268, 104);
            this.btn_task.Name = "btn_task";
            this.btn_task.Size = new System.Drawing.Size(220, 84);
            this.btn_task.TabIndex = 0;
            this.btn_task.Text = "Task";
            this.btn_task.UseVisualStyleBackColor = true;
            this.btn_task.Click += new System.EventHandler(this.btn_task_Click);
            // 
            // btn_main
            // 
            this.btn_main.Location = new System.Drawing.Point(268, 256);
            this.btn_main.Name = "btn_main";
            this.btn_main.Size = new System.Drawing.Size(220, 57);
            this.btn_main.TabIndex = 1;
            this.btn_main.Text = "Main";
            this.btn_main.UseVisualStyleBackColor = true;
            this.btn_main.Click += new System.EventHandler(this.btn_main_Click);
            // 
            // frm_async
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(694, 418);
            this.Controls.Add(this.btn_main);
            this.Controls.Add(this.btn_task);
            this.Name = "frm_async";
            this.Text = "frm_async";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_task;
        private System.Windows.Forms.Button btn_main;
    }
}