﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Anagram_P19
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the string1");
            string s1 = Console.ReadLine();
            Console.WriteLine("Enter the string2");
            string s2 = Console.ReadLine();
            int count = 0;
            int c1=0,c2=0;
            int count2=s1.Length;
            if (s1.Length == s2.Length)
            {
                for (int i = 0; i < s1.Length; i++)
                {
                    c1 = 0;
                    c2 = 0;
                    for (int a=0;a<s1.Length;a++)
                    {                        
                        if(s1[i]==s1[a])
                        {
                            c1++;
                        }
                    }
                    for (int j = 0; j < s2.Length; j++)
                    {
                        if(s1[i]==s2[j])
                        {
                            c2++;
                        }
                        
                    }
                    if(c1==c2)
                    {
                        count++;
                    }
                }
                if(count==count2)
                {
                    Console.WriteLine("Anagram");
                }
                else
                {
                    Console.WriteLine("Not an anagram");
                }
            }
            else
            {
                Console.WriteLine("Not an anagram");
            }
            Console.ReadLine();
        }
    }
}
