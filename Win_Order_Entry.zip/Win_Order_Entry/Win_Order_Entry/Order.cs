﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Order_Entry
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private string ItemName;
        private int ItemPrice;
        private int ItemQuantity;
        private string OrderCity;
        private string PaymentType;
        private static int count = 1000;
        public Order(string CustomerName,string ItemName,
            int ItemPrice,int ItemQuantity,string OrderCity,string PaymentType)
        {
            this.OrderID = ++Order.count;
            this.CustomerName = CustomerName;
            this.ItemName = ItemName;
            this.ItemPrice = ItemPrice;
            this.ItemQuantity = ItemQuantity;
            this.OrderCity = OrderCity;
            this.PaymentType = PaymentType;
        }
        public int GetOrderValue(int price,int quantity)
        {
            return price * quantity;
        }
    }
}
