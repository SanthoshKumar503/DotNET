﻿namespace Win_Order_Entry
{
    partial class frm_order
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_cname = new System.Windows.Forms.Label();
            this.txt_cname = new System.Windows.Forms.TextBox();
            this.cmb_items = new System.Windows.Forms.ComboBox();
            this.txt_price = new System.Windows.Forms.TextBox();
            this.lbl_price = new System.Windows.Forms.Label();
            this.cmb_quantity = new System.Windows.Forms.ComboBox();
            this.lbl_quantity = new System.Windows.Forms.Label();
            this.lbl_itemname = new System.Windows.Forms.Label();
            this.cmb_city = new System.Windows.Forms.ComboBox();
            this.lbl_city = new System.Windows.Forms.Label();
            this.lbl_pay = new System.Windows.Forms.Label();
            this.rdb_cod = new System.Windows.Forms.RadioButton();
            this.rdb_net = new System.Windows.Forms.RadioButton();
            this.rdb_debit = new System.Windows.Forms.RadioButton();
            this.btn_place = new System.Windows.Forms.Button();
            this.lbl_total = new System.Windows.Forms.Label();
            this.txt_total = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_cname
            // 
            this.lbl_cname.AutoSize = true;
            this.lbl_cname.Location = new System.Drawing.Point(126, 59);
            this.lbl_cname.Name = "lbl_cname";
            this.lbl_cname.Size = new System.Drawing.Size(132, 20);
            this.lbl_cname.TabIndex = 0;
            this.lbl_cname.Text = "Customer Name :";
            // 
            // txt_cname
            // 
            this.txt_cname.Location = new System.Drawing.Point(265, 59);
            this.txt_cname.Name = "txt_cname";
            this.txt_cname.Size = new System.Drawing.Size(297, 26);
            this.txt_cname.TabIndex = 1;
            // 
            // cmb_items
            // 
            this.cmb_items.FormattingEnabled = true;
            this.cmb_items.Location = new System.Drawing.Point(265, 114);
            this.cmb_items.Name = "cmb_items";
            this.cmb_items.Size = new System.Drawing.Size(297, 28);
            this.cmb_items.TabIndex = 2;
            this.cmb_items.SelectedIndexChanged += new System.EventHandler(this.cmb_items_SelectedIndexChanged);
            // 
            // txt_price
            // 
            this.txt_price.Location = new System.Drawing.Point(265, 165);
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(297, 26);
            this.txt_price.TabIndex = 3;
            // 
            // lbl_price
            // 
            this.lbl_price.AutoSize = true;
            this.lbl_price.Location = new System.Drawing.Point(126, 171);
            this.lbl_price.Name = "lbl_price";
            this.lbl_price.Size = new System.Drawing.Size(88, 20);
            this.lbl_price.TabIndex = 4;
            this.lbl_price.Text = "Item Price :";
            // 
            // cmb_quantity
            // 
            this.cmb_quantity.FormattingEnabled = true;
            this.cmb_quantity.Location = new System.Drawing.Point(265, 221);
            this.cmb_quantity.Name = "cmb_quantity";
            this.cmb_quantity.Size = new System.Drawing.Size(297, 28);
            this.cmb_quantity.TabIndex = 5;
            // 
            // lbl_quantity
            // 
            this.lbl_quantity.AutoSize = true;
            this.lbl_quantity.Location = new System.Drawing.Point(130, 228);
            this.lbl_quantity.Name = "lbl_quantity";
            this.lbl_quantity.Size = new System.Drawing.Size(112, 20);
            this.lbl_quantity.TabIndex = 7;
            this.lbl_quantity.Text = "Item Quantity :";
            // 
            // lbl_itemname
            // 
            this.lbl_itemname.AutoSize = true;
            this.lbl_itemname.Location = new System.Drawing.Point(130, 121);
            this.lbl_itemname.Name = "lbl_itemname";
            this.lbl_itemname.Size = new System.Drawing.Size(95, 20);
            this.lbl_itemname.TabIndex = 8;
            this.lbl_itemname.Text = "Item Name :";
            // 
            // cmb_city
            // 
            this.cmb_city.FormattingEnabled = true;
            this.cmb_city.Location = new System.Drawing.Point(265, 270);
            this.cmb_city.Name = "cmb_city";
            this.cmb_city.Size = new System.Drawing.Size(297, 28);
            this.cmb_city.TabIndex = 9;
            // 
            // lbl_city
            // 
            this.lbl_city.AutoSize = true;
            this.lbl_city.Location = new System.Drawing.Point(134, 277);
            this.lbl_city.Name = "lbl_city";
            this.lbl_city.Size = new System.Drawing.Size(79, 20);
            this.lbl_city.TabIndex = 10;
            this.lbl_city.Text = "Order City";
            // 
            // lbl_pay
            // 
            this.lbl_pay.AutoSize = true;
            this.lbl_pay.Location = new System.Drawing.Point(138, 326);
            this.lbl_pay.Name = "lbl_pay";
            this.lbl_pay.Size = new System.Drawing.Size(138, 20);
            this.lbl_pay.TabIndex = 11;
            this.lbl_pay.Text = "Payment Options :";
            // 
            // rdb_cod
            // 
            this.rdb_cod.AutoSize = true;
            this.rdb_cod.Location = new System.Drawing.Point(265, 363);
            this.rdb_cod.Name = "rdb_cod";
            this.rdb_cod.Size = new System.Drawing.Size(149, 24);
            this.rdb_cod.TabIndex = 12;
            this.rdb_cod.TabStop = true;
            this.rdb_cod.Text = "Cash On Deliviry";
            this.rdb_cod.UseVisualStyleBackColor = true;
            // 
            // rdb_net
            // 
            this.rdb_net.AutoSize = true;
            this.rdb_net.Location = new System.Drawing.Point(265, 409);
            this.rdb_net.Name = "rdb_net";
            this.rdb_net.Size = new System.Drawing.Size(121, 24);
            this.rdb_net.TabIndex = 13;
            this.rdb_net.TabStop = true;
            this.rdb_net.Text = "Net Banking";
            this.rdb_net.UseVisualStyleBackColor = true;
            // 
            // rdb_debit
            // 
            this.rdb_debit.AutoSize = true;
            this.rdb_debit.Location = new System.Drawing.Point(265, 449);
            this.rdb_debit.Name = "rdb_debit";
            this.rdb_debit.Size = new System.Drawing.Size(110, 24);
            this.rdb_debit.TabIndex = 14;
            this.rdb_debit.TabStop = true;
            this.rdb_debit.Text = "Debit Card";
            this.rdb_debit.UseVisualStyleBackColor = true;
            // 
            // btn_place
            // 
            this.btn_place.Location = new System.Drawing.Point(338, 518);
            this.btn_place.Name = "btn_place";
            this.btn_place.Size = new System.Drawing.Size(146, 45);
            this.btn_place.TabIndex = 15;
            this.btn_place.Text = "Place Order";
            this.btn_place.UseVisualStyleBackColor = true;
            this.btn_place.Click += new System.EventHandler(this.btn_place_Click);
            // 
            // lbl_total
            // 
            this.lbl_total.AutoSize = true;
            this.lbl_total.Location = new System.Drawing.Point(142, 620);
            this.lbl_total.Name = "lbl_total";
            this.lbl_total.Size = new System.Drawing.Size(112, 20);
            this.lbl_total.TabIndex = 16;
            this.lbl_total.Text = "Total Amount :";
            // 
            // txt_total
            // 
            this.txt_total.Location = new System.Drawing.Point(265, 620);
            this.txt_total.Name = "txt_total";
            this.txt_total.Size = new System.Drawing.Size(202, 26);
            this.txt_total.TabIndex = 17;
            // 
            // frm_order
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1069, 689);
            this.Controls.Add(this.txt_total);
            this.Controls.Add(this.lbl_total);
            this.Controls.Add(this.btn_place);
            this.Controls.Add(this.rdb_debit);
            this.Controls.Add(this.rdb_net);
            this.Controls.Add(this.rdb_cod);
            this.Controls.Add(this.lbl_pay);
            this.Controls.Add(this.lbl_city);
            this.Controls.Add(this.cmb_city);
            this.Controls.Add(this.lbl_itemname);
            this.Controls.Add(this.lbl_quantity);
            this.Controls.Add(this.cmb_quantity);
            this.Controls.Add(this.lbl_price);
            this.Controls.Add(this.txt_price);
            this.Controls.Add(this.cmb_items);
            this.Controls.Add(this.txt_cname);
            this.Controls.Add(this.lbl_cname);
            this.Name = "frm_order";
            this.Text = "Orders";
            this.Load += new System.EventHandler(this.frm_order_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_cname;
        private System.Windows.Forms.TextBox txt_cname;
        private System.Windows.Forms.ComboBox cmb_items;
        private System.Windows.Forms.TextBox txt_price;
        private System.Windows.Forms.Label lbl_price;
        private System.Windows.Forms.ComboBox cmb_quantity;
        private System.Windows.Forms.Label lbl_quantity;
        private System.Windows.Forms.Label lbl_itemname;
        private System.Windows.Forms.ComboBox cmb_city;
        private System.Windows.Forms.Label lbl_city;
        private System.Windows.Forms.Label lbl_pay;
        private System.Windows.Forms.RadioButton rdb_cod;
        private System.Windows.Forms.RadioButton rdb_net;
        private System.Windows.Forms.RadioButton rdb_debit;
        private System.Windows.Forms.Button btn_place;
        private System.Windows.Forms.Label lbl_total;
        private System.Windows.Forms.TextBox txt_total;
    }
}