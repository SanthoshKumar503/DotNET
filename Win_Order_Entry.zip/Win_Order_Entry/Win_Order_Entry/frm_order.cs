﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Order_Entry
{
    public partial class frm_order : Form
    {
        int price;
        public frm_order()
        {
            InitializeComponent();
        }

        private void frm_order_Load(object sender, EventArgs e)
        {
            cmb_items.Items.Add("Mobile");
            cmb_items.Items.Add("LED Tv");
            cmb_items.Items.Add("Micro Oven");
            cmb_items.Items.Add("Washing Machine");

            cmb_quantity.Items.Add(1);
            cmb_quantity.Items.Add(2);
            cmb_quantity.Items.Add(3);
            cmb_quantity.Items.Add(4);

            cmb_city.Items.Add("Bangalore");
            cmb_city.Items.Add("Hyderabad");
            cmb_city.Items.Add("Pune");
            cmb_city.Items.Add("Chennai");
        }

        private void btn_place_Click(object sender, EventArgs e)
        {
            string name = string.Empty;
                name= txt_cname.Text;
            string iname = string.Empty;
                iname = cmb_items.Text;
            string iquant = string.Empty; 
                iquant = cmb_quantity.Text;
            string ocity = string.Empty;
                ocity= cmb_city.Text;
            bool cod = rdb_cod.Checked;
            bool net = rdb_net.Checked;
            bool debit = rdb_debit.Checked;
            string ptype = string.Empty;
                ptype=string.Empty;
            if (name == string.Empty)
            {
                MessageBox.Show("Enter customer name");
            }
            else if (iname == string.Empty)
            {
                MessageBox.Show("Select Item");
            }
            else if (iquant == string.Empty)
            {
                MessageBox.Show("Select Quantity");
            }
            else if (ocity == string.Empty)
            {
                MessageBox.Show("Select City");
            }
            else if (cod == false && net == false && debit == false)
            {
                MessageBox.Show("Select Payment Method");
            }
            else
            {
                if (cod == true)
                {
                    ptype = "COD";
                }
                else if (net == true)
                {
                    ptype = "Net Banking";
                }
                else
                {
                    ptype = "Debit card";
                }
                Order o = new Order(name, iname, price, Convert.ToInt32(iquant), ocity, ptype);
                int total = o.GetOrderValue(price, Convert.ToInt32(iquant));
                txt_total.Text = total.ToString();
            }     

                  
        }

        private void cmb_items_SelectedIndexChanged(object sender, EventArgs e)
        {
            string iname = cmb_items.Text;
            if (iname == "Mobile")
            {
                price = 15000;
                txt_price.Text = price.ToString();

            }
            else if (iname == "LED Tv")
            {
                price = 50000;
                txt_price.Text = price.ToString();
            }
            else if (iname == "Micro Oven")
            {
                price=1000;
                txt_price.Text = price.ToString();
            }
            else if (iname == "Washing Machine")
            {
                price = 30000;
                txt_price.Text = price.ToString();
            }

        }
    }
}
