﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_DP
{
    class Product
    {
        private int ProductId;
        private string ProductName;
        private int ProductPrice;
        private static int count;
        public Product(string ProductName,int ProductPrice)
        {
            this.ProductName = ProductName;
            this.ProductPrice = ProductPrice;
            this.ProductId = ++Product.count;
        }
        public int PProductId
        {
            get
            {
                return this.ProductId;
            }
        }
        public string PProductName
        {
            get
            {
                return this.ProductName;
            }
        }
        public int PProductPrice
        {
            get
            {
                return this.ProductPrice;
            }
        }

    }
}
