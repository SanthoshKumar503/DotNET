﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_DP
{
    class Program
    {
        static void Main(string[] args)
        {
            Manager m1 = Manager.GetManager();
            Manager m2 = Manager.GetManager();

            Console.WriteLine("Manager Id:" + m1.PManagerId);
            Console.WriteLine("Manager Name:" + m1.PManagerName);

            Console.WriteLine("Manager ID:" + m2.PManagerId);
            Console.WriteLine("Manager Name:" + m2.PManagerName);

            if(m1==m2)
            {
                Console.WriteLine("SingleTon");
            }
            else
            {
                Console.WriteLine("Not a SingleTon");
            }
            /*
            ProductFactory factory = new ProductFactory();

            Product p = factory.GetProduct();
            Console.WriteLine("Product Id:" + p.PProductId);
            Console.WriteLine("Product Name:" + p.PProductName);
            Console.WriteLine("Product Price:" + p.PProductPrice);

            Product p2=factory.RepairProduct(p);
            if(p==p2)
            {
                Console.WriteLine("Same product");
            }
            else
            {
                Console.WriteLine("Different Product");
            }
            */
            Console.ReadLine();
        }
    }
}
