﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_DP
{
    class ProductFactory
    {
        public Product GetProduct()
        {
            Product p = new Product("OnePlus Mobile", 20000);
            return p;
        }
        public Product RepairProduct(Product p)
        {
            Console.WriteLine("Product repaired");
            Product obj = new Product("OnePlus",20000);
            return obj;
        }
    }
}
