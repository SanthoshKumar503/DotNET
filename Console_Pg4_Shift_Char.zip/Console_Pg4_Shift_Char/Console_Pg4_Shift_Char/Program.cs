﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Pg4_Shift_Char
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter string");
            string str = Console.ReadLine();
            char[] ch = str.ToCharArray();
            for(int i=0;i<ch.Length;i++)
            {
                if (ch[i] == 'Z')
                {                    
                    ch[i] = (char)65;
                    Console.Write(ch[i]);
                }
                else if(ch[i]=='z')
                {
                    ch[i] = (char)97;
                    Console.Write(ch[i]);
                }
                else
                {
                    char c = ch[i];
                    int i3 = c;
                    i3++;
                    c = (char)i3;
                    Console.Write(c);
                }
            }
            Console.ReadLine();
        }
    }
}
