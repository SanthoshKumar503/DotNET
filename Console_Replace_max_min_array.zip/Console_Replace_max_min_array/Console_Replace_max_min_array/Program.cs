﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Replace_max_min_array
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Swapping max and min value");
            int[] arr = { 22, 1, 23, 99, 77 };
            Console.WriteLine("Before Swap");
            for (int a = 0; a < arr.Length; a++)
            {
                Console.WriteLine(arr[a]);
            }
            int maxind=0,max=arr[0];
            int minind=0,min=arr[0];
            for(int i=0;i<arr.Length;i++)
            {
                if(arr[i]>max)
                {
                    max = arr[i];
                    maxind = i;
                }
            }
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] < min)
                {
                    min = arr[i];
                    minind = i;
                }
            }
            int temp = arr[maxind];
            arr[maxind] = arr[minind];
            arr[minind] = temp;
            Console.WriteLine("After Swap");
            for (int a = 0; a < arr.Length; a++)
            {
                Console.WriteLine(arr[a]);
            }
            Console.ReadLine();
        }
    }
}
