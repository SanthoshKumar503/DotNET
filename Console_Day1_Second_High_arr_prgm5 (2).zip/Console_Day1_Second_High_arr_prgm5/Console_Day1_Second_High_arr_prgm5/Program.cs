﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day1_Second_High_arr_prgm5
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 22, 1, 81, 99, 77 };            
            for (int a = 0; a < arr.Length; a++)
            {
                Console.WriteLine(arr[a]);
            }
            int max = arr[0];
            int min = arr[0];
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] > max)
                {
                    max = arr[i];
                }
            }
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i]<max && arr[i]>min)
                {
                    min = arr[i];
                }
            }
            
                Console.WriteLine("Second highest is:"+min);
            
            Console.ReadLine();
        }
    }
}
