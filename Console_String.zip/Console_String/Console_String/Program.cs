﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_String
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "pathfront";
            char[] array = str.ToCharArray();
            for(int i=0;i<array.Length;i++)
            {
                Console.WriteLine(array[i]);
                int a = Convert.ToInt32(array[i]);
                Console.WriteLine(a);
            }

            string str1 = new string(array);
            Console.WriteLine(str1);



            string s1 = "a";
            char[] c = { 'a' };
            Object obj = new string(c);
            Console.WriteLine(s1 == obj);
            Console.WriteLine(s1.Equals(obj));
            Console.ReadLine();
        }
    }
}
