﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Assignment
{
    class Fact
    {
        public static int Factorial(int num,int n1)
        {
            int n2=1;
            for(int i=1;i<=n1;i++)
            {
                n2 = n2+(i * num);
            }
            return n2;
        } 
    }
}
