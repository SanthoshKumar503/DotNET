﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Assignment
{
    class VehicleLoan : Loan
    {
        public VehicleLoan(string CustomerName, string CustomerEmailId, string MobileNo, int LoanAmount, int Duration, int Rate)
            :base(CustomerName,CustomerEmailId, MobileNo, LoanAmount, Duration, Rate)
        {
            Console.WriteLine("VehicleLoan constuctor");
        }
        private static int emi2;
        public override int PayEMI(int amt)
        {
            int n1 = (this.PLoanAmount * this.PRate * (1 + PRate));
            int n2 = Fact.Factorial(n1, this.PDuration);
            int n3 = Fact.Factorial(1 + this.PRate, PDuration - 1);
            emi2 = n2 / n3;
            return emi2;
        }

        public override int PendingLoan()
        {
            return this.PLoanAmount - emi2;
        }
    }
}
