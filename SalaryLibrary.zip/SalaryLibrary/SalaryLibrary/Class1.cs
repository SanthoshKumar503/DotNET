﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalaryLibrary
{
    public class Salarycls
    {
        public int GetSalry(int days,int per_day_salary)
        {
            return days * per_day_salary+5000;
        }
    }
}
