﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Find_Duplicate
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[5];
            Console.WriteLine("Enter the array elements");
            for(int i=0;i<arr.Length;i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Array.Sort(arr);
            Console.WriteLine("Duplicate array elements are");
            for(int i=0;i<arr.Length-1;i++)
            {
                int j = i + 1;
                if (arr[i] == arr[j])
                {
                    Console.Write(arr[i]+" ");
                    while (arr[i] == arr[j])
                    {
                        i = j;
                        j++;
                    }
                   
                }
            }
            Console.ReadLine();
        }
    }
}
