﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Pg3_Reverse_String
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the string");
            string str = Console.ReadLine();
            char[] ch = str.ToCharArray();
            char temp;
            for(int i=0;i<ch.Length/2;i++)
            {
                temp = ch[ch.Length - 1-i];
                ch[ch.Length - 1 - i] = ch[i];
                ch[i] = temp;
            }
            for(int c=0;c<ch.Length;c++)
            {
                Console.Write(ch[c]);
            }
            Console.ReadLine();
        }
    }
}
