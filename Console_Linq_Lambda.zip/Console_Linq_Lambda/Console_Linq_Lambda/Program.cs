﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Linq_Lambda
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Order o1 = new Order("BGL", 2000);
            Order o2 = new Order("chennai", 4000);
            Order o3 = new Order("ctr", 5000);
            Order o4 = new Order("tpt", 3000);

            List<Order> list = new List<Order>();
            list.Add(o1);
            list.Add(o2);
            list.Add(o3);
            list.Add(o4);
            int id = 1001;

            var obj = list.FirstOrDefault(o=>o1.OrderID == id);
            if(obj!=null)
            {
                Console.WriteLine(obj.OrderID + " " + obj.OrderCity + " " + obj.OrderAmt);
            }
            else
            {
                Console.WriteLine("Not found");
            }

            /*//lammda

            var data = list.Where(o => o.OrderAmt > 3000);
            foreach(Order m in data)
            {
                Console.WriteLine(m.OrderID + " " + m.OrderCity + " " + m.OrderAmt);
            }

            /*
            var obj = (from o in list
                       where o.OrderID == id
                       select o).FirstOrDefault();

            if(obj!=null)
            {
                Console.WriteLine(obj.OrderID + " " + obj.OrderCity + " " + obj.OrderAmt);
            }
            else
            {
                Console.WriteLine("Not found");
            }
            /*
            var data = (from o in list
                       where o.OrderAmt > 2000
                       select o).ToList();
            foreach(Order m in data)
            {
                Console.WriteLine(m.OrderID + " " + m.OrderCity + " " + m.OrderAmt);
            }
            */

            Console.ReadLine();
        }
    }
}
