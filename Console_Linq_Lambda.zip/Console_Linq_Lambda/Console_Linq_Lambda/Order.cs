﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Linq_Lambda
{
    class Order
    {
        public int OrderID { get; }
        public string OrderCity { get; set; }
        public int OrderAmt { get; set; }
        private static int count = 1000;
        public Order(string OrderCity,int OrderAmt)
        {
            this.OrderCity = OrderCity;
            this.OrderAmt = OrderAmt;
            this.OrderID = ++Order.count;
        }
    }
}
