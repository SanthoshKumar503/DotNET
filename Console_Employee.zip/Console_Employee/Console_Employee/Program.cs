﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Employee Id");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Employee Department");
            int dept= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee Salary");
            int sal= Convert.ToInt32(Console.ReadLine());

            Employee e = new Employee(id, name, dept, sal);
            Console.WriteLine("Enter Employee Updated Salary");
            int updSal=Convert.ToInt32(Console.ReadLine());
            bool status=e.UpdateSalary(updSal);
            if(status==true)
            {
                Console.WriteLine("Salary Updated");
            }
            else
            {
                Console.WriteLine("Salary update failed");
            }

            int res=e.GetSalary();
            Console.WriteLine("Employee Salary is:"+res);

            e.GetDetails();

            Console.ReadLine();
        }
    }
}
