﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Employee
{
    class Employee
    {
        private int EmployeeId;
        private string EmployeeName;
        private int EmployeeDept;
        private int EmployeeSal;
        public Employee(int EmployeeId,string EmployeeName,int EmployeeDept,int EmployeeSal)
        {
            this.EmployeeId = EmployeeId;
            this.EmployeeName = EmployeeName;
            this.EmployeeDept = EmployeeDept;
            this.EmployeeSal = EmployeeSal;
        }
        public bool UpdateSalary(int NewSal)
        {
            if(NewSal>0)
            {
                this.EmployeeSal = this.EmployeeSal + NewSal;
                return true;
            }
            else
            {
                return false;
            }
        }
        public int GetSalary()
        {
            return this.EmployeeSal;
        }
        public void GetDetails()
        {
            Console.WriteLine("Employee Id:" + this.EmployeeId);
            Console.WriteLine("Employee Name:" + this.EmployeeName);
            Console.WriteLine("Employee Department:" + this.EmployeeDept);
            Console.WriteLine("Employee Salary:" + this.EmployeeSal);
        }
    }
}
