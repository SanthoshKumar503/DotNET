﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_JaggedArray_enum_var_dynamic
{
    class Program
    {
        static void Main(string[] args)
        {
            PaymentTypes p = PaymentTypes.NetBanking;
            Console.WriteLine(p);
            int x = Convert.ToInt32(p);
            Console.WriteLine(x);
            /*
            int[][] jagged = new int[3][];
            jagged[0] = new int[2];
            jagged[1] = new int[3];
            jagged[2] = new int[2];

            jagged[0][0] = 20;
            jagged[0][1] = 25;

            jagged[1][0] = 22;
            jagged[1][1] = 76;
            jagged[1][2] = 40;

            jagged[2][0] = 55;
            jagged[2][1] = 60;

            int x = jagged[1][2];
            for (int i = 0; i < jagged.Length; i++)
            {
                int[] j = jagged[i];
                for (int c = 0; c < j.Length;c++)
                {
                    Console.WriteLine(j[c]);
                }
                Console.WriteLine("-------");
            }
            */

            Console.ReadLine();
        }
    }
}
