﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_JaggedArray_enum_var_dynamic
{
    class Account
    {
        private int AccountId;//0
        private int AccountBalance;//0
        private int? CustomerAge=null;//no-error
        private string CustomerName;//default null
    }
}
