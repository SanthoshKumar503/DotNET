﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_JaggedArray_enum_var_dynamic
{
    enum PaymentTypes
    {
        COD,NetBanking=4,CreditCard,DebitCare,CASH
    }
}
