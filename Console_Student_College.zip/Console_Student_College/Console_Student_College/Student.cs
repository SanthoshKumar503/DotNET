﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Student_College
{
    class Student
    {
        public delegate void del_leave(int stdid, string msg);
        public event del_leave evt_leave;
        private int StudentID;
        private string StudentName;
        private string StudentCity;
        private static int count = 0;
        public Student(string StudentName,string StudentCity)
        {
            this.StudentName = StudentName;
            this.StudentCity = StudentCity;
            this.StudentID = ++Student.count;

        }
        public int PStudentID
        {
            get
            {
                return this.StudentID;
            }
        }
        public string PStudentName
        {
            get
            {
                return this.StudentName;
            }
            set
            {
                this.StudentName = value;
            }
        }
        public string PStudentCity
        {
            get
            {
                return this.StudentCity;
            }
            set
            {
                this.StudentCity = value;
            }
        }
        public override string ToString()
        {
            return this.PStudentID + ", " + this.PStudentName + ", " + this.PStudentCity;
        }
        public void RequestLeave(string reason)
        {
            Console.WriteLine("Student ID:" + this.StudentID + ", " + "Request of leave:" + reason);
            if (this.evt_leave != null)
            {
                this.evt_leave(this.PStudentID, reason);
            }
        }

    }
}
