﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Student_College
{
    class College
    {
        public void leavenotify(int sid,string msg)
        {
            Console.WriteLine("College : student leave, Id:" + sid + " reason:" + msg);
        }
        private List<Student> list = new List<Student>();
        private int CollegeID;
        private string CollegeName;
        public College(int CollegeID,string CollegeName)
        {
            this.CollegeID = CollegeID;
            this.CollegeName = CollegeName;
        }
        public void AddStudent(Student obj)
        {
            list.Add(obj);
            obj.evt_leave += new Student.del_leave(this.leavenotify);
        }
        public int StudentCount()
        {
            return list.Count;
        }
        public void ShowAllStudents()
        {
            foreach(Student s in list)
            {
                Console.WriteLine(s.ToString());
            }
        }
        public int GetStudentCount()
        {
            return list.Count;
        }
        public Student Find(int id)
        {
            foreach(Student se in list)
            {
                if(se.PStudentID==id)
                {
                    return se;
                }
            }
            return null;
        }
        public bool Remove(int id)
        {
            foreach(Student s in list)
            {
                if(s.PStudentID==id)
                {
                    list.Remove(s);
                    return true;
                }
            }
            return false;
        }
    }
}
