﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Student_College
{
    class Program
    {
        static void Main(string[] args)
        {
            College c = new College(1001, "Pathfront");
            bool flag = true;
            while(flag)
            {
                Console.WriteLine("Add-1,Show-2,Find-3,Count-4,Remove-5,Leave-6,Exit-7");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch(opt)
                {
                    case 1:
                        {
                            Console.WriteLine("Enter student name:");
                            string name=Console.ReadLine();
                            Console.WriteLine("Enter student city");
                            string city = Console.ReadLine();
                            Student s = new Student(name, city);
                            c.AddStudent(s);
                            Console.WriteLine("Student Added and ID:" + s.PStudentID);
                            break;
                        }
                    case 2:
                        {
                            c.ShowAllStudents();
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("Enter the student id:");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Student s = c.Find(id);
                            if(s!=null)
                            {
                                Console.WriteLine(s.ToString());
                            }
                            else
                            {
                                Console.WriteLine("Student not found");
                            }
                            break;
                        }
                    case 4:
                        {
                            int total = c.GetStudentCount();
                            Console.WriteLine("Student total:" + total);
                            break;
                        }
                    case 5:
                        {
                            Console.WriteLine("Enter the student ID:");
                            int id = Convert.ToInt32(Console.ReadLine());
                            bool status = c.Remove(id);
                            if(status==true)
                            {
                                Console.WriteLine("Student removed");
                            }
                            else
                            {
                                Console.WriteLine("Not found");
                            }
                            break;
                        }
                    case 6:
                        {
                            Console.WriteLine("Enter the student ID");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Student s = c.Find(id);
                            if (s != null)
                            {
                                Console.WriteLine("Enter the leave reason");
                                string r = Console.ReadLine();
                                s.RequestLeave(r);
                            }
                            else
                            {
                                Console.WriteLine("Student not found");
                            }
                            break;
                        }
                    case 7:
                        {
                            flag = false;
                            break;
                        }
                }
            }
            Console.ReadLine();
        }
    }
}
