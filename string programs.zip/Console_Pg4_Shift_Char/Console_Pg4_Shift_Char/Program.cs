﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Pg4_Shift_Char
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter string");
            string str = Console.ReadLine();
            char[] ch = str.ToCharArray();
            for(int i=0;i<ch.Length;i++)
            {
                char c = ch[i];
                int i2 = c;
                i2++;
                c = (char)i2;
                Console.Write(c);
            }
            Console.ReadLine();
        }
    }
}
