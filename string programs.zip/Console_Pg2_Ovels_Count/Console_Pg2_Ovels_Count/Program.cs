﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Pg2_Ovels_Count
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Text");
            string str = Console.ReadLine();
            char[] ch = str.ToCharArray();
            int count = 0;
            for(int i=0;i<ch.Length;i++)
            {
                if(ch[i]=='a' || ch[i] == 'e' || ch[i] == 'i' || ch[i] == 'o' || ch[i] == 'u' ||
                    ch[i] == 'A' || ch[i] == 'E' || ch[i] == 'I' || ch[i] == 'O' || ch[i] == 'U' )
                {
                    count++;
                }
            }
            Console.WriteLine("Number of ovels is:" + count);
            Console.ReadLine();
        }
    }
}
