﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Threads_Lock_ThreadPool
{
    public partial class frm_async_await : Form
    {
        public frm_async_await()
        {
            InitializeComponent();
        }
        Calculator obj = new Calculator();
        private async void btn_add_Click(object sender, EventArgs e)
        {
            double d1 = Convert.ToDouble(txt_num1.Text);
            double d2 = Convert.ToDouble(txt_num2.Text);
            var t = obj.GetCalAsync(d1, d2, OperationType.SUM);
            double r = await t;
            lst_result.Items.Add("Addition:" + r);
        }

        private async void btn_sub_Click(object sender, EventArgs e)
        {
            double d1 = Convert.ToDouble(txt_num1.Text);
            double d2 = Convert.ToDouble(txt_num2.Text);
            var t = obj.GetCalAsync(d1, d2, OperationType.SUB);
            double r = await t;
            lst_result.Items.Add("Subtraction:"+r);
        }

        private async void btn_mul_Click(object sender, EventArgs e)
        {
            double d1 = Convert.ToDouble(txt_num1.Text);
            double d2 = Convert.ToDouble(txt_num2.Text);
            var t = obj.GetCalAsync(d1, d2, OperationType.MUL);
            double r = await t;
            lst_result.Items.Add("Multiplication:"+r);
        }

        private async void btn_div_Click(object sender, EventArgs e)
        {
            double d1 = Convert.ToInt64(txt_num1.Text);
            double d2 = Convert.ToDouble(txt_num2.Text);
            var t = obj.GetCalAsync(d1, d2, OperationType.DIV);
            double r = await t;
            lst_result.Items.Add("Division:"+r);
        }
    }
}
