﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Threading;

namespace Win_Threads_Lock_ThreadPool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int total;
        public void getsum()
        {
            if (Monitor.TryEnter(this,8000))
            {
                //Monitor.Enter(this);//function base
                // lock(this)   //synchronization
                // {
                int n1 = Convert.ToInt32(txt_th1.Text);
                int n2 = Convert.ToInt32(txt_th2.Text);
                total = n1 + n2;
                Thread.Sleep(5000);
                MessageBox.Show("Total:" + total);
                // }
                Monitor.Exit(this);
            }
            else
            {
                MessageBox.Show("I will try later");
            }
          
        }
        private void btn_th1_Click(object sender, EventArgs e)
        {
            Thread th1 = new Thread(this.getsum);
            th1.Start();
        }

        private void btn_th2_Click(object sender, EventArgs e)
        {
            Thread th2 = new Thread(this.getsum);
            th2.Start();
        }
    }
}
