﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Threads_Lock_ThreadPool
{
    class Calculator
    {
        //use in win_task_async
        public Task<double> GetCalAsync(double d1,double d2,OperationType opt)
        {
            Task<double> t = Task.Run(()=> {
                System.Threading.Thread.Sleep(5000);
                if(opt==OperationType.SUM)
                {
                    return d1 + d2;
                }
                if(opt==OperationType.SUB)
                {
                    return d1 - d2;
                }
                if(opt==OperationType.MUL)
                {
                    return d1 * d2;
                }
                if(opt==OperationType.DIV)
                {
                    return d1 / d2;
                }
                else
                {
                    return 0;
                }
            });
            return t;
        }
    }
    enum OperationType
    {
        SUM,SUB,DIV,MUL
    }
}
