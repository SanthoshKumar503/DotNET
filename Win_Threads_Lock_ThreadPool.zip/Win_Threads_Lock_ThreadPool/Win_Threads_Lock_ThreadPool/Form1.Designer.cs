﻿namespace Win_Threads_Lock_ThreadPool
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_th1 = new System.Windows.Forms.Label();
            this.lbl_th2 = new System.Windows.Forms.Label();
            this.txt_th1 = new System.Windows.Forms.TextBox();
            this.txt_th2 = new System.Windows.Forms.TextBox();
            this.btn_th1 = new System.Windows.Forms.Button();
            this.btn_th2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_th1
            // 
            this.lbl_th1.AutoSize = true;
            this.lbl_th1.Location = new System.Drawing.Point(130, 107);
            this.lbl_th1.Name = "lbl_th1";
            this.lbl_th1.Size = new System.Drawing.Size(76, 20);
            this.lbl_th1.TabIndex = 0;
            this.lbl_th1.Text = "Thread 1:";
            // 
            // lbl_th2
            // 
            this.lbl_th2.AutoSize = true;
            this.lbl_th2.Location = new System.Drawing.Point(130, 205);
            this.lbl_th2.Name = "lbl_th2";
            this.lbl_th2.Size = new System.Drawing.Size(76, 20);
            this.lbl_th2.TabIndex = 1;
            this.lbl_th2.Text = "Thread 2:";
            // 
            // txt_th1
            // 
            this.txt_th1.Location = new System.Drawing.Point(268, 101);
            this.txt_th1.Name = "txt_th1";
            this.txt_th1.Size = new System.Drawing.Size(249, 26);
            this.txt_th1.TabIndex = 2;
            // 
            // txt_th2
            // 
            this.txt_th2.Location = new System.Drawing.Point(268, 199);
            this.txt_th2.Name = "txt_th2";
            this.txt_th2.Size = new System.Drawing.Size(249, 26);
            this.txt_th2.TabIndex = 3;
            // 
            // btn_th1
            // 
            this.btn_th1.Location = new System.Drawing.Point(149, 293);
            this.btn_th1.Name = "btn_th1";
            this.btn_th1.Size = new System.Drawing.Size(178, 41);
            this.btn_th1.TabIndex = 4;
            this.btn_th1.Text = "Thread 1";
            this.btn_th1.UseVisualStyleBackColor = true;
            this.btn_th1.Click += new System.EventHandler(this.btn_th1_Click);
            // 
            // btn_th2
            // 
            this.btn_th2.Location = new System.Drawing.Point(378, 293);
            this.btn_th2.Name = "btn_th2";
            this.btn_th2.Size = new System.Drawing.Size(178, 41);
            this.btn_th2.TabIndex = 5;
            this.btn_th2.Text = "Thread 2";
            this.btn_th2.UseVisualStyleBackColor = true;
            this.btn_th2.Click += new System.EventHandler(this.btn_th2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(741, 434);
            this.Controls.Add(this.btn_th2);
            this.Controls.Add(this.btn_th1);
            this.Controls.Add(this.txt_th2);
            this.Controls.Add(this.txt_th1);
            this.Controls.Add(this.lbl_th2);
            this.Controls.Add(this.lbl_th1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_th1;
        private System.Windows.Forms.Label lbl_th2;
        private System.Windows.Forms.TextBox txt_th1;
        private System.Windows.Forms.TextBox txt_th2;
        private System.Windows.Forms.Button btn_th1;
        private System.Windows.Forms.Button btn_th2;
    }
}

