﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleInterface_Assignment
{
    class ProductBook : ICourierProduct
    {
        int PBID;
        string AuthorName;
        string PBTitle;
        int PBPrice;
        int PBPages;


        public ProductBook(int PBID,string AuthorName,string PBTitle,int PBPrice,int PBPages)
        {
            this.PBID = PBID;
            this.AuthorName = AuthorName;
            this.PBTitle = PBTitle;
            this.PBPrice = PBPrice;
            this.PBPages = PBPages;
        }

        public void GetFromAddress()
        {
            Console.WriteLine("From Japan");
        }

        public void GetToAddress()
        {
            Console.WriteLine("To China");
        }

        public void GetProductType()
        {
            Console.WriteLine("Book ID:" + this.PBID);
            Console.WriteLine("Book Author:" + this.AuthorName);
            Console.WriteLine("Book Title:" + this.PBTitle);
            Console.WriteLine("Book Price:" + this.PBPrice);
            Console.WriteLine("Book Pages:" + this.PBPages);
        }
    }
}
