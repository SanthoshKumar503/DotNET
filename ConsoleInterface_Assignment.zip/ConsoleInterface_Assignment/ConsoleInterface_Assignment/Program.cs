﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleInterface_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Product type");
            string type = Console.ReadLine();
            ProductMobile pm = null;
            ProductBook pb = null;
            if (type=="mobile")
            {
                Console.WriteLine("Enter the Mobile ID");
                int id = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Mobile Name");
                string mobilename = Console.ReadLine();
                Console.WriteLine("Enter the Mobile Price");
                int price = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Mobile Company Name");
                string cmpname = Console.ReadLine();
                Console.WriteLine("Enter the Mobile Ram size");
                int ram = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Mobile OS");
                string os = Console.ReadLine();

                pm = new ProductMobile(id, mobilename, price, cmpname, ram, os);
            }
            else if(type=="book")
            {
                Console.WriteLine("Enter the Book ID");
                int bid = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Book Author Name");
                string author = Console.ReadLine();
                Console.WriteLine("Enter the Book Title");
                string title = Console.ReadLine();
                Console.WriteLine("Enter the Book Price");
                int bprice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Book Pages");
                int pages = Convert.ToInt32(Console.ReadLine());

               pb = new ProductBook(bid, author, title, bprice, pages);
            }
            if (type == "book" || type == "mobile")
            {
                Courier c = new Courier("BlueDart", "Bangalore");
                if (type == "mobile")
                {
                    c.ReceiveProduct(pm);
                }
                else
                {
                    c.ReceiveProduct(pb);
                }
            }
            else
            {
                Console.WriteLine("Invalid product");
            }
            Console.ReadLine();
        }
    }
}

