﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleInterface_Assignment
{
    class Courier
    {
        string CourierName;
        string CourierAddress;
        public Courier(string CourierName,string CourierAddress)
        {
            this.CourierName = CourierName;
            this.CourierAddress = CourierAddress;
        }
        public void ReceiveProduct(ICourierProduct i)
        {
            Console.WriteLine("--------------------");
            i.GetFromAddress();
            i.GetToAddress();                                      
            i.GetProductType();
            Console.WriteLine("--------------------");
        }
    }
}
