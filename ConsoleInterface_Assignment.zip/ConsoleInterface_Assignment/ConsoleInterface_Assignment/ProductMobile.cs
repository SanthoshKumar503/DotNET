﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleInterface_Assignment
{
    class ProductMobile : ICourierProduct
    {
        int PMID;
        string PMName;
        int PMPrice;
        string CompanyName;
        int RAM;
        string OS;
        public ProductMobile(int PMID,string PMName,int PMPrice,
            string CompanyName,int RAM,string OS)
        {
            this.PMID = PMID;
            this.PMName = PMName;
            this.PMPrice = PMPrice;
            this.CompanyName = CompanyName;
            this.RAM = RAM;
            this.OS = OS;
        }
        public void Start()
        {
            Console.WriteLine("ProductMobile Started...");
        }
        public void Stop()
        {
            Console.WriteLine("ProductMobile Stopped...");
        }
        public void Call()
        {
            Console.WriteLine("ProductMobile Called...");
        }
        public void sentMsg()
        {
            Console.WriteLine("Message is sent...");
        }

        public void GetFromAddress()
        {
            Console.WriteLine("From India");
        }

        public void GetToAddress()
        {
            Console.WriteLine("To Newyork");
        }

        public void GetProductType()
        {
            Console.WriteLine("Mobile ID:" + this.PMID);
            Console.WriteLine("Mobile Name:" + this.PMName);
            Console.WriteLine("Mobile Price:" + this.PMPrice);
            Console.WriteLine("Mobile CompanyName:" + this.CompanyName);
            Console.WriteLine("Mobile RAM Size:" + this.RAM);
            Console.WriteLine("Mobile OS:" + this.OS);
        }
    }
}
