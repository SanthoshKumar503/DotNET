﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Delegates
{
    class Test
    {
        public delegate void del(string str);

        public void Call1(string s)
        {
            Console.WriteLine("Call1 called:" + s);
        }
        public void Call2(string s2)
        {
            Console.WriteLine("Call2 called:" + s2);

        }
        public static void Call3(string s3)
        {
            Console.WriteLine("Call3 called:" + s3);
        }
        public delegate void delcall(string str);
        public void AddEmployeeIdDB(string name,string city,delcall callback)
        {
            Console.WriteLine(name + " " + city);
            if(callback!=null)
            {
                callback("It is done");
            }
        }

    }
}
