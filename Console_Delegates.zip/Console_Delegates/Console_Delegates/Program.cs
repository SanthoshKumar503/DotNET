﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Delegates
{
    class Program
    {
        static void Main(string[] args)
        {
            Test t = new Test();
            t.AddEmployeeIdDB("san", "bng", (s) => Console.WriteLine(s));
            t.AddEmployeeIdDB("sam", "ctr", (s) => Console.WriteLine(s));
            t.AddEmployeeIdDB("man", "chn", null);
            t.AddEmployeeIdDB("hjk", "sjh", t.Call1);

            //Test.del d = new Test.del(t.Call1);
            Test.del d = t.Call1;
            d += t.Call2;
            d += Test.Call3;
            d -= t.Call1;
            d += delegate (string str)
              {
                  Console.WriteLine("Anonymous function:" + str);
              };

            d += (s) =>
            {
                Console.WriteLine("Lamda function multi:" + s);
            };
            d += (x) => Console.WriteLine("Lambda function single:" + x);

            d("Hello");
            Console.ReadLine();
        }
    }
}
