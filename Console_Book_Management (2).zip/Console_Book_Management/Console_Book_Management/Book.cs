﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Book_Management
{
    class Book
    {
        private int BookId;
        private string BookTitle;
        private string BookAuthor;
        private int BookPrice;
        private int BookPages;
        private static int count = 1000;
        public Book(string BookTitle, string BookAuthor, int BookPrice, int BookPages)
        {            
            this.BookTitle = BookTitle;
            this.BookAuthor = BookAuthor;
            this.BookPrice = BookPrice;
            this.BookPages = BookPages;
            this.BookId = ++Book.count;
        }
        public int PBookId
        {
            get
            {
                return this.BookId;
            }            
        }
        public string PBookTitle
        {
            get
            {
                return this.BookTitle;
            }
            set
            {
                if(value!=" ")
                {
                    this.BookTitle = value;
                }
            }
        }
        public string PBookAuthor
        {
            get
            {
                return this.BookAuthor;
            }
            set
            {
                if(value!=" ")
                {
                    this.BookAuthor = value;
                }
            }
        }
        public int PBookPrice
        {
            get
            {
                return this.BookPrice;
            }
            set
            {
                if(value>0)
                {
                    this.BookPrice = value;
                }
            }
        }
        public int PBookPages
        {
            get
            {
                return this.BookPages;
            }
            set
            {
                if(value>0)
                {
                    this.BookPages = value;
                }
            }
        }
    }
}
