﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Book_Management
{
    class Ebook : Book
    {
        private int BookSize;
        private string BookFormat;
        public Ebook(string BookTitle, string BookAuthor, int BookPrice, int BookPages,
            int BookSize,string BookFormat):base(BookTitle, BookAuthor, BookPrice, BookPages)
        {
            this.BookSize = BookSize;
            this.BookFormat = BookFormat;
        }
        public int PBookSize
        {
            get
            {
                return this.BookSize;
            }
            set
            {
                if(value>0)
                {
                    this.BookSize = value;
                }
            }
        }
        public string PBookFormat
        {
            get
            {
                return this.BookFormat;
            }
            set
            {
                if(value!=" ")
                {
                    this.BookFormat = value;
                }
            }
        }
    }
}
