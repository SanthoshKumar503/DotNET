﻿namespace Win_Banking_Application_ADO
{
    partial class frm_NewCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_newCustomer = new System.Windows.Forms.Label();
            this.lbl_custName = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_custMobile = new System.Windows.Forms.Label();
            this.lbl_custGender = new System.Windows.Forms.Label();
            this.lbl_custPassword = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.rdo_male = new System.Windows.Forms.RadioButton();
            this.rdo_female = new System.Windows.Forms.RadioButton();
            this.txt_custPass = new System.Windows.Forms.TextBox();
            this.btn_custSubmit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_newCustomer
            // 
            this.lbl_newCustomer.AutoSize = true;
            this.lbl_newCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_newCustomer.ForeColor = System.Drawing.Color.Purple;
            this.lbl_newCustomer.Location = new System.Drawing.Point(300, 27);
            this.lbl_newCustomer.Name = "lbl_newCustomer";
            this.lbl_newCustomer.Size = new System.Drawing.Size(212, 32);
            this.lbl_newCustomer.TabIndex = 0;
            this.lbl_newCustomer.Text = "New Customer";
            // 
            // lbl_custName
            // 
            this.lbl_custName.AutoSize = true;
            this.lbl_custName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_custName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_custName.Location = new System.Drawing.Point(90, 184);
            this.lbl_custName.Name = "lbl_custName";
            this.lbl_custName.Size = new System.Drawing.Size(216, 25);
            this.lbl_custName.TabIndex = 1;
            this.lbl_custName.Text = "Enter Customer Name :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label2.Location = new System.Drawing.Point(90, 248);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(212, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Enter Customer Email :";
            // 
            // lbl_custMobile
            // 
            this.lbl_custMobile.AutoSize = true;
            this.lbl_custMobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_custMobile.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_custMobile.Location = new System.Drawing.Point(94, 304);
            this.lbl_custMobile.Name = "lbl_custMobile";
            this.lbl_custMobile.Size = new System.Drawing.Size(206, 25);
            this.lbl_custMobile.TabIndex = 3;
            this.lbl_custMobile.Text = "Enter Mobile Number :";
            // 
            // lbl_custGender
            // 
            this.lbl_custGender.AutoSize = true;
            this.lbl_custGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_custGender.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_custGender.Location = new System.Drawing.Point(94, 360);
            this.lbl_custGender.Name = "lbl_custGender";
            this.lbl_custGender.Size = new System.Drawing.Size(178, 25);
            this.lbl_custGender.TabIndex = 4;
            this.lbl_custGender.Text = "Customer Gender :";
            // 
            // lbl_custPassword
            // 
            this.lbl_custPassword.AutoSize = true;
            this.lbl_custPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_custPassword.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_custPassword.Location = new System.Drawing.Point(90, 420);
            this.lbl_custPassword.Name = "lbl_custPassword";
            this.lbl_custPassword.Size = new System.Drawing.Size(236, 25);
            this.lbl_custPassword.TabIndex = 5;
            this.lbl_custPassword.Text = "Enter Customer Passord :";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(344, 185);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(217, 26);
            this.textBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(344, 247);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(217, 26);
            this.textBox2.TabIndex = 7;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(344, 304);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(217, 26);
            this.textBox3.TabIndex = 8;
            // 
            // rdo_male
            // 
            this.rdo_male.AutoSize = true;
            this.rdo_male.Location = new System.Drawing.Point(344, 360);
            this.rdo_male.Name = "rdo_male";
            this.rdo_male.Size = new System.Drawing.Size(68, 24);
            this.rdo_male.TabIndex = 9;
            this.rdo_male.TabStop = true;
            this.rdo_male.Text = "Male";
            this.rdo_male.UseVisualStyleBackColor = true;
            // 
            // rdo_female
            // 
            this.rdo_female.AutoSize = true;
            this.rdo_female.Location = new System.Drawing.Point(453, 360);
            this.rdo_female.Name = "rdo_female";
            this.rdo_female.Size = new System.Drawing.Size(87, 24);
            this.rdo_female.TabIndex = 10;
            this.rdo_female.TabStop = true;
            this.rdo_female.Text = "Female";
            this.rdo_female.UseVisualStyleBackColor = true;
            // 
            // txt_custPass
            // 
            this.txt_custPass.Location = new System.Drawing.Point(344, 420);
            this.txt_custPass.Name = "txt_custPass";
            this.txt_custPass.Size = new System.Drawing.Size(217, 26);
            this.txt_custPass.TabIndex = 11;
            // 
            // btn_custSubmit
            // 
            this.btn_custSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_custSubmit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_custSubmit.Location = new System.Drawing.Point(408, 516);
            this.btn_custSubmit.Name = "btn_custSubmit";
            this.btn_custSubmit.Size = new System.Drawing.Size(104, 36);
            this.btn_custSubmit.TabIndex = 12;
            this.btn_custSubmit.Text = "Submit";
            this.btn_custSubmit.UseVisualStyleBackColor = true;
            // 
            // frm_NewCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(851, 723);
            this.Controls.Add(this.btn_custSubmit);
            this.Controls.Add(this.txt_custPass);
            this.Controls.Add(this.rdo_female);
            this.Controls.Add(this.rdo_male);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lbl_custPassword);
            this.Controls.Add(this.lbl_custGender);
            this.Controls.Add(this.lbl_custMobile);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_custName);
            this.Controls.Add(this.lbl_newCustomer);
            this.Name = "frm_NewCustomer";
            this.Text = "frm_NewCustomer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_newCustomer;
        private System.Windows.Forms.Label lbl_custName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_custMobile;
        private System.Windows.Forms.Label lbl_custGender;
        private System.Windows.Forms.Label lbl_custPassword;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.RadioButton rdo_male;
        private System.Windows.Forms.RadioButton rdo_female;
        private System.Windows.Forms.TextBox txt_custPass;
        private System.Windows.Forms.Button btn_custSubmit;
    }
}