﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Banking_Application_ADO
{
    public partial class frm_Home : Form
    {
        public static int accID;
        public static int custID;
        public frm_Home()
        {
            InitializeComponent();
        }

        private void frm_Home_Load(object sender, EventArgs e)
        {
            BankingDAL dal = new BankingDAL();
            GetCustomer g = dal.GetCust(frm_Login.custID);
            lbl_homeCustID.Text += g.CustomerID;
            lbl_homeCustName.Text += g.CustomerName;
            custID= g.CustomerID;

            accID =dal.GetID(g.CustomerID);  
            if(accID!=0)
            {
                lbl_homeAccID2.Text = accID.ToString();
            } 
            else
            {
                lbl_homeAccID2.Text = "Add Account";
            }                       
        }

        private void lbl_NewAccount_Click(object sender, EventArgs e)
        {
            frm_NewAccount nacc = new frm_NewAccount();
            nacc.Show();
        }

        private void btn_AddTransaction_Click(object sender, EventArgs e)
        {
            frm_addTransaction atran = new frm_addTransaction();
            atran.Show();
        }

        private void btn_MyTransaction_Click(object sender, EventArgs e)
        {
            frm_ShowTransactions s = new frm_ShowTransactions();
            s.Show();
        }
    }
}
