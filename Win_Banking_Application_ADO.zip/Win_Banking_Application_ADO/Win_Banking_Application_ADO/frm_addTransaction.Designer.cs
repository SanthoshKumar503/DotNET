﻿namespace Win_Banking_Application_ADO
{
    partial class frm_addTransaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_tranAccID = new System.Windows.Forms.Label();
            this.txt_tranAmount = new System.Windows.Forms.Label();
            this.lbl_tranType = new System.Windows.Forms.Label();
            this.txt_tranAccID = new System.Windows.Forms.TextBox();
            this.cmb_tranType = new System.Windows.Forms.ComboBox();
            this.btn_tranMakePay = new System.Windows.Forms.Button();
            this.lbl_tranStatus = new System.Windows.Forms.Label();
            this.txt_tranAmt = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Purple;
            this.label1.Location = new System.Drawing.Point(297, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(215, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Make Payment";
            // 
            // lbl_tranAccID
            // 
            this.lbl_tranAccID.AutoSize = true;
            this.lbl_tranAccID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tranAccID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_tranAccID.Location = new System.Drawing.Point(134, 172);
            this.lbl_tranAccID.Name = "lbl_tranAccID";
            this.lbl_tranAccID.Size = new System.Drawing.Size(119, 25);
            this.lbl_tranAccID.TabIndex = 1;
            this.lbl_tranAccID.Text = "Account ID :";
            // 
            // txt_tranAmount
            // 
            this.txt_tranAmount.AutoSize = true;
            this.txt_tranAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tranAmount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txt_tranAmount.Location = new System.Drawing.Point(134, 236);
            this.txt_tranAmount.Name = "txt_tranAmount";
            this.txt_tranAmount.Size = new System.Drawing.Size(142, 25);
            this.txt_tranAmount.TabIndex = 2;
            this.txt_tranAmount.Text = "Enter Amount :";
            // 
            // lbl_tranType
            // 
            this.lbl_tranType.AutoSize = true;
            this.lbl_tranType.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tranType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_tranType.Location = new System.Drawing.Point(134, 317);
            this.lbl_tranType.Name = "lbl_tranType";
            this.lbl_tranType.Size = new System.Drawing.Size(176, 25);
            this.lbl_tranType.TabIndex = 3;
            this.lbl_tranType.Text = "Transaction Type :";
            // 
            // txt_tranAccID
            // 
            this.txt_tranAccID.Location = new System.Drawing.Point(336, 172);
            this.txt_tranAccID.Name = "txt_tranAccID";
            this.txt_tranAccID.Size = new System.Drawing.Size(223, 26);
            this.txt_tranAccID.TabIndex = 4;
            // 
            // cmb_tranType
            // 
            this.cmb_tranType.FormattingEnabled = true;
            this.cmb_tranType.Location = new System.Drawing.Point(336, 317);
            this.cmb_tranType.Name = "cmb_tranType";
            this.cmb_tranType.Size = new System.Drawing.Size(223, 28);
            this.cmb_tranType.TabIndex = 6;
            // 
            // btn_tranMakePay
            // 
            this.btn_tranMakePay.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_tranMakePay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_tranMakePay.Location = new System.Drawing.Point(357, 423);
            this.btn_tranMakePay.Name = "btn_tranMakePay";
            this.btn_tranMakePay.Size = new System.Drawing.Size(118, 45);
            this.btn_tranMakePay.TabIndex = 7;
            this.btn_tranMakePay.Text = "Make Pay";
            this.btn_tranMakePay.UseVisualStyleBackColor = true;
            this.btn_tranMakePay.Click += new System.EventHandler(this.btn_tranMakePay_Click);
            // 
            // lbl_tranStatus
            // 
            this.lbl_tranStatus.AutoSize = true;
            this.lbl_tranStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tranStatus.ForeColor = System.Drawing.Color.Red;
            this.lbl_tranStatus.Location = new System.Drawing.Point(336, 560);
            this.lbl_tranStatus.Name = "lbl_tranStatus";
            this.lbl_tranStatus.Size = new System.Drawing.Size(79, 25);
            this.lbl_tranStatus.TabIndex = 8;
            this.lbl_tranStatus.Text = "Status :";
            // 
            // txt_tranAmt
            // 
            this.txt_tranAmt.Location = new System.Drawing.Point(336, 236);
            this.txt_tranAmt.Name = "txt_tranAmt";
            this.txt_tranAmt.Size = new System.Drawing.Size(223, 26);
            this.txt_tranAmt.TabIndex = 9;
            // 
            // frm_addTransaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(886, 709);
            this.Controls.Add(this.txt_tranAmt);
            this.Controls.Add(this.lbl_tranStatus);
            this.Controls.Add(this.btn_tranMakePay);
            this.Controls.Add(this.cmb_tranType);
            this.Controls.Add(this.txt_tranAccID);
            this.Controls.Add(this.lbl_tranType);
            this.Controls.Add(this.txt_tranAmount);
            this.Controls.Add(this.lbl_tranAccID);
            this.Controls.Add(this.label1);
            this.Name = "frm_addTransaction";
            this.Text = "frm_addTransaction";
            this.Load += new System.EventHandler(this.frm_addTransaction_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_tranAccID;
        private System.Windows.Forms.Label txt_tranAmount;
        private System.Windows.Forms.Label lbl_tranType;
        private System.Windows.Forms.TextBox txt_tranAccID;
        private System.Windows.Forms.ComboBox cmb_tranType;
        private System.Windows.Forms.Button btn_tranMakePay;
        private System.Windows.Forms.Label lbl_tranStatus;
        private System.Windows.Forms.TextBox txt_tranAmt;
    }
}