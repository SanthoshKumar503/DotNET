﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Banking_Application_ADO
{
    class ShowTransaction
    {
        public int TransactionID { get; set; }
        public int AccountID { get; set; }
        public int Amount { get; set; }
        public string TransactionType { get; set; }
        public string TransactionDate { get; set; }


    }
}
