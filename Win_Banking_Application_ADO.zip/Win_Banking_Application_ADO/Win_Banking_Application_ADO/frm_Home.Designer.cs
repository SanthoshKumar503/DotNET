﻿namespace Win_Banking_Application_ADO
{
    partial class frm_Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_home = new System.Windows.Forms.Label();
            this.lbl_homeCustID = new System.Windows.Forms.Label();
            this.lbl_homeCustName = new System.Windows.Forms.Label();
            this.lbl_NewAccount = new System.Windows.Forms.Button();
            this.btn_AddTransaction = new System.Windows.Forms.Button();
            this.btn_MyTransaction = new System.Windows.Forms.Button();
            this.lbl_homeAccID = new System.Windows.Forms.Label();
            this.lbl_homeAccID2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_home
            // 
            this.lbl_home.AutoSize = true;
            this.lbl_home.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_home.ForeColor = System.Drawing.Color.Purple;
            this.lbl_home.Location = new System.Drawing.Point(326, 51);
            this.lbl_home.Name = "lbl_home";
            this.lbl_home.Size = new System.Drawing.Size(173, 32);
            this.lbl_home.TabIndex = 0;
            this.lbl_home.Text = "Home Page";
            // 
            // lbl_homeCustID
            // 
            this.lbl_homeCustID.AutoSize = true;
            this.lbl_homeCustID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_homeCustID.Location = new System.Drawing.Point(164, 155);
            this.lbl_homeCustID.Name = "lbl_homeCustID";
            this.lbl_homeCustID.Size = new System.Drawing.Size(107, 20);
            this.lbl_homeCustID.TabIndex = 1;
            this.lbl_homeCustID.Text = "Customer ID :";
            // 
            // lbl_homeCustName
            // 
            this.lbl_homeCustName.AutoSize = true;
            this.lbl_homeCustName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_homeCustName.Location = new System.Drawing.Point(139, 202);
            this.lbl_homeCustName.Name = "lbl_homeCustName";
            this.lbl_homeCustName.Size = new System.Drawing.Size(132, 20);
            this.lbl_homeCustName.TabIndex = 2;
            this.lbl_homeCustName.Text = "Customer Name :";
            // 
            // lbl_NewAccount
            // 
            this.lbl_NewAccount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_NewAccount.Location = new System.Drawing.Point(113, 311);
            this.lbl_NewAccount.Name = "lbl_NewAccount";
            this.lbl_NewAccount.Size = new System.Drawing.Size(158, 43);
            this.lbl_NewAccount.TabIndex = 3;
            this.lbl_NewAccount.Text = "New Account";
            this.lbl_NewAccount.UseVisualStyleBackColor = true;
            this.lbl_NewAccount.Click += new System.EventHandler(this.lbl_NewAccount_Click);
            // 
            // btn_AddTransaction
            // 
            this.btn_AddTransaction.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_AddTransaction.Location = new System.Drawing.Point(332, 311);
            this.btn_AddTransaction.Name = "btn_AddTransaction";
            this.btn_AddTransaction.Size = new System.Drawing.Size(167, 43);
            this.btn_AddTransaction.TabIndex = 4;
            this.btn_AddTransaction.Text = "Add Transaction";
            this.btn_AddTransaction.UseVisualStyleBackColor = true;
            this.btn_AddTransaction.Click += new System.EventHandler(this.btn_AddTransaction_Click);
            // 
            // btn_MyTransaction
            // 
            this.btn_MyTransaction.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_MyTransaction.Location = new System.Drawing.Point(544, 311);
            this.btn_MyTransaction.Name = "btn_MyTransaction";
            this.btn_MyTransaction.Size = new System.Drawing.Size(139, 43);
            this.btn_MyTransaction.TabIndex = 5;
            this.btn_MyTransaction.Text = "My Transactions";
            this.btn_MyTransaction.UseVisualStyleBackColor = true;
            this.btn_MyTransaction.Click += new System.EventHandler(this.btn_MyTransaction_Click);
            // 
            // lbl_homeAccID
            // 
            this.lbl_homeAccID.AutoSize = true;
            this.lbl_homeAccID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_homeAccID.Location = new System.Drawing.Point(527, 155);
            this.lbl_homeAccID.Name = "lbl_homeAccID";
            this.lbl_homeAccID.Size = new System.Drawing.Size(97, 20);
            this.lbl_homeAccID.TabIndex = 6;
            this.lbl_homeAccID.Text = "Account ID :";
            // 
            // lbl_homeAccID2
            // 
            this.lbl_homeAccID2.AutoSize = true;
            this.lbl_homeAccID2.Location = new System.Drawing.Point(621, 155);
            this.lbl_homeAccID2.Name = "lbl_homeAccID2";
            this.lbl_homeAccID2.Size = new System.Drawing.Size(0, 20);
            this.lbl_homeAccID2.TabIndex = 7;
            // 
            // frm_Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 711);
            this.Controls.Add(this.lbl_homeAccID2);
            this.Controls.Add(this.lbl_homeAccID);
            this.Controls.Add(this.btn_MyTransaction);
            this.Controls.Add(this.btn_AddTransaction);
            this.Controls.Add(this.lbl_NewAccount);
            this.Controls.Add(this.lbl_homeCustName);
            this.Controls.Add(this.lbl_homeCustID);
            this.Controls.Add(this.lbl_home);
            this.Name = "frm_Home";
            this.Text = "frm_Home";
            this.Load += new System.EventHandler(this.frm_Home_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_home;
        private System.Windows.Forms.Label lbl_homeCustID;
        private System.Windows.Forms.Label lbl_homeCustName;
        private System.Windows.Forms.Button lbl_NewAccount;
        private System.Windows.Forms.Button btn_AddTransaction;
        private System.Windows.Forms.Button btn_MyTransaction;
        private System.Windows.Forms.Label lbl_homeAccID;
        private System.Windows.Forms.Label lbl_homeAccID2;
    }
}