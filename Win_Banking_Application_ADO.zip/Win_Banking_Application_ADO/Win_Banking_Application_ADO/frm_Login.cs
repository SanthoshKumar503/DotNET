﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Banking_Application_ADO
{
    public partial class frm_Login : Form
    {
        public static int custID;
        public frm_Login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            string id = txt_loginid.Text;
            string pass = txt_loginpassword.Text;
            bool sts= Validation.IsID(id);
            if(id==string.Empty)
            {
                lbl_loginStatus.Text = "Enter Customer ID";
            }
            else if(sts==false)
            {
                lbl_loginStatus.Text = "Enter Valid ID";
            }
            else if(pass==string.Empty)
            {
                lbl_loginStatus.Text = "Enter Password";
            }
            else
            {
                Customers c = new Customers();
                c.CustomerID = Convert.ToInt32(id);
                custID=Convert.ToInt32(id);
                c.CustomerPassword = pass;
                BankingDAL dal = new BankingDAL();
                bool status=dal.Login(c);
                if(status==true)
                {
                    frm_Home h = new frm_Home();
                    h.Show();
                }
                else
                {
                    lbl_loginStatus.Text = "Invalid User";
                }
            }
        }

        private void btn_custSubmit_Click(object sender, EventArgs e)
        {
            string name = txt_custName.Text;
            string email = txt_custEmail.Text;
            string mobile = txt_custMobile.Text;
            bool sts = Validation.IsID(mobile);
            bool male = rdo_male.Checked;
            bool female = rdo_female.Checked;
            string pass = txt_custPass.Text;
            if(name==string.Empty)
            {
                lbl_custStatus.Text = "Enter Customer Name";
            }
            else if(email==string.Empty)
            {
                lbl_custStatus.Text = "Enter Email";
            }
            else if(mobile==string.Empty)
            {
                lbl_custStatus.Text = "Enter Mobile Number";
            }
            else if(sts==false)
            {
                lbl_custStatus.Text = "Enter valid Number";
            }
            else if(male==false && female==false)
            {
                lbl_custStatus.Text = "Select Gender";
            }
            else if(pass==string.Empty)
            {
                lbl_custStatus.Text = "Enter Password";
            }
            else
            {
                Customers c = new Customers();
                c.CustomerName = name;
                c.CustomerEmail = email;
                c.CustomerMobile = mobile;
                if(male==true)
                {
                    c.CustomerGender = "Male";
                }
                else
                {
                    c.CustomerGender = "Female";
                }
                c.CustomerPassword = pass;
                BankingDAL dal = new BankingDAL();
                c.CustomerID=dal.AddCustomers(c);
                lbl_custStatus.Text = "Customer ID :" + c.CustomerID;
            }
        }

        private void frm_Login_Load(object sender, EventArgs e)
        {

        }
    }
}
