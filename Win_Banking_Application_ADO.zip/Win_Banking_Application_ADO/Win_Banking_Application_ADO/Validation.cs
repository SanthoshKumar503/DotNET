﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Banking_Application_ADO
{
    class Validation
    {
        public static bool IsID(string str)
        {
            int count = 0;
            int cnt = str.Length;
            char[] ch = str.ToCharArray();
            for(int i=0;i<ch.Length;i++)
            {
                int c = ch[i];
                if(ch[i]>= '0' && ch[i]<='9')
                {
                    count++;
                } 
            }
            if(count == cnt)
            {
                return true;
            }
            else
            {
                return false;
            }
             
        }
    }
}
