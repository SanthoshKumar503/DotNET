﻿namespace Win_Banking_Application_ADO
{
    partial class frm_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_login = new System.Windows.Forms.Label();
            this.lbl_loginid = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_loginid = new System.Windows.Forms.TextBox();
            this.txt_loginpassword = new System.Windows.Forms.TextBox();
            this.lbl_loginIdStatus = new System.Windows.Forms.Label();
            this.lbl_loginPassStatus = new System.Windows.Forms.Label();
            this.btn_login = new System.Windows.Forms.Button();
            this.btn_custSubmit = new System.Windows.Forms.Button();
            this.txt_custPass = new System.Windows.Forms.TextBox();
            this.rdo_female = new System.Windows.Forms.RadioButton();
            this.rdo_male = new System.Windows.Forms.RadioButton();
            this.txt_custMobile = new System.Windows.Forms.TextBox();
            this.txt_custEmail = new System.Windows.Forms.TextBox();
            this.txt_custName = new System.Windows.Forms.TextBox();
            this.lbl_custPassword = new System.Windows.Forms.Label();
            this.lbl_custGender = new System.Windows.Forms.Label();
            this.lbl_custMobile = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_custName = new System.Windows.Forms.Label();
            this.lbl_newCustomer = new System.Windows.Forms.Label();
            this.lbl_loginStatus = new System.Windows.Forms.Label();
            this.lbl_custStatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_login
            // 
            this.lbl_login.AutoSize = true;
            this.lbl_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_login.ForeColor = System.Drawing.Color.Purple;
            this.lbl_login.Location = new System.Drawing.Point(243, 92);
            this.lbl_login.Name = "lbl_login";
            this.lbl_login.Size = new System.Drawing.Size(229, 32);
            this.lbl_login.TabIndex = 0;
            this.lbl_login.Text = "Customer Login";
            // 
            // lbl_loginid
            // 
            this.lbl_loginid.AutoSize = true;
            this.lbl_loginid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_loginid.ForeColor = System.Drawing.Color.Blue;
            this.lbl_loginid.Location = new System.Drawing.Point(39, 199);
            this.lbl_loginid.Name = "lbl_loginid";
            this.lbl_loginid.Size = new System.Drawing.Size(183, 25);
            this.lbl_loginid.TabIndex = 1;
            this.lbl_loginid.Text = "Enter Customer ID :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(39, 264);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(250, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Enter Customer Password :";
            // 
            // txt_loginid
            // 
            this.txt_loginid.Location = new System.Drawing.Point(297, 199);
            this.txt_loginid.Name = "txt_loginid";
            this.txt_loginid.Size = new System.Drawing.Size(244, 26);
            this.txt_loginid.TabIndex = 3;
            // 
            // txt_loginpassword
            // 
            this.txt_loginpassword.Location = new System.Drawing.Point(297, 264);
            this.txt_loginpassword.Name = "txt_loginpassword";
            this.txt_loginpassword.Size = new System.Drawing.Size(244, 26);
            this.txt_loginpassword.TabIndex = 4;
            // 
            // lbl_loginIdStatus
            // 
            this.lbl_loginIdStatus.AutoSize = true;
            this.lbl_loginIdStatus.ForeColor = System.Drawing.Color.Red;
            this.lbl_loginIdStatus.Location = new System.Drawing.Point(560, 205);
            this.lbl_loginIdStatus.Name = "lbl_loginIdStatus";
            this.lbl_loginIdStatus.Size = new System.Drawing.Size(0, 20);
            this.lbl_loginIdStatus.TabIndex = 5;
            // 
            // lbl_loginPassStatus
            // 
            this.lbl_loginPassStatus.AutoSize = true;
            this.lbl_loginPassStatus.ForeColor = System.Drawing.Color.Red;
            this.lbl_loginPassStatus.Location = new System.Drawing.Point(548, 264);
            this.lbl_loginPassStatus.Name = "lbl_loginPassStatus";
            this.lbl_loginPassStatus.Size = new System.Drawing.Size(0, 20);
            this.lbl_loginPassStatus.TabIndex = 6;
            // 
            // btn_login
            // 
            this.btn_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.ForeColor = System.Drawing.Color.Blue;
            this.btn_login.Location = new System.Drawing.Point(227, 352);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(152, 47);
            this.btn_login.TabIndex = 7;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // btn_custSubmit
            // 
            this.btn_custSubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_custSubmit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_custSubmit.Location = new System.Drawing.Point(909, 505);
            this.btn_custSubmit.Name = "btn_custSubmit";
            this.btn_custSubmit.Size = new System.Drawing.Size(104, 36);
            this.btn_custSubmit.TabIndex = 25;
            this.btn_custSubmit.Text = "Submit";
            this.btn_custSubmit.UseVisualStyleBackColor = true;
            this.btn_custSubmit.Click += new System.EventHandler(this.btn_custSubmit_Click);
            // 
            // txt_custPass
            // 
            this.txt_custPass.Location = new System.Drawing.Point(926, 433);
            this.txt_custPass.Name = "txt_custPass";
            this.txt_custPass.Size = new System.Drawing.Size(217, 26);
            this.txt_custPass.TabIndex = 24;
            // 
            // rdo_female
            // 
            this.rdo_female.AutoSize = true;
            this.rdo_female.Location = new System.Drawing.Point(1039, 373);
            this.rdo_female.Name = "rdo_female";
            this.rdo_female.Size = new System.Drawing.Size(87, 24);
            this.rdo_female.TabIndex = 23;
            this.rdo_female.TabStop = true;
            this.rdo_female.Text = "Female";
            this.rdo_female.UseVisualStyleBackColor = true;
            // 
            // rdo_male
            // 
            this.rdo_male.AutoSize = true;
            this.rdo_male.Location = new System.Drawing.Point(909, 374);
            this.rdo_male.Name = "rdo_male";
            this.rdo_male.Size = new System.Drawing.Size(68, 24);
            this.rdo_male.TabIndex = 22;
            this.rdo_male.TabStop = true;
            this.rdo_male.Text = "Male";
            this.rdo_male.UseVisualStyleBackColor = true;
            // 
            // txt_custMobile
            // 
            this.txt_custMobile.Location = new System.Drawing.Point(909, 319);
            this.txt_custMobile.Name = "txt_custMobile";
            this.txt_custMobile.Size = new System.Drawing.Size(217, 26);
            this.txt_custMobile.TabIndex = 21;
            // 
            // txt_custEmail
            // 
            this.txt_custEmail.Location = new System.Drawing.Point(909, 263);
            this.txt_custEmail.Name = "txt_custEmail";
            this.txt_custEmail.Size = new System.Drawing.Size(217, 26);
            this.txt_custEmail.TabIndex = 20;
            // 
            // txt_custName
            // 
            this.txt_custName.Location = new System.Drawing.Point(909, 198);
            this.txt_custName.Name = "txt_custName";
            this.txt_custName.Size = new System.Drawing.Size(217, 26);
            this.txt_custName.TabIndex = 19;
            // 
            // lbl_custPassword
            // 
            this.lbl_custPassword.AutoSize = true;
            this.lbl_custPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_custPassword.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_custPassword.Location = new System.Drawing.Point(691, 434);
            this.lbl_custPassword.Name = "lbl_custPassword";
            this.lbl_custPassword.Size = new System.Drawing.Size(236, 25);
            this.lbl_custPassword.TabIndex = 18;
            this.lbl_custPassword.Text = "Enter Customer Passord :";
            // 
            // lbl_custGender
            // 
            this.lbl_custGender.AutoSize = true;
            this.lbl_custGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_custGender.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_custGender.Location = new System.Drawing.Point(691, 374);
            this.lbl_custGender.Name = "lbl_custGender";
            this.lbl_custGender.Size = new System.Drawing.Size(178, 25);
            this.lbl_custGender.TabIndex = 17;
            this.lbl_custGender.Text = "Customer Gender :";
            // 
            // lbl_custMobile
            // 
            this.lbl_custMobile.AutoSize = true;
            this.lbl_custMobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_custMobile.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_custMobile.Location = new System.Drawing.Point(691, 318);
            this.lbl_custMobile.Name = "lbl_custMobile";
            this.lbl_custMobile.Size = new System.Drawing.Size(206, 25);
            this.lbl_custMobile.TabIndex = 16;
            this.lbl_custMobile.Text = "Enter Mobile Number :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label3.Location = new System.Drawing.Point(691, 259);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(212, 25);
            this.label3.TabIndex = 15;
            this.label3.Text = "Enter Customer Email :";
            // 
            // lbl_custName
            // 
            this.lbl_custName.AutoSize = true;
            this.lbl_custName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_custName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lbl_custName.Location = new System.Drawing.Point(691, 199);
            this.lbl_custName.Name = "lbl_custName";
            this.lbl_custName.Size = new System.Drawing.Size(216, 25);
            this.lbl_custName.TabIndex = 14;
            this.lbl_custName.Text = "Enter Customer Name :";
            // 
            // lbl_newCustomer
            // 
            this.lbl_newCustomer.AutoSize = true;
            this.lbl_newCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_newCustomer.ForeColor = System.Drawing.Color.Purple;
            this.lbl_newCustomer.Location = new System.Drawing.Point(801, 92);
            this.lbl_newCustomer.Name = "lbl_newCustomer";
            this.lbl_newCustomer.Size = new System.Drawing.Size(212, 32);
            this.lbl_newCustomer.TabIndex = 13;
            this.lbl_newCustomer.Text = "New Customer";
            // 
            // lbl_loginStatus
            // 
            this.lbl_loginStatus.AutoSize = true;
            this.lbl_loginStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_loginStatus.ForeColor = System.Drawing.Color.Red;
            this.lbl_loginStatus.Location = new System.Drawing.Point(244, 457);
            this.lbl_loginStatus.Name = "lbl_loginStatus";
            this.lbl_loginStatus.Size = new System.Drawing.Size(121, 25);
            this.lbl_loginStatus.TabIndex = 26;
            this.lbl_loginStatus.Text = "Login Status";
            // 
            // lbl_custStatus
            // 
            this.lbl_custStatus.AutoSize = true;
            this.lbl_custStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_custStatus.ForeColor = System.Drawing.Color.Red;
            this.lbl_custStatus.Location = new System.Drawing.Point(855, 584);
            this.lbl_custStatus.Name = "lbl_custStatus";
            this.lbl_custStatus.Size = new System.Drawing.Size(211, 25);
            this.lbl_custStatus.TabIndex = 27;
            this.lbl_custStatus.Text = "Customer Login Status";
            // 
            // frm_Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1208, 650);
            this.Controls.Add(this.lbl_custStatus);
            this.Controls.Add(this.lbl_loginStatus);
            this.Controls.Add(this.btn_custSubmit);
            this.Controls.Add(this.txt_custPass);
            this.Controls.Add(this.rdo_female);
            this.Controls.Add(this.rdo_male);
            this.Controls.Add(this.txt_custMobile);
            this.Controls.Add(this.txt_custEmail);
            this.Controls.Add(this.txt_custName);
            this.Controls.Add(this.lbl_custPassword);
            this.Controls.Add(this.lbl_custGender);
            this.Controls.Add(this.lbl_custMobile);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbl_custName);
            this.Controls.Add(this.lbl_newCustomer);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.lbl_loginPassStatus);
            this.Controls.Add(this.lbl_loginIdStatus);
            this.Controls.Add(this.txt_loginpassword);
            this.Controls.Add(this.txt_loginid);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_loginid);
            this.Controls.Add(this.lbl_login);
            this.Name = "frm_Login";
            this.Text = "frm_Login";
            this.Load += new System.EventHandler(this.frm_Login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_login;
        private System.Windows.Forms.Label lbl_loginid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_loginid;
        private System.Windows.Forms.TextBox txt_loginpassword;
        private System.Windows.Forms.Label lbl_loginIdStatus;
        private System.Windows.Forms.Label lbl_loginPassStatus;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button btn_custSubmit;
        private System.Windows.Forms.TextBox txt_custPass;
        private System.Windows.Forms.RadioButton rdo_female;
        private System.Windows.Forms.RadioButton rdo_male;
        private System.Windows.Forms.TextBox txt_custMobile;
        private System.Windows.Forms.TextBox txt_custEmail;
        private System.Windows.Forms.TextBox txt_custName;
        private System.Windows.Forms.Label lbl_custPassword;
        private System.Windows.Forms.Label lbl_custGender;
        private System.Windows.Forms.Label lbl_custMobile;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_custName;
        private System.Windows.Forms.Label lbl_newCustomer;
        private System.Windows.Forms.Label lbl_loginStatus;
        private System.Windows.Forms.Label lbl_custStatus;
    }
}