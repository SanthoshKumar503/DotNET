﻿namespace Win_ADO
{
    partial class frm_Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_loginemployee = new System.Windows.Forms.Label();
            this.lbl_loginemployeeid = new System.Windows.Forms.Label();
            this.lbl_loginemployeepassword = new System.Windows.Forms.Label();
            this.txt_loginemployeeid = new System.Windows.Forms.TextBox();
            this.txt_loginemployeepassword = new System.Windows.Forms.TextBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.lbl_loginstatus = new System.Windows.Forms.Label();
            this.btn_loginnewemployee = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_loginemployee
            // 
            this.lbl_loginemployee.AutoSize = true;
            this.lbl_loginemployee.Location = new System.Drawing.Point(215, 35);
            this.lbl_loginemployee.Name = "lbl_loginemployee";
            this.lbl_loginemployee.Size = new System.Drawing.Size(89, 20);
            this.lbl_loginemployee.TabIndex = 0;
            this.lbl_loginemployee.Text = "Login Form";
            // 
            // lbl_loginemployeeid
            // 
            this.lbl_loginemployeeid.AutoSize = true;
            this.lbl_loginemployeeid.Location = new System.Drawing.Point(86, 125);
            this.lbl_loginemployeeid.Name = "lbl_loginemployeeid";
            this.lbl_loginemployeeid.Size = new System.Drawing.Size(108, 20);
            this.lbl_loginemployeeid.TabIndex = 1;
            this.lbl_loginemployeeid.Text = "Employee ID :";
            // 
            // lbl_loginemployeepassword
            // 
            this.lbl_loginemployeepassword.AutoSize = true;
            this.lbl_loginemployeepassword.Location = new System.Drawing.Point(90, 182);
            this.lbl_loginemployeepassword.Name = "lbl_loginemployeepassword";
            this.lbl_loginemployeepassword.Size = new System.Drawing.Size(160, 20);
            this.lbl_loginemployeepassword.TabIndex = 2;
            this.lbl_loginemployeepassword.Text = "Employee Password :";
            // 
            // txt_loginemployeeid
            // 
            this.txt_loginemployeeid.Location = new System.Drawing.Point(263, 118);
            this.txt_loginemployeeid.Name = "txt_loginemployeeid";
            this.txt_loginemployeeid.Size = new System.Drawing.Size(172, 26);
            this.txt_loginemployeeid.TabIndex = 3;
            // 
            // txt_loginemployeepassword
            // 
            this.txt_loginemployeepassword.Location = new System.Drawing.Point(263, 175);
            this.txt_loginemployeepassword.Name = "txt_loginemployeepassword";
            this.txt_loginemployeepassword.Size = new System.Drawing.Size(172, 26);
            this.txt_loginemployeepassword.TabIndex = 4;
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(154, 263);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(96, 44);
            this.btn_login.TabIndex = 5;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // lbl_loginstatus
            // 
            this.lbl_loginstatus.AutoSize = true;
            this.lbl_loginstatus.Location = new System.Drawing.Point(356, 275);
            this.lbl_loginstatus.Name = "lbl_loginstatus";
            this.lbl_loginstatus.Size = new System.Drawing.Size(138, 20);
            this.lbl_loginstatus.TabIndex = 6;
            this.lbl_loginstatus.Text = "Employee Status :";
            // 
            // btn_loginnewemployee
            // 
            this.btn_loginnewemployee.Location = new System.Drawing.Point(244, 366);
            this.btn_loginnewemployee.Name = "btn_loginnewemployee";
            this.btn_loginnewemployee.Size = new System.Drawing.Size(153, 52);
            this.btn_loginnewemployee.TabIndex = 7;
            this.btn_loginnewemployee.Text = "New Employee";
            this.btn_loginnewemployee.UseVisualStyleBackColor = true;
            this.btn_loginnewemployee.Click += new System.EventHandler(this.btn_loginnewemployee_Click);
            // 
            // frm_Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(657, 508);
            this.Controls.Add(this.btn_loginnewemployee);
            this.Controls.Add(this.lbl_loginstatus);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.txt_loginemployeepassword);
            this.Controls.Add(this.txt_loginemployeeid);
            this.Controls.Add(this.lbl_loginemployeepassword);
            this.Controls.Add(this.lbl_loginemployeeid);
            this.Controls.Add(this.lbl_loginemployee);
            this.Name = "frm_Login";
            this.Text = "frm_Login";
            this.Load += new System.EventHandler(this.frm_Login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_loginemployee;
        private System.Windows.Forms.Label lbl_loginemployeeid;
        private System.Windows.Forms.Label lbl_loginemployeepassword;
        private System.Windows.Forms.TextBox txt_loginemployeeid;
        private System.Windows.Forms.TextBox txt_loginemployeepassword;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Label lbl_loginstatus;
        private System.Windows.Forms.Button btn_loginnewemployee;
    }
}