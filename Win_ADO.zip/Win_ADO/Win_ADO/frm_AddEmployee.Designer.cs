﻿namespace Win_ADO
{
    partial class frm_AddEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_addname = new System.Windows.Forms.Label();
            this.lbl_addpassword = new System.Windows.Forms.Label();
            this.lbl_addcity = new System.Windows.Forms.Label();
            this.txt_addname = new System.Windows.Forms.TextBox();
            this.txt_addpassword = new System.Windows.Forms.TextBox();
            this.txt_addcity = new System.Windows.Forms.TextBox();
            this.lbl_addemployee = new System.Windows.Forms.Label();
            this.btn_addemployee = new System.Windows.Forms.Button();
            this.lbl_findstatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_addname
            // 
            this.lbl_addname.AutoSize = true;
            this.lbl_addname.Location = new System.Drawing.Point(115, 108);
            this.lbl_addname.Name = "lbl_addname";
            this.lbl_addname.Size = new System.Drawing.Size(102, 20);
            this.lbl_addname.TabIndex = 0;
            this.lbl_addname.Text = "Enter Name :";
            // 
            // lbl_addpassword
            // 
            this.lbl_addpassword.AutoSize = true;
            this.lbl_addpassword.Location = new System.Drawing.Point(119, 167);
            this.lbl_addpassword.Name = "lbl_addpassword";
            this.lbl_addpassword.Size = new System.Drawing.Size(129, 20);
            this.lbl_addpassword.TabIndex = 1;
            this.lbl_addpassword.Text = "Enter Password :";
            // 
            // lbl_addcity
            // 
            this.lbl_addcity.AutoSize = true;
            this.lbl_addcity.Location = new System.Drawing.Point(131, 227);
            this.lbl_addcity.Name = "lbl_addcity";
            this.lbl_addcity.Size = new System.Drawing.Size(86, 20);
            this.lbl_addcity.TabIndex = 2;
            this.lbl_addcity.Text = "Enter City :";
            // 
            // txt_addname
            // 
            this.txt_addname.Location = new System.Drawing.Point(274, 108);
            this.txt_addname.Name = "txt_addname";
            this.txt_addname.Size = new System.Drawing.Size(281, 26);
            this.txt_addname.TabIndex = 3;
            // 
            // txt_addpassword
            // 
            this.txt_addpassword.Location = new System.Drawing.Point(274, 167);
            this.txt_addpassword.Name = "txt_addpassword";
            this.txt_addpassword.Size = new System.Drawing.Size(281, 26);
            this.txt_addpassword.TabIndex = 4;
            // 
            // txt_addcity
            // 
            this.txt_addcity.Location = new System.Drawing.Point(274, 221);
            this.txt_addcity.Name = "txt_addcity";
            this.txt_addcity.Size = new System.Drawing.Size(281, 26);
            this.txt_addcity.TabIndex = 5;
            // 
            // lbl_addemployee
            // 
            this.lbl_addemployee.AutoSize = true;
            this.lbl_addemployee.Location = new System.Drawing.Point(343, 36);
            this.lbl_addemployee.Name = "lbl_addemployee";
            this.lbl_addemployee.Size = new System.Drawing.Size(136, 20);
            this.lbl_addemployee.TabIndex = 6;
            this.lbl_addemployee.Text = "ADD EMPLOYEE";
            // 
            // btn_addemployee
            // 
            this.btn_addemployee.Location = new System.Drawing.Point(258, 305);
            this.btn_addemployee.Name = "btn_addemployee";
            this.btn_addemployee.Size = new System.Drawing.Size(121, 43);
            this.btn_addemployee.TabIndex = 7;
            this.btn_addemployee.Text = "Add Employee";
            this.btn_addemployee.UseVisualStyleBackColor = true;
            this.btn_addemployee.Click += new System.EventHandler(this.btn_addemployee_Click);
            // 
            // lbl_findstatus
            // 
            this.lbl_findstatus.AutoSize = true;
            this.lbl_findstatus.Location = new System.Drawing.Point(447, 316);
            this.lbl_findstatus.Name = "lbl_findstatus";
            this.lbl_findstatus.Size = new System.Drawing.Size(64, 20);
            this.lbl_findstatus.TabIndex = 8;
            this.lbl_findstatus.Text = "Status :";
            // 
            // frm_AddEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(829, 512);
            this.Controls.Add(this.lbl_findstatus);
            this.Controls.Add(this.btn_addemployee);
            this.Controls.Add(this.lbl_addemployee);
            this.Controls.Add(this.txt_addcity);
            this.Controls.Add(this.txt_addpassword);
            this.Controls.Add(this.txt_addname);
            this.Controls.Add(this.lbl_addcity);
            this.Controls.Add(this.lbl_addpassword);
            this.Controls.Add(this.lbl_addname);
            this.Name = "frm_AddEmployee";
            this.Text = "frm_AddEmployee";
            this.Load += new System.EventHandler(this.frm_AddEmployee_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_addname;
        private System.Windows.Forms.Label lbl_addpassword;
        private System.Windows.Forms.Label lbl_addcity;
        private System.Windows.Forms.TextBox txt_addname;
        private System.Windows.Forms.TextBox txt_addpassword;
        private System.Windows.Forms.TextBox txt_addcity;
        private System.Windows.Forms.Label lbl_addemployee;
        private System.Windows.Forms.Button btn_addemployee;
        private System.Windows.Forms.Label lbl_findstatus;
    }
}