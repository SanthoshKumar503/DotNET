﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Win_ADO
{
    class EmployeesDAL
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int AddEmployee(Employee obj)
        {
            SqlCommand com_addemp = new SqlCommand("p_addemployee", con);
            com_addemp.CommandType = CommandType.StoredProcedure;
            com_addemp.Parameters.AddWithValue("@name", obj.EmployeeName);
            com_addemp.Parameters.AddWithValue("@psw", obj.EmployeePassword);
            com_addemp.Parameters.AddWithValue("@city", obj.EmployeeCity);
            SqlParameter p_id = new SqlParameter();  //for storing return value of procedure
            p_id.Direction = ParameterDirection.ReturnValue;
            com_addemp.Parameters.Add(p_id);
            con.Open();
            com_addemp.ExecuteNonQuery();
            con.Close();
            int id = Convert.ToInt32(p_id.Value);
            return id;
        }

        public Employee FindEmployee(int id)
        {
            SqlCommand com_find = new SqlCommand("p_find", con);
            com_find.CommandType = CommandType.StoredProcedure;
            com_find.Parameters.AddWithValue("@id", id);
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            if(dr.Read())
            {
                Employee obj = new Employee();
                obj.EmployeeID = dr.GetInt32(0);
                obj.EmployeeName = dr.GetString(1);
                obj.EmployeePassword = dr.GetString(2);
                obj.EmployeeCity = dr.GetString(3);
                con.Close();
                return obj;
            }
            else
            {
                con.Close();
                return null;
            }
        }

        public List<Employee> Search(string key)
        {
            SqlCommand com_search = new SqlCommand("p_search", con);
            com_search.CommandType = CommandType.StoredProcedure;
            com_search.Parameters.AddWithValue("@key", key);
            con.Open();
            SqlDataReader dr = com_search.ExecuteReader();
            List<Employee> list = new List<Employee>();
            while(dr.Read())
            {
                Employee e = new Employee();
                e.EmployeeID = dr.GetInt32(0);
                e.EmployeeName = dr.GetString(1);
                e.EmployeePassword = dr.GetString(2);
                e.EmployeeCity = dr.GetString(3);
                list.Add(e);
            }
            con.Close();
            return list;
        }

        public bool Login(int id,string password)
        {
            if(id<=0)
            {
                throw new Exception("Invalid ID");
            }
            SqlCommand com_login = new SqlCommand("p_login", con);
            com_login.CommandType = CommandType.StoredProcedure;
            com_login.Parameters.AddWithValue("@id", id);
            com_login.Parameters.AddWithValue("@psw", password);
            SqlParameter p_count = new SqlParameter();
            p_count.Direction = ParameterDirection.ReturnValue;
            com_login.Parameters.Add(p_count);

            try
            {
                con.Open();
                com_login.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(p_count.Value);
                if (count == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
                System.Windows.Forms.MessageBox.Show("Finally");
                if(con.State==ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public bool Update(int id,string name,string city)
        {
            SqlCommand com_update = new SqlCommand("p_update", con);
            com_update.CommandType = CommandType.StoredProcedure;
            com_update.Parameters.AddWithValue("@id", id);
            com_update.Parameters.AddWithValue("@name", name);
            com_update.Parameters.AddWithValue("@city", city);
            SqlParameter p_count = new SqlParameter();
            p_count.Direction = ParameterDirection.ReturnValue;
            com_update.Parameters.Add(p_count);
            con.Open();
            com_update.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(p_count.Value);
            if(count==1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool Delete(int id)
        {
            SqlCommand com_delete = new SqlCommand("p_delete", con);
            com_delete.CommandType = CommandType.StoredProcedure;
            com_delete.Parameters.AddWithValue("@id", id);
            SqlParameter p_count = new SqlParameter();
            p_count.Direction = ParameterDirection.ReturnValue;
            com_delete.Parameters.Add(p_count);
            con.Open();
            com_delete.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(p_count.Value);
            if(count==1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public string GetName(int id)
        {
            SqlCommand com_getname = new SqlCommand("p_getname", con);
            com_getname.CommandType = CommandType.StoredProcedure;
            com_getname.Parameters.AddWithValue("@id", id);
            con.Open();
            SqlDataReader dr = com_getname.ExecuteReader();
            if(dr.Read())
            {
                string name = dr.GetString(0);
                con.Close();
                return name;
            }         
            else
            {
                con.Close();
                return string.Empty;
            }
        }

        public List<int> GetEmployeesIDs()
        {
            SqlCommand com_ids = new SqlCommand("p_getids", con);
            com_ids.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_ids.ExecuteReader();
            List<int> ids = new List<int>();
            while(dr.Read())
            {
                int id = dr.GetInt32(0);
                ids.Add(id);
            }
            con.Close();
            return ids;
        }

    }
}
