﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ADO
{
    public partial class frm_SearchEmployee : Form
    {
        public frm_SearchEmployee()
        {
            InitializeComponent();
        }

        private void btn_searchemployeeid_Click(object sender, EventArgs e)
        {
            string key = txt_searchemployeeid.Text;
            if(key==string.Empty)
            {
                MessageBox.Show("Enter key");
            }
            else
            {
                EmployeesDAL dal = new EmployeesDAL();
                List<Employee> list = dal.Search(key);
                dgv_search.DataSource = list;
            }
        }

        private void dgv_search_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
