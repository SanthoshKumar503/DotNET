﻿namespace Win_ADO
{
    partial class frm_SearchEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_searchemployee = new System.Windows.Forms.Label();
            this.lbl_searchemployeeid = new System.Windows.Forms.Label();
            this.txt_searchemployeeid = new System.Windows.Forms.TextBox();
            this.btn_searchemployeeid = new System.Windows.Forms.Button();
            this.dgv_search = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_search)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_searchemployee
            // 
            this.lbl_searchemployee.AutoSize = true;
            this.lbl_searchemployee.Location = new System.Drawing.Point(257, 27);
            this.lbl_searchemployee.Name = "lbl_searchemployee";
            this.lbl_searchemployee.Size = new System.Drawing.Size(134, 20);
            this.lbl_searchemployee.TabIndex = 0;
            this.lbl_searchemployee.Text = "Search Employee";
            // 
            // lbl_searchemployeeid
            // 
            this.lbl_searchemployeeid.AutoSize = true;
            this.lbl_searchemployeeid.Location = new System.Drawing.Point(112, 115);
            this.lbl_searchemployeeid.Name = "lbl_searchemployeeid";
            this.lbl_searchemployeeid.Size = new System.Drawing.Size(151, 20);
            this.lbl_searchemployeeid.TabIndex = 1;
            this.lbl_searchemployeeid.Text = "Enter Employee ID :";
            // 
            // txt_searchemployeeid
            // 
            this.txt_searchemployeeid.Location = new System.Drawing.Point(269, 115);
            this.txt_searchemployeeid.Name = "txt_searchemployeeid";
            this.txt_searchemployeeid.Size = new System.Drawing.Size(195, 26);
            this.txt_searchemployeeid.TabIndex = 2;
            // 
            // btn_searchemployeeid
            // 
            this.btn_searchemployeeid.Location = new System.Drawing.Point(500, 115);
            this.btn_searchemployeeid.Name = "btn_searchemployeeid";
            this.btn_searchemployeeid.Size = new System.Drawing.Size(94, 26);
            this.btn_searchemployeeid.TabIndex = 3;
            this.btn_searchemployeeid.Text = "Search";
            this.btn_searchemployeeid.UseVisualStyleBackColor = true;
            this.btn_searchemployeeid.Click += new System.EventHandler(this.btn_searchemployeeid_Click);
            // 
            // dgv_search
            // 
            this.dgv_search.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_search.Location = new System.Drawing.Point(44, 224);
            this.dgv_search.Name = "dgv_search";
            this.dgv_search.RowTemplate.Height = 28;
            this.dgv_search.Size = new System.Drawing.Size(774, 341);
            this.dgv_search.TabIndex = 10;
            this.dgv_search.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_search_CellContentClick);
            // 
            // frm_SearchEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(851, 598);
            this.Controls.Add(this.dgv_search);
            this.Controls.Add(this.btn_searchemployeeid);
            this.Controls.Add(this.txt_searchemployeeid);
            this.Controls.Add(this.lbl_searchemployeeid);
            this.Controls.Add(this.lbl_searchemployee);
            this.Name = "frm_SearchEmployee";
            this.Text = "frm_SearchEmployee";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_search)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_searchemployee;
        private System.Windows.Forms.Label lbl_searchemployeeid;
        private System.Windows.Forms.TextBox txt_searchemployeeid;
        private System.Windows.Forms.Button btn_searchemployeeid;
        private System.Windows.Forms.DataGridView dgv_search;
    }
}