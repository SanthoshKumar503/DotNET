﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ADO
{
    public partial class frm_FindEmployee : Form
    {
        public frm_FindEmployee()
        {
            InitializeComponent();
        }

        private void cmb_findemployeeid_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void frm_FindEmployee_Load(object sender, EventArgs e)
        {
            EmployeesDAL dal = new EmployeesDAL();
            List<int> eids = dal.GetEmployeesIDs();
            foreach(int id in eids)
            {
                cmb_findemployeeid.Items.Add(id);
            }
        }

        private void btn_findemployeeid_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(cmb_findemployeeid.Text);
            EmployeesDAL dal = new EmployeesDAL();
            Employee obj = dal.FindEmployee(id);
            if(obj!=null)
            {
                txt_findname.Text = obj.EmployeeName;
                txt_findcity.Text = obj.EmployeeCity;
                txt_findpassword.Text = obj.EmployeePassword;
            }
            else
            {
                lbl_findstatus.Text = "Employee Not Found";
            }

        }

        private void btn_findupdate_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(cmb_findemployeeid.Text);
            string name = txt_findname.Text;
            string city = txt_findcity.Text;
            EmployeesDAL dal = new EmployeesDAL();
            bool status=dal.Update(id, name, city);
            if(status==true)
            {
                lbl_findstatus.Text = "Updated successful";
            }
            else
            {
                lbl_findstatus.Text = "Not updated";
            }
        }

        private void btn_finddelete_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(cmb_findemployeeid.Text);
            EmployeesDAL dal = new EmployeesDAL();
            bool status=dal.Delete(id);
            if(status==true)
            {
                lbl_findstatus.Text = "Deleted";
            }
            else
            {
                lbl_findstatus.Text = "Not deleted";
            }
        }
    }
}
