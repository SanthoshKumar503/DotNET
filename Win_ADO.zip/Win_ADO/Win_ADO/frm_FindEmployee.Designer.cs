﻿namespace Win_ADO
{
    partial class frm_FindEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_findemployeeid = new System.Windows.Forms.Label();
            this.lbl_findname = new System.Windows.Forms.Label();
            this.lbl_findpassword = new System.Windows.Forms.Label();
            this.lbl_findcity = new System.Windows.Forms.Label();
            this.cmb_findemployeeid = new System.Windows.Forms.ComboBox();
            this.btn_findemployeeid = new System.Windows.Forms.Button();
            this.txt_findname = new System.Windows.Forms.TextBox();
            this.txt_findpassword = new System.Windows.Forms.TextBox();
            this.txt_findcity = new System.Windows.Forms.TextBox();
            this.lbl_findemployee = new System.Windows.Forms.Label();
            this.lbl_findstatus = new System.Windows.Forms.Label();
            this.btn_findupdate = new System.Windows.Forms.Button();
            this.btn_finddelete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_findemployeeid
            // 
            this.lbl_findemployeeid.AutoSize = true;
            this.lbl_findemployeeid.Location = new System.Drawing.Point(102, 102);
            this.lbl_findemployeeid.Name = "lbl_findemployeeid";
            this.lbl_findemployeeid.Size = new System.Drawing.Size(151, 20);
            this.lbl_findemployeeid.TabIndex = 0;
            this.lbl_findemployeeid.Text = "Enter Employee ID :";
            // 
            // lbl_findname
            // 
            this.lbl_findname.AutoSize = true;
            this.lbl_findname.Location = new System.Drawing.Point(106, 170);
            this.lbl_findname.Name = "lbl_findname";
            this.lbl_findname.Size = new System.Drawing.Size(133, 20);
            this.lbl_findname.TabIndex = 1;
            this.lbl_findname.Text = "Employee Name :";
            // 
            // lbl_findpassword
            // 
            this.lbl_findpassword.AutoSize = true;
            this.lbl_findpassword.Location = new System.Drawing.Point(110, 219);
            this.lbl_findpassword.Name = "lbl_findpassword";
            this.lbl_findpassword.Size = new System.Drawing.Size(160, 20);
            this.lbl_findpassword.TabIndex = 2;
            this.lbl_findpassword.Text = "Employee Password :";
            // 
            // lbl_findcity
            // 
            this.lbl_findcity.AutoSize = true;
            this.lbl_findcity.Location = new System.Drawing.Point(114, 272);
            this.lbl_findcity.Name = "lbl_findcity";
            this.lbl_findcity.Size = new System.Drawing.Size(117, 20);
            this.lbl_findcity.TabIndex = 3;
            this.lbl_findcity.Text = "Employee City :";
            // 
            // cmb_findemployeeid
            // 
            this.cmb_findemployeeid.FormattingEnabled = true;
            this.cmb_findemployeeid.Location = new System.Drawing.Point(277, 102);
            this.cmb_findemployeeid.Name = "cmb_findemployeeid";
            this.cmb_findemployeeid.Size = new System.Drawing.Size(236, 28);
            this.cmb_findemployeeid.TabIndex = 4;
            this.cmb_findemployeeid.SelectedIndexChanged += new System.EventHandler(this.cmb_findemployeeid_SelectedIndexChanged);
            // 
            // btn_findemployeeid
            // 
            this.btn_findemployeeid.Location = new System.Drawing.Point(543, 102);
            this.btn_findemployeeid.Name = "btn_findemployeeid";
            this.btn_findemployeeid.Size = new System.Drawing.Size(75, 28);
            this.btn_findemployeeid.TabIndex = 5;
            this.btn_findemployeeid.Text = "Find";
            this.btn_findemployeeid.UseVisualStyleBackColor = true;
            this.btn_findemployeeid.Click += new System.EventHandler(this.btn_findemployeeid_Click);
            // 
            // txt_findname
            // 
            this.txt_findname.Location = new System.Drawing.Point(277, 170);
            this.txt_findname.Name = "txt_findname";
            this.txt_findname.Size = new System.Drawing.Size(236, 26);
            this.txt_findname.TabIndex = 6;
            // 
            // txt_findpassword
            // 
            this.txt_findpassword.Location = new System.Drawing.Point(277, 219);
            this.txt_findpassword.Name = "txt_findpassword";
            this.txt_findpassword.Size = new System.Drawing.Size(236, 26);
            this.txt_findpassword.TabIndex = 7;
            // 
            // txt_findcity
            // 
            this.txt_findcity.Location = new System.Drawing.Point(277, 272);
            this.txt_findcity.Name = "txt_findcity";
            this.txt_findcity.Size = new System.Drawing.Size(236, 26);
            this.txt_findcity.TabIndex = 8;
            // 
            // lbl_findemployee
            // 
            this.lbl_findemployee.AutoSize = true;
            this.lbl_findemployee.Location = new System.Drawing.Point(332, 35);
            this.lbl_findemployee.Name = "lbl_findemployee";
            this.lbl_findemployee.Size = new System.Drawing.Size(114, 20);
            this.lbl_findemployee.TabIndex = 9;
            this.lbl_findemployee.Text = "Find Employee";
            // 
            // lbl_findstatus
            // 
            this.lbl_findstatus.AutoSize = true;
            this.lbl_findstatus.Location = new System.Drawing.Point(194, 348);
            this.lbl_findstatus.Name = "lbl_findstatus";
            this.lbl_findstatus.Size = new System.Drawing.Size(138, 20);
            this.lbl_findstatus.TabIndex = 10;
            this.lbl_findstatus.Text = "Employee Status :";
            // 
            // btn_findupdate
            // 
            this.btn_findupdate.Location = new System.Drawing.Point(543, 181);
            this.btn_findupdate.Name = "btn_findupdate";
            this.btn_findupdate.Size = new System.Drawing.Size(75, 35);
            this.btn_findupdate.TabIndex = 11;
            this.btn_findupdate.Text = "Update";
            this.btn_findupdate.UseVisualStyleBackColor = true;
            this.btn_findupdate.Click += new System.EventHandler(this.btn_findupdate_Click);
            // 
            // btn_finddelete
            // 
            this.btn_finddelete.Location = new System.Drawing.Point(543, 243);
            this.btn_finddelete.Name = "btn_finddelete";
            this.btn_finddelete.Size = new System.Drawing.Size(75, 49);
            this.btn_finddelete.TabIndex = 12;
            this.btn_finddelete.Text = "Delete";
            this.btn_finddelete.UseVisualStyleBackColor = true;
            this.btn_finddelete.Click += new System.EventHandler(this.btn_finddelete_Click);
            // 
            // frm_FindEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 503);
            this.Controls.Add(this.btn_finddelete);
            this.Controls.Add(this.btn_findupdate);
            this.Controls.Add(this.lbl_findstatus);
            this.Controls.Add(this.lbl_findemployee);
            this.Controls.Add(this.txt_findcity);
            this.Controls.Add(this.txt_findpassword);
            this.Controls.Add(this.txt_findname);
            this.Controls.Add(this.btn_findemployeeid);
            this.Controls.Add(this.cmb_findemployeeid);
            this.Controls.Add(this.lbl_findcity);
            this.Controls.Add(this.lbl_findpassword);
            this.Controls.Add(this.lbl_findname);
            this.Controls.Add(this.lbl_findemployeeid);
            this.Name = "frm_FindEmployee";
            this.Text = "frm_FindEmployee";
            this.Load += new System.EventHandler(this.frm_FindEmployee_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_findemployeeid;
        private System.Windows.Forms.Label lbl_findname;
        private System.Windows.Forms.Label lbl_findpassword;
        private System.Windows.Forms.Label lbl_findcity;
        private System.Windows.Forms.ComboBox cmb_findemployeeid;
        private System.Windows.Forms.Button btn_findemployeeid;
        private System.Windows.Forms.TextBox txt_findname;
        private System.Windows.Forms.TextBox txt_findpassword;
        private System.Windows.Forms.TextBox txt_findcity;
        private System.Windows.Forms.Label lbl_findemployee;
        private System.Windows.Forms.Label lbl_findstatus;
        private System.Windows.Forms.Button btn_findupdate;
        private System.Windows.Forms.Button btn_finddelete;
    }
}