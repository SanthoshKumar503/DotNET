﻿namespace Win_ADO
{
    partial class frm_Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_homepage = new System.Windows.Forms.Label();
            this.lbl_homeid = new System.Windows.Forms.Label();
            this.lbl_homename = new System.Windows.Forms.Label();
            this.btn_homefindemployee = new System.Windows.Forms.Button();
            this.btn_homesearchemployee = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_homepage
            // 
            this.lbl_homepage.AutoSize = true;
            this.lbl_homepage.Location = new System.Drawing.Point(197, 40);
            this.lbl_homepage.Name = "lbl_homepage";
            this.lbl_homepage.Size = new System.Drawing.Size(322, 20);
            this.lbl_homepage.TabIndex = 0;
            this.lbl_homepage.Text = "Welcome to Employee Management System";
            // 
            // lbl_homeid
            // 
            this.lbl_homeid.AutoSize = true;
            this.lbl_homeid.Location = new System.Drawing.Point(197, 113);
            this.lbl_homeid.Name = "lbl_homeid";
            this.lbl_homeid.Size = new System.Drawing.Size(108, 20);
            this.lbl_homeid.TabIndex = 1;
            this.lbl_homeid.Text = "Employee ID :";
            // 
            // lbl_homename
            // 
            this.lbl_homename.AutoSize = true;
            this.lbl_homename.Location = new System.Drawing.Point(197, 157);
            this.lbl_homename.Name = "lbl_homename";
            this.lbl_homename.Size = new System.Drawing.Size(133, 20);
            this.lbl_homename.TabIndex = 2;
            this.lbl_homename.Text = "Employee Name :";
            // 
            // btn_homefindemployee
            // 
            this.btn_homefindemployee.Location = new System.Drawing.Point(169, 255);
            this.btn_homefindemployee.Name = "btn_homefindemployee";
            this.btn_homefindemployee.Size = new System.Drawing.Size(161, 49);
            this.btn_homefindemployee.TabIndex = 3;
            this.btn_homefindemployee.Text = "Find Employee";
            this.btn_homefindemployee.UseVisualStyleBackColor = true;
            this.btn_homefindemployee.Click += new System.EventHandler(this.btn_homefindemployee_Click);
            // 
            // btn_homesearchemployee
            // 
            this.btn_homesearchemployee.Location = new System.Drawing.Point(422, 255);
            this.btn_homesearchemployee.Name = "btn_homesearchemployee";
            this.btn_homesearchemployee.Size = new System.Drawing.Size(156, 49);
            this.btn_homesearchemployee.TabIndex = 4;
            this.btn_homesearchemployee.Text = "Search Employee";
            this.btn_homesearchemployee.UseVisualStyleBackColor = true;
            this.btn_homesearchemployee.Click += new System.EventHandler(this.btn_homesearchemployee_Click);
            // 
            // frm_Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(751, 502);
            this.Controls.Add(this.btn_homesearchemployee);
            this.Controls.Add(this.btn_homefindemployee);
            this.Controls.Add(this.lbl_homename);
            this.Controls.Add(this.lbl_homeid);
            this.Controls.Add(this.lbl_homepage);
            this.Name = "frm_Home";
            this.Text = "frm_Home";
            this.Load += new System.EventHandler(this.frm_Home_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_homepage;
        private System.Windows.Forms.Label lbl_homeid;
        private System.Windows.Forms.Label lbl_homename;
        private System.Windows.Forms.Button btn_homefindemployee;
        private System.Windows.Forms.Button btn_homesearchemployee;
    }
}