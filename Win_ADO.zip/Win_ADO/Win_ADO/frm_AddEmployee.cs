﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ADO
{
    public partial class frm_AddEmployee : Form
    {
        public frm_AddEmployee()
        {
            InitializeComponent();
        }

        private void btn_addemployee_Click(object sender, EventArgs e)
        {
            string name = txt_addname.Text;
            string psw = txt_addpassword.Text;
            string city = txt_addcity.Text;
            if(name==string.Empty)
            {
                lbl_findstatus.Text = "Enter Name";
            }
            else if(psw==string.Empty)
            {
                lbl_findstatus.Text = "Enter Password";
            }
            else if(city==string.Empty)
            {
                lbl_findstatus.Text = "Enter city";
            }
            else
            {
                Employee obj = new Employee();
                obj.EmployeeName = name;
                obj.EmployeePassword = psw;
                obj.EmployeeCity = city;
                EmployeesDAL dal = new EmployeesDAL();
                int id=dal.AddEmployee(obj);
                lbl_findstatus.Text = "Employee inserted and ID is :" + id;
            }

        }

        private void frm_AddEmployee_Load(object sender, EventArgs e)
        {

        }
    }
}
