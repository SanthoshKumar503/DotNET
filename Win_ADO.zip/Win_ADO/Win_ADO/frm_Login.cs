﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ADO
{
    public partial class frm_Login : Form
    {
        public static int EmployeeID;
        public frm_Login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            string id= txt_loginemployeeid.Text;
            string password = txt_loginemployeepassword.Text;
            if(id==string.Empty)
            {
                lbl_loginstatus.Text = "Enter Employee ID";
            }
            else if(password==string.Empty)
            {
                lbl_loginstatus.Text = "Enter Password";
            }
            else
            {
                try
                {
                    int eid = Convert.ToInt32(id);
                    EmployeesDAL dal = new EmployeesDAL();
                    bool status = dal.Login(eid, password);
                    if (status == true)
                    {
                        frm_Login.EmployeeID = eid;
                        MessageBox.Show("Valid user");
                        frm_Home obj = new frm_Home();
                        obj.Show();
                    }
                    else
                    {
                        lbl_loginstatus.Text = "Invalid ID or Password";
                    }
                }
                catch(NullReferenceException exp1)
                {
                    MessageBox.Show(exp1.Message);
                }
                catch(System.Data.SqlClient.SqlException exp2)
                {
                    MessageBox.Show(exp2.Message);
                }
                catch(Exception exp3)
                {
                    MessageBox.Show(exp3.Message);
                }
                finally
                {
                    MessageBox.Show("Finally 2");
                }
                MessageBox.Show("After fillay");
            }
        }

        private void btn_loginnewemployee_Click(object sender, EventArgs e)
        {
            frm_AddEmployee obj = new frm_AddEmployee();
            obj.Show();
        }

        private void frm_Login_Load(object sender, EventArgs e)
        {

        }
    }
}
