﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ADO
{
    public partial class frm_Home : Form
    {
        public frm_Home()
        {
            InitializeComponent();
        }

        private void btn_homefindemployee_Click(object sender, EventArgs e)
        {
            frm_FindEmployee obj = new frm_FindEmployee();
            obj.Show();
        }

        private void btn_homesearchemployee_Click(object sender, EventArgs e)
        {
            frm_SearchEmployee se = new frm_SearchEmployee();
            se.Show();
        }

        private void frm_Home_Load(object sender, EventArgs e)
        {
            lbl_homeid.Text += frm_Login.EmployeeID.ToString();
            EmployeesDAL dal = new EmployeesDAL();
            string name=dal.GetName(frm_Login.EmployeeID);
            lbl_homename.Text += name;
        }
    }
}
