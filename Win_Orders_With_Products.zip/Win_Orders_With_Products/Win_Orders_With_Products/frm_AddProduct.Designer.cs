﻿namespace Win_Orders_With_Products
{
    partial class frm_AddProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_addproducthome = new System.Windows.Forms.Label();
            this.lbl_addproductname = new System.Windows.Forms.Label();
            this.lbl_addproductprice = new System.Windows.Forms.Label();
            this.txt_addproductname = new System.Windows.Forms.TextBox();
            this.txt_addproductprice = new System.Windows.Forms.TextBox();
            this.btn_addproduct = new System.Windows.Forms.Button();
            this.lbl_addproductstatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_addproducthome
            // 
            this.lbl_addproducthome.AutoSize = true;
            this.lbl_addproducthome.Location = new System.Drawing.Point(279, 24);
            this.lbl_addproducthome.Name = "lbl_addproducthome";
            this.lbl_addproducthome.Size = new System.Drawing.Size(137, 20);
            this.lbl_addproducthome.TabIndex = 0;
            this.lbl_addproducthome.Text = "ADD PRODUCTS";
            // 
            // lbl_addproductname
            // 
            this.lbl_addproductname.AutoSize = true;
            this.lbl_addproductname.Location = new System.Drawing.Point(160, 121);
            this.lbl_addproductname.Name = "lbl_addproductname";
            this.lbl_addproductname.Size = new System.Drawing.Size(151, 20);
            this.lbl_addproductname.TabIndex = 1;
            this.lbl_addproductname.Text = "Add Product Name :";
            // 
            // lbl_addproductprice
            // 
            this.lbl_addproductprice.AutoSize = true;
            this.lbl_addproductprice.Location = new System.Drawing.Point(164, 201);
            this.lbl_addproductprice.Name = "lbl_addproductprice";
            this.lbl_addproductprice.Size = new System.Drawing.Size(144, 20);
            this.lbl_addproductprice.TabIndex = 2;
            this.lbl_addproductprice.Text = "Add Product Price :";
            // 
            // txt_addproductname
            // 
            this.txt_addproductname.Location = new System.Drawing.Point(371, 121);
            this.txt_addproductname.Name = "txt_addproductname";
            this.txt_addproductname.Size = new System.Drawing.Size(257, 26);
            this.txt_addproductname.TabIndex = 3;
            // 
            // txt_addproductprice
            // 
            this.txt_addproductprice.Location = new System.Drawing.Point(371, 201);
            this.txt_addproductprice.Name = "txt_addproductprice";
            this.txt_addproductprice.Size = new System.Drawing.Size(257, 26);
            this.txt_addproductprice.TabIndex = 4;
            // 
            // btn_addproduct
            // 
            this.btn_addproduct.Location = new System.Drawing.Point(409, 291);
            this.btn_addproduct.Name = "btn_addproduct";
            this.btn_addproduct.Size = new System.Drawing.Size(146, 36);
            this.btn_addproduct.TabIndex = 5;
            this.btn_addproduct.Text = "Add Product";
            this.btn_addproduct.UseVisualStyleBackColor = true;
            this.btn_addproduct.Click += new System.EventHandler(this.btn_addproduct_Click);
            // 
            // lbl_addproductstatus
            // 
            this.lbl_addproductstatus.AutoSize = true;
            this.lbl_addproductstatus.Location = new System.Drawing.Point(409, 444);
            this.lbl_addproductstatus.Name = "lbl_addproductstatus";
            this.lbl_addproductstatus.Size = new System.Drawing.Size(64, 20);
            this.lbl_addproductstatus.TabIndex = 6;
            this.lbl_addproductstatus.Text = "Status :";
            // 
            // frm_AddProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 575);
            this.Controls.Add(this.lbl_addproductstatus);
            this.Controls.Add(this.btn_addproduct);
            this.Controls.Add(this.txt_addproductprice);
            this.Controls.Add(this.txt_addproductname);
            this.Controls.Add(this.lbl_addproductprice);
            this.Controls.Add(this.lbl_addproductname);
            this.Controls.Add(this.lbl_addproducthome);
            this.Name = "frm_AddProduct";
            this.Text = "frm_AddProduct";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_addproducthome;
        private System.Windows.Forms.Label lbl_addproductname;
        private System.Windows.Forms.Label lbl_addproductprice;
        private System.Windows.Forms.TextBox txt_addproductname;
        private System.Windows.Forms.TextBox txt_addproductprice;
        private System.Windows.Forms.Button btn_addproduct;
        private System.Windows.Forms.Label lbl_addproductstatus;
    }
}