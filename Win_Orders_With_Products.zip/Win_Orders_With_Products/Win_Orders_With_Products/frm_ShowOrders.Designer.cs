﻿namespace Win_Orders_With_Products
{
    partial class frm_ShowOrders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_showorders = new System.Windows.Forms.Label();
            this.lbl_showemailid = new System.Windows.Forms.Label();
            this.txt_showemailid = new System.Windows.Forms.TextBox();
            this.btn_showemailid = new System.Windows.Forms.Button();
            this.dgv_showorders = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_showorders)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_showorders
            // 
            this.lbl_showorders.AutoSize = true;
            this.lbl_showorders.Location = new System.Drawing.Point(344, 25);
            this.lbl_showorders.Name = "lbl_showorders";
            this.lbl_showorders.Size = new System.Drawing.Size(79, 20);
            this.lbl_showorders.TabIndex = 0;
            this.lbl_showorders.Text = "ORDERS";
            // 
            // lbl_showemailid
            // 
            this.lbl_showemailid.AutoSize = true;
            this.lbl_showemailid.Location = new System.Drawing.Point(111, 111);
            this.lbl_showemailid.Name = "lbl_showemailid";
            this.lbl_showemailid.Size = new System.Drawing.Size(120, 20);
            this.lbl_showemailid.TabIndex = 1;
            this.lbl_showemailid.Text = "Enter Email ID :";
            // 
            // txt_showemailid
            // 
            this.txt_showemailid.Location = new System.Drawing.Point(262, 111);
            this.txt_showemailid.Name = "txt_showemailid";
            this.txt_showemailid.Size = new System.Drawing.Size(247, 26);
            this.txt_showemailid.TabIndex = 2;
            // 
            // btn_showemailid
            // 
            this.btn_showemailid.Location = new System.Drawing.Point(589, 103);
            this.btn_showemailid.Name = "btn_showemailid";
            this.btn_showemailid.Size = new System.Drawing.Size(106, 39);
            this.btn_showemailid.TabIndex = 3;
            this.btn_showemailid.Text = "Search";
            this.btn_showemailid.UseVisualStyleBackColor = true;
            this.btn_showemailid.Click += new System.EventHandler(this.btn_showemailid_Click);
            // 
            // dgv_showorders
            // 
            this.dgv_showorders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_showorders.Location = new System.Drawing.Point(13, 197);
            this.dgv_showorders.Name = "dgv_showorders";
            this.dgv_showorders.RowTemplate.Height = 28;
            this.dgv_showorders.Size = new System.Drawing.Size(762, 393);
            this.dgv_showorders.TabIndex = 4;
            // 
            // frm_ShowOrders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(787, 602);
            this.Controls.Add(this.dgv_showorders);
            this.Controls.Add(this.btn_showemailid);
            this.Controls.Add(this.txt_showemailid);
            this.Controls.Add(this.lbl_showemailid);
            this.Controls.Add(this.lbl_showorders);
            this.Name = "frm_ShowOrders";
            this.Text = "frm_ShowOrders";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_showorders)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_showorders;
        private System.Windows.Forms.Label lbl_showemailid;
        private System.Windows.Forms.TextBox txt_showemailid;
        private System.Windows.Forms.Button btn_showemailid;
        private System.Windows.Forms.DataGridView dgv_showorders;
    }
}