﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overriding
{
    class Trainee : Employee
    {
        public Trainee(string EmployeeName, double EmployeeBasicSalary):base(EmployeeName,EmployeeBasicSalary)
        {
            this.EmployeeBasicSalary = 1000;
        }

        public override double getSalary(double days)
        {
            return this.EmployeeBasicSalary;
        }
    }
}
