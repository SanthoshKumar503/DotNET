﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overriding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the employee name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the employee basic salary");
            double salary = Convert.ToInt64(Console.ReadLine());
            Employee e=null;

            Console.WriteLine("Enter Emplyee type");
            string type = Console.ReadLine();

            if(type=="Employee")
            {
                e = new Employee(name, salary);
            }
            else if(type=="Contract")
            {
                e = new EmployeeContract(name, salary);
            }
            else if(type=="Trainee")
            {
                e = new Trainee(name, salary);
            }
            if (e != null)
            {
                Console.WriteLine("Employee ID:" + e.PEmployeeId);
                Console.WriteLine("Employee Name:" + e.PEmployeeName);

                string details = e.getDetails();
                Console.WriteLine("Employee derails:" + details);

                string work = e.getWork();
                Console.WriteLine("Work is:" + work);

                Console.WriteLine("Enter No.Of days");
                double days = Convert.ToDouble(Console.ReadLine());
                double monthSalary = e.getSalary(days);
                Console.WriteLine("Month salary is:" + monthSalary);
            }
            else
            {
                Console.WriteLine("Invalid Type");
            }

            Console.ReadLine();
        }
    }
}
