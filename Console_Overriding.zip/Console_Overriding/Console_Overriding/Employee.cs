﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overriding
{
    class Employee
    {
        private int EmployeeId;
        private string EmployeeName;
        protected double EmployeeBasicSalary;
        private static int count = 1000;
        public Employee(string EmployeeName,double EmployeeBasicSalary)
        {
            this.EmployeeName = EmployeeName;
            this.EmployeeBasicSalary = EmployeeBasicSalary;
            this.EmployeeId = ++Employee.count;
        }       
        public int PEmployeeId
        {
            get
            {
                return this.EmployeeId;
            }
        }
        public string PEmployeeName
        {
            get
            {
                return this.EmployeeName;
            }
            set
            {
                if(value!=" ")
                {
                    this.EmployeeName = value;
                }
            }
        }
        public string getWork()
        {
            return "C# Developer";
        }
        public string getDetails()
        {
            return this.EmployeeId + "," + this.EmployeeName;
        }
        public virtual double getSalary(double days)
        {
            double bouns = 2000;
            double tds = 1000;
            double total = (this.EmployeeBasicSalary / 30 * days) + bouns - tds;
            return total;
        }
    }
}
