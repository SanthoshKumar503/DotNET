﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overriding
{
    class EmployeeContract : Employee
    {
        public EmployeeContract(string EmployeeName, double EmployeeBasicSalary)
            :base(EmployeeName,EmployeeBasicSalary)
        {
            Console.WriteLine("Employee Contract constructor is created");
        }
        public override double getSalary(double days)
        {
            double total = (this.EmployeeBasicSalary / 30 * days) - 1000 ;
            return total;
        }
    }
}
