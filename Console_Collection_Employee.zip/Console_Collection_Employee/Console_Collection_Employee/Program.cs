﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Collection_Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            Company c = new Company("Pathfront","Bangalore");
            bool flag = true;
            while(flag)
            {
                Console.WriteLine("1-AddEmployee\t2-SearchEmployee\t3-RemoveEmployee\n4-ShowEmployee\t5-RequestLeave\t6-Exit");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        {
                            Console.WriteLine("Enter Employee Name:");
                            string name = Console.ReadLine();
                            Console.WriteLine("Enter Employee city");
                            string city = Console.ReadLine();
                            Employee e = new Employee(name, city);
                            c.AddEmployee(e);
                            Console.WriteLine("Employee Added and ID:" + e.PEmployeeID);
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("Enter the Employee id:");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Employee e = c.SearchEmployee(id);
                            if (e != null)
                            {
                                Console.WriteLine(e.ToString());
                            }
                            else
                            {
                                Console.WriteLine("Employee not found");
                            }
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("Enter the employee ID");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Employee e=c.SearchEmployee(id);  
                            if(e!=null)
                            {
                                c.RemoveEmployee(id);
                                Console.WriteLine("Employee Removed");
                            }  
                            else
                            {
                                Console.WriteLine("Employee Not Found");
                            }                        
                            break;
                        }
                    case 4:
                        {
                            c.ShowEmployees();
                            break;
                        }
                    case 5:
                        {
                            Console.WriteLine("Enter Employee ID");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Employee e = c.SearchEmployee(id);
                            if (e!=null)
                            {
                                Console.WriteLine("Enter reason");
                                string r = Console.ReadLine();
                                e.RequestLeave(r);
                                Console.WriteLine(r);
                            }
                            else
                            {
                                Console.WriteLine("Employee Not Found");
                            }

                            break;
                    
                         }
                    case 6:
                        {
                            flag = false;
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Invalid Choice");
                            break;
                        }
                }
         }
            Console.ReadLine();
        }
    }
}
