﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Collection_Employee
{
    class Employee
    {
        public delegate void del_leave(int empid, string msg);
        public event del_leave evt_leaveemp;

        private int EmployeeID;
        private string EmployeeName;
        private string EmployeeCity;
        public static int count = 1000;
        public Employee(string EmployeeName,string EmployeeCity)
        {
            this.EmployeeID=++Employee.count;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
        }
        public int PEmployeeID
        {
            get
            {
                return this.EmployeeID;
            }
        }
        public string PEmployeeName
        {
            get
            {
                return this.EmployeeName;
            }
        }
        public string PEmployeeCity
        {
            get
            {
                return this.EmployeeCity;
            }
        }
        public override string ToString()
        {
            return this.EmployeeID + " " + this.EmployeeName + " " + this.PEmployeeCity;
        }
        public void RequestLeave(string reason)
        {
            Console.WriteLine( "Employee Id" + this.EmployeeID + " Reason of leave:" + reason);
            if(this.evt_leaveemp!=null)
            {
                this.evt_leaveemp(this.EmployeeID, reason);
            }
        }
    }
}
