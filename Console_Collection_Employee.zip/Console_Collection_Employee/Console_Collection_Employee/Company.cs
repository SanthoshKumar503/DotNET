﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Collection_Employee
{
    class Company
    {
        public void TakeLeave(int empid, string msg)
        {
            Console.WriteLine("Company: Employee leave, Id:" + empid + " reason:" + msg);
        }
        private string CompanyName;
        private string CompanyCity;
        public Company(string CompanyName,string CompanyCity)
        {
            this.CompanyName = CompanyName;
            this.CompanyCity = CompanyCity;
        }
        List<Employee> list = new List<Employee>();
        public void AddEmployee(Employee e)
        {
            list.Add(e);
            e.evt_leaveemp += new Employee.del_leave(this.TakeLeave);
        }
        public Employee SearchEmployee(int id)
        {
            foreach (Employee i in list)
            {
                if (i.PEmployeeID == id)
                {
                    return i;
                }
            }
            return null;
        }
        public bool RemoveEmployee(int id)
        {
            foreach(Employee i in list)
            {
                if(i.PEmployeeID==id)
                {
                    list.Remove(i);
                    return true;
                }
            }
            return false;
        }
        public void ShowEmployees()
        {
            foreach(Employee e in list)
            {
                Console.WriteLine(e);
            }
        }

        
    }
}
