﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Book_Management
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the book title");
            string title = Console.ReadLine();
            Console.WriteLine("Enter the author name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the book price");
            int price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the book pages");
            int pages = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine("\tBook Class");
            Book b = new Book(title, name, price, pages);

            int r1=b.PBookId;
            Console.WriteLine("Book ID is:" + r1);
            string s1 = b.PBookTitle;
            Console.WriteLine("Book title is:" + s1);
            string s2 = b.PBookAuthor;
            Console.WriteLine("Book author is:" + s2);
            int r2 = b.PBookPrice;
            Console.WriteLine("Book price is:" + r2);
            int r3 = b.PBookPages;
            Console.WriteLine("Book pages is:" + r3);

            Console.WriteLine("\tEBook Class");
            Console.WriteLine("Enter the book title");
            title = Console.ReadLine();
            Console.WriteLine("Enter the author name");
            name = Console.ReadLine();
            Console.WriteLine("Enter the book price");
            price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the book pages");
            pages = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the ebook size");
            int size = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("Enter the ebook format");
            string format = Console.ReadLine();

            Ebook e = new Ebook(title,name,price,pages,size,format);

            r1 = e.PBookId;
            Console.WriteLine("EBook ID is:" + r1);
            s1 = e.PBookTitle;
            Console.WriteLine("EBook title is:" + s1);
            s2 = e.PBookAuthor;
            Console.WriteLine("EBook author is:" + s2);
            r2 = e.PBookPrice;
            Console.WriteLine("EBook price is:" + r2);
            r3 = e.PBookPages;
            Console.WriteLine("EBook pages is:" + r3);
            int r4 = e.PBookSize;
            Console.WriteLine("EBook pages is:" + r4);
            string s3 = e.PBookFormat;
            Console.WriteLine("EBook pages is:" + s3);


            Console.ReadLine();
        }
    }
}
