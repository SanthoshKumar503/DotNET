﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic
{
    class Test
    {
        public T Call<T>(T para)
        {
            return para;
        }
    }
}
