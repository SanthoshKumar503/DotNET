﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> names = new Dictionary<int, string>();
            names.Add(101, "smith");
            names.Add(80, "John");

            if(names.ContainsKey(101))
            {
                string s2 = names[101];
                Console.WriteLine(s2);
            }
            Console.WriteLine(names.Count);
            //names.Remove(101);
            Console.WriteLine(names.Count);
            Console.WriteLine("----KeyValuePair----");
            foreach(KeyValuePair<int,string> kv in names )
            {
                Console.WriteLine("Keys :" + kv.Key + " ,Value:" + kv.Value);
            }
            Console.WriteLine("----Keys----");
            foreach(int k in names.Keys)
            {
                Console.WriteLine("Keys:" + k);
            }
            Console.WriteLine("----Values----");
            foreach(string v in names.Values )
            {
                Console.WriteLine("Values:" + v);
            }

            /*
            List<string> names = new List<string>();
            names.Add("san");
            names.Add("kmr");
            names.Add("ram");
            names.Add("viv");

            int c = names.Count;
            Console.WriteLine("size:" + c);
            for(int i=0;i<c;i++)
            {
                Console.WriteLine(names[i]);
            }

            /*
            List<int> marks = new List<int>();
            marks.Add(88);
            marks.Add(78);
            marks.Add(54);
            marks.Add(90);

            int c = marks.Count;
            Console.WriteLine("Size of marks:"+c);
            int x = marks[1];
            Console.WriteLine("Value at 1:"+x);
            Console.WriteLine("+++++For+++++");
            for(int i=0;i<marks.Count;i++)
            {
                Console.WriteLine(marks[i]);
            }
            Console.WriteLine("+++++ForEach+++++");
            marks.Remove(54);
            marks.RemoveAt(0);
            foreach(int m in marks)
            {
                Console.WriteLine(m);
            }

            /*
            Test t = new Test();
            int x = t.Call<int>(100);
            string s = t.Call<string>("abc");
            Console.WriteLine(x);
            Console.WriteLine(s);
            */
            /*
            Test2<int> t = new Test2<int>();
            int c1=t.Call(10);
            t.Call2(20);
            Console.WriteLine(c1);

            Test2<string> t2 = new Test2<string>();
            string s = t2.Call("san");
            t2.Call2("hello");
            Console.WriteLine(s);
            */

            Console.ReadLine();
        }
    }
}
