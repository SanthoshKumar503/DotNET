﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic
{
    class Test3
    {
        public IEnumerable<int> GetMarks()
        {
            for(int i=0;i<10;i++)
            {
                yield return i;
            }
        }
    }
}
