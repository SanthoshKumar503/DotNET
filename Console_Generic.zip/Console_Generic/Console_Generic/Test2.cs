﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Generic
{
    class Test2<T>
    {
        public T Call(T p)
        {
            return p;
        }
        public void Call2(T p)
        {

        }
    }
}
