﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Salary_Calculation
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter number of days");
            int days = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter one day salary");
            int sal = Convert.ToInt32(Console.ReadLine());
            SalaryLibrary.Salarycls obj = new SalaryLibrary.Salarycls();
           int res= obj.GetSalry(days, sal);
            Console.WriteLine("Total salary:" + res);
            Console.ReadLine();

        }
    }
}
