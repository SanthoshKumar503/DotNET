﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstrsct_Class
{
    class Current : Account
    {
        public Current(int AccountId,string CustomerName,int AccountBalance)
            :base(AccountId,CustomerName,AccountBalance)
        {
            Console.WriteLine("Curret account");
        }

        public override void Deposit(int amount)
        {
            this.AccountBalance = this.AccountBalance + amount;
        }

        public override void Withdraw(int amount)
        {
            this.AccountBalance = this.AccountBalance - amount;
        }
    }
}
