﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstrsct_Class
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter account ID:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the customer name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the Account balance");
            int balance = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the account type");
            string type = Console.ReadLine();

            Account obj = null;

            if(type=="saving")
            {
                obj = new Saving(id,name,balance);
            }
            else if(type=="current")
            {
                obj = new Current(id, name, balance);
            }

            if(obj!=null)
            {
                Console.WriteLine("Account ID:" + obj.PAccountId);
                Console.WriteLine("Customer Name:" + obj.PCustomerName);
                int bal = obj.GetBalance();
                Console.WriteLine("Balance is:" + bal);
                Console.WriteLine("Enter amount to deposit");
                int amt = Convert.ToInt32(Console.ReadLine());
                obj.Deposit(amt);
                bal = obj.GetBalance();
                Console.WriteLine("Account balance" + bal);
                Console.WriteLine("Enter amount to withdraw");
                amt = Convert.ToInt32(Console.ReadLine());
                obj.Withdraw(amt);
                bal = obj.GetBalance();
                Console.WriteLine("Account balance:" + bal);
                obj.StopPayment();
                obj.BlockAccount();
            }
            Console.ReadLine();
        }
    }
}
