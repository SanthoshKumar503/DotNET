﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstrsct_Class
{
    abstract class Account
    {
        private int AccountId;
        private string CustomerName;
        protected int AccountBalance;
        public Account(int AccountId,string CustomerName,int AccountBalance)
        {
            this.AccountId = AccountId;
            this.AccountBalance = AccountBalance;
            this.CustomerName = CustomerName;
            Console.WriteLine("Account class object created");
        }
        public int PAccountId
        {
            get
            {
                return this.AccountId;
            }

        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
       
        public int GetBalance()
        {
            return this.AccountBalance;
        }
        public void StopPayment()
        {
            Console.WriteLine("Payment stopped");
        }
        public void BlockAccount()
        {
            Console.WriteLine("Account blocked");
        }
        public abstract void Withdraw(int amount);
        public abstract void Deposit(int amount);

    }
}
