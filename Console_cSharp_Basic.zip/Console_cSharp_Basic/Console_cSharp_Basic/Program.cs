﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_cSharp_Basic
{
    class Program
    {

       
        static void Main(string[] args)
        {
            /*
            /*
            const int n = 100;
           // n = 200;
            Console.WriteLine(n);
        */
            /*
            int i= 100;
            if(i>=0 && i<=100)
                {
                    Console.WriteLine("Valid");
                }
                else
                {
                    Console.WriteLine("Invalid");
                }
                */
            /*
        int c = 0;
        while(c<10)
        {
            Console.WriteLine(c);
            c++;
        }
            */
            /*
            for(int i=0;i<10;i++)
            {
                Console.WriteLine(i);
            }
            */

            /*
            int ch = 1;
            switch(ch)
            {
                case 0:
                    {
                        Console.WriteLine("Case zero");
                        break;
                    }
                case 1:
                    {
                        Console.WriteLine("Case one");
                        break;
                    }
                default:
                    {
                        Console.WriteLine("Default");
                        break;
                    }
            }
            */
            /*
        int[] marks = { 81, 72, 63, 54, 45 };
        int[] mr = new int[5];
        mr[0] = 56;
        mr[1] = 76;
        mr[2] = 67;
        mr[3] = 48;
        mr[4] = 50;

       // int i = mr[2];
        //Console.WriteLine(i);

        int count = mr.Length;
        //Console.WriteLine("Length of thr array"+count);
        /*
        for(int c=0;c<count;c++)
        {
            Console.WriteLine(mr[c]);
        }
        */
            /*
            foreach(int m in mr)
            {
                Console.WriteLine(m);
            }

            /*
            int max = mr[0];
            for(int j=0;j<count;j++)
            {
                if(mr[j]>max)
                {
                    max = mr[j];
                }
            }
            Console.WriteLine("Minimum Value is:"+max);

            int min = mr[0];
            for (int j = 0; j < count; j++)
            {
                if (mr[j] < min)
                {
                    min = mr[j];
                }
            }
            Console.WriteLine("Minimum Value is:" + min);
            */
            /*
            Console.WriteLine("After swapping");
            int temp;
            temp = mr[0];
            mr[0] = mr[count - 1];
            mr[count - 1] = temp;
            foreach (int m in mr)
            {
                Console.WriteLine(m);
            }
            */
            /*
            string str = "hello world hi";
            char[] ch = str.ToCharArray();
            int c = 0;
            for(int i=0;i<ch.Length;i++)
            {
                if (ch[i] == ' ')
                    c++;
            }
            c = c + 1;
            Console.WriteLine("Number of words is:" + c);
            */

            
        }
    }
}
