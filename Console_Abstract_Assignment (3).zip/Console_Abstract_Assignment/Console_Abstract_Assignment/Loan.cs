﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Assignment
{
    abstract class Loan
    {
        private int LoanID;
        private string CustomerName;
        private string CustomerEmailId;
        private string MobileNo;
        private int LoanAmount;
        private int Duration;
        private int Rate;
        private static int count;
        public Loan(string CustomerName,string CustomerEmailId,string MobileNo,int LoanAmount,int Duration,int Rate)
        {
            this.CustomerName = CustomerName;
            this.CustomerEmailId = CustomerEmailId;
            this.LoanID = ++Loan.count;
            this.MobileNo = MobileNo;
            this.LoanAmount = LoanAmount;
            this.Duration = Duration;
            this.Rate = Rate;
        }
        public int PLoanId
        {
            get
            {
                return this.LoanID;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public string PCustomerEmailId
        {
            get
            {
                return this.CustomerEmailId;
            }
        }
        public string PMobileNo
        {
            get
            {
                return this.MobileNo;
            }
        }
        public int PLoanAmount
        {
            get
            {
                return this.LoanAmount;
            }
            set
            {
                this.LoanAmount = value;
            }
        }
        public int PDuration
        {
            get
            {
                return this.Duration;
            }
        }
        public int PRate
        {
            get
            {
                return this.Rate;
            }
        }
        public abstract double PayEMI(int amt);
        public abstract double PendingLoan();

    }
}
