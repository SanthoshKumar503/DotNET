﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_CSharp_OOP2
{
    class Employee
    {
        public static int count;
        public int EmployeeId;
        static Employee()
        {
            int a = 100;
            int b = 200;
            Employee.count = a + b;
            Console.WriteLine("Static Constuctor");
        }
        public static void call()
        {
            Console.WriteLine("Static call");
        }
    }
}
