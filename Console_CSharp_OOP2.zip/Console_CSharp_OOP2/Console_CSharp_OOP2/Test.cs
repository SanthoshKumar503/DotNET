﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_CSharp_OOP2
{
    class Test
    {

        public void Add(ref int n)
        {
            n = n + 2000;
        }
        public void Sum(out int s)
        {
            s = 2000;
        }
        /*
        public int Add(int n1,int n2)
        {
            return n1 + n2;
        }
        public double Add(double d1,double d2)
        {
            return d1 + d2;
        }
        public int Add(int x)
        {
            return x++;
        }
        public string Add(string s1,string s2)
        {
            return s1 + s2;
        }
        public double Add(double d,int n)
        {
            return d + n;
        }
        */

    }
}
