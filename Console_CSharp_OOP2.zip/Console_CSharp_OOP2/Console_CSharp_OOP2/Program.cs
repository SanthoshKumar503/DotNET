﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_CSharp_OOP2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Employee.count);
            Employee.count = 1;
            Console.WriteLine(Employee.count);
            Employee.count = 2000;
            Console.WriteLine(Employee.count);
            Employee.call();
            /*

            XYZ obj = new XYZ();
            obj.
            /*
            Test t = new Test();
            int n1 = 50;
            int n2;
            t.Add(ref n1);
            Console.WriteLine(n1);
            t.Sum(out n2);
            Console.WriteLine(n2);
            /*
            int n2 = 100;
            double d1 = 75.98;
            double d2 = 87.67;
            string s1 = "one";
            string s2 = "two";

            int r1=t.Add(n1);
            Console.WriteLine(r1);
            double r2=t.Add(d1, d2);
            Console.WriteLine(r2);
            double r3=t.Add(d1, n1);
            Console.WriteLine(r3);
            double r4=t.Add(n2, d2);
            Console.WriteLine(r4);
            string r5=t.Add(s1, s2);
            Console.WriteLine(r5);
            int r6=t.Add(n1, n2);
            Console.WriteLine(r6);
            */
            Console.ReadLine();
        }
    }
}
