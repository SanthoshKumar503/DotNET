﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Properties
{
    class Program
    {
        static void Main(string[] args)
        {
            Student obj = new Student("John", 65);
            int id = obj.PStudentId;
            Console.WriteLine(id);


            string name = obj.PStudentName;
            Console.WriteLine(name);
            obj.PStudentName = "San";
            name = obj.PStudentName;
            Console.WriteLine(name);
            Console.ReadLine();

            int marks = obj.PStudentMarks;
            Console.WriteLine(marks);
            obj.PStudentMarks = 100;
            marks = obj.PStudentMarks;
            Console.WriteLine(marks);
            obj.PStudentMarks = 200;
            marks = obj.PStudentMarks;
            Console.WriteLine(marks);
        }
    }
}
