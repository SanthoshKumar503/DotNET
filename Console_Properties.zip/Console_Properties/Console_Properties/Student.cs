﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Properties
{
    class Student
    {
        private int StudentId;
        private string StudentName;
        private int StudentMarks;
        private static int count = 1000;
        public Student(string StudentName,int StudentMarks)
        {
            this.StudentName = StudentName;
            this.StudentMarks = StudentMarks;
            this.StudentId = ++Student.count;
        }

        public int PStudentId
        {
            get
            {
                return StudentId;
            }
        }
        public string PStudentName
        {
            get
            {
                return StudentName;
            }
            set
            {
                if(value.Length>0)
                this.StudentName = value;
            }
        }
        public int PStudentMarks
        {
            get
            {
                return this.StudentMarks;
            }
            set
            {
                if(value>=0 && value<=100)
                {
                    this.StudentMarks = value;
                }
            }
        }

    }
}
