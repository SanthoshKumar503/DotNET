﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day1_Prime_not_prgm2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number");
            int num = Convert.ToInt32(Console.ReadLine());
            int c = 0;
            for(int i=1;i<num/2;i++)
            {
                if(num%i==0)
                {
                    c++;
                }
            }
            if(c==1)
            {
                Console.WriteLine("Given Number is prime number");
            }
            else
            {
                Console.WriteLine("Given number is not a prime number");
            }
            Console.ReadLine();
        }
    }
}
