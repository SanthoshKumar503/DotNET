﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Basics
{
    class Customer
    {
        private string CustomerName;
        private readonly int AccountId;
        private double AccountBalance;
        private string CustomerCity;

        public Customer()
        {
            Console.WriteLine("Default Constructor called");
        }
        public Customer(string CustomerName,int AccountId,double AccountBalance,string CustomerCity):this()//calling constructor
        {
            this.CustomerName = CustomerName;
            this.AccountId = AccountId;
            this.AccountBalance = AccountBalance;
            this.CustomerCity = CustomerCity;
            Console.WriteLine("Constructor called");
        }
        public bool WithDraw(double Amt)
        {
            if (this.AccountBalance >= Amt)
            {
                this.AccountBalance = this.AccountBalance - Amt;
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool Deposit(double Amt)
        {
            if(Amt>0)
            {
                this.AccountBalance = this.AccountBalance + Amt;
                return true;
            }
            else
            {
                return false;
            }
        }
        public double GetBalance()
        {
            return this.AccountBalance;
        }
        public string GetDetails()
        {
            return this.CustomerName + ", " + this.CustomerCity;
        }
        public int GetAccountId()
        {
            return this.AccountId;
        }
    }
}
