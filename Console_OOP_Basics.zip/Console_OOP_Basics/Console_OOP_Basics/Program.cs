﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP_Basics
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter your Account id");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter your Account balance");
            double bal = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter your city");
            string city = Console.ReadLine();

            Customer obj = new Customer(name,id,bal,city);

            Console.WriteLine("Enter deposit amount");
            double dep = Convert.ToDouble(Console.ReadLine());
            bool status=obj.Deposit(dep);
            if(status==true)
            {
                Console.WriteLine("Amount deposited");
            }
            else
            {
                Console.WriteLine("Withdraw Failed");
            }

            Console.WriteLine("Enter withdraw amount");
            double withdraw = Convert.ToDouble(Console.ReadLine());
            status=obj.WithDraw(withdraw);
            if(status==true)
            {
                Console.WriteLine("Withdraw successful");
            }
            else
            {
                Console.WriteLine("Withdraw Failed");
            }

            Console.WriteLine("Your balance is:");
            double res=obj.GetBalance();
            Console.WriteLine(res);

            Console.WriteLine("Your Details are:");
            string details = obj.GetDetails();
            Console.WriteLine(details);

            Console.WriteLine("Your Account id is:");
            int acc = obj.GetAccountId();
            Console.WriteLine(acc);


            Console.ReadLine();
        }
    }
}
