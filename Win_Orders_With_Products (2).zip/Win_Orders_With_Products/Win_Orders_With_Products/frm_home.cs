﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Orders_With_Products
{
    public partial class frm_home : Form
    {
        public frm_home()
        {
            InitializeComponent();
        }

        private void btn_addproduct_Click(object sender, EventArgs e)
        {
            frm_AddProduct p = new frm_AddProduct();
            p.Show();
        }

        private void btn_addorders_Click(object sender, EventArgs e)
        {
            frm_AddOrders o = new frm_AddOrders();
            o.Show();
        }

        private void btn_showorders_Click(object sender, EventArgs e)
        {
            frm_ShowOrders s = new frm_ShowOrders();
            s.Show();
        }
    }
}
