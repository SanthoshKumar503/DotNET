﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Orders_With_Products
{
    public partial class frm_AddProduct : Form
    {
        public frm_AddProduct()
        {
            InitializeComponent();
        }

        private void btn_addproduct_Click(object sender, EventArgs e)
        {
            string name = txt_addproductname.Text;
            string price = txt_addproductprice.Text;
            if(name==string.Empty)
            {
                lbl_addproductstatus.Text = "Enter Product Name";
            }
            else if(price==string.Empty)
            {
                lbl_addproductstatus.Text = "Enter Product Price";
            }
            else
            {
                try
                {
                    Products p = new Products();
                    p.ProductName = name;
                    int pprice = Convert.ToInt32(price);
                    p.ProductPrice = pprice;
                    ProductOrderDAL dal = new ProductOrderDAL();
                    int pid = dal.AddProduct(p);
                    lbl_addproductstatus.Text = "Product ID :" + pid;
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void frm_AddProduct_Load(object sender, EventArgs e)
        {

        }
    }
}
