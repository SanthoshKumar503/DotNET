﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Win_Orders_With_Products
{
    class ProductOrderDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connstr"].ConnectionString);
        public int AddProduct(Products p)
        {
            if(p==null)
            {
                throw new Exception("Invalid Add Product");
            }
            SqlCommand com_add = new SqlCommand("p_AddProduct", con);
            com_add.CommandType = CommandType.StoredProcedure;
            com_add.Parameters.AddWithValue("@name", p.ProductName);
            com_add.Parameters.AddWithValue("@price", p.ProductPrice);
            SqlParameter p_id = new SqlParameter();
            p_id.Direction = ParameterDirection.ReturnValue;
            com_add.Parameters.Add(p_id);

            try
            {
                con.Open();
                com_add.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(p_id.Value);
                return id;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public List<int> FindProductIDs()
        {
            SqlCommand com_find = new SqlCommand("p_FindProductIDs", con);
            com_find.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr= com_find.ExecuteReader();
            List<int> list = new List<int>();
            while(dr.Read())
            {
                int id = dr.GetInt32(0);
                list.Add(id);
            }
            con.Close();
            return list;

        }
        public int FindProductPrice(int pid)
        {
            if(pid<0)
            {
                throw new Exception("Invalid Product ID");
            }
            SqlCommand com_price = new SqlCommand("p_FindProductPrice", con);
            com_price.CommandType = CommandType.StoredProcedure;
            com_price.Parameters.AddWithValue("@pid", pid);

            try
            {
                con.Open();
                SqlDataReader dr = com_price.ExecuteReader();
                int price = 0;
                if (dr.Read())
                {
                    price = dr.GetInt32(0);
                }
                con.Close();
                return price;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public int AddOrder(Orders o)
        {
            if(o==null)
            {
                throw new Exception("Invalid Adding Orders");
            }
            SqlCommand com_add = new SqlCommand("p_AddOrder", con);
            com_add.CommandType = CommandType.StoredProcedure;
            com_add.Parameters.AddWithValue("@email", o.CustomerEmailID);
            com_add.Parameters.AddWithValue("@pid", o.ProductID);
            com_add.Parameters.AddWithValue("@pprice", o.ProductPrice);
            com_add.Parameters.AddWithValue("@qty", o.ProductQty);
            SqlParameter p_id = new SqlParameter();
            p_id.Direction = ParameterDirection.ReturnValue;
            com_add.Parameters.Add(p_id);

            try
            {
                con.Open();
                com_add.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(p_id.Value);
                return id;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public List<OrderProducts> ShowOrders(string email)
        {
            if(email==string.Empty)
            {
                throw new Exception("Provide Email ID");
            }
            SqlCommand com_show = new SqlCommand("p_ShowOrders", con);
            com_show.CommandType = CommandType.StoredProcedure;
            com_show.Parameters.AddWithValue("@email", email);

            try
            {
                con.Open();
                SqlDataReader dr = com_show.ExecuteReader();
                List<OrderProducts> list = new List<OrderProducts>();
                while (dr.Read())
                {
                    OrderProducts op = new OrderProducts();
                    op.OrderID = dr.GetInt32(0);
                    op.CustomerEmailID = dr.GetString(1);
                    op.OrderDate = dr.GetDateTime(2).ToString();
                    op.ProductID = dr.GetInt32(3);
                    op.ProductName = dr.GetString(4);
                    op.ProductPrice = dr.GetInt32(5);
                    op.ProductQty = dr.GetInt32(6);
                    list.Add(op);
                }
                con.Close();
                return list;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
    }
}
