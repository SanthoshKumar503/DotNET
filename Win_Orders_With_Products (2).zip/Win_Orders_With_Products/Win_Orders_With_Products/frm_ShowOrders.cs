﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Orders_With_Products
{
    public partial class frm_ShowOrders : Form
    {
        public frm_ShowOrders()
        {
            InitializeComponent();
        }

        private void btn_showemailid_Click(object sender, EventArgs e)
        {
            string email = txt_showemailid.Text;
            if(email==string.Empty)
            {
                MessageBox.Show("Enter email ID");
            }
            else
            {
                try
                {
                    ProductOrderDAL dal = new ProductOrderDAL();
                    List<OrderProducts> op = dal.ShowOrders(email);
                    dgv_showorders.DataSource = op;
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void frm_ShowOrders_Load(object sender, EventArgs e)
        {

        }
    }
}
