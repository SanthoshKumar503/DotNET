﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Orders_With_Products
{
    public partial class frm_AddOrders : Form
    {
        public frm_AddOrders()
        {
            InitializeComponent();
        }

        private void cmb_addorderid_SelectedIndexChanged(object sender, EventArgs e)
        {
            string price = cmb_addorderid.Text;
            if(price==string.Empty)
            {
                lbl_addorderstatus.Text += "Select Product ID";
            }
            else
            {
                try
                {
                    int pid = Convert.ToInt32(price);
                    ProductOrderDAL dal = new ProductOrderDAL();
                    pid = dal.FindProductPrice(pid);
                    txt_addorderprice.Text = pid.ToString();
                }
                catch(Exception exp)
                {
                    MessageBox.Show(exp.Message);
                }
            }
        }
       
        private void frm_AddOrders_Load(object sender, EventArgs e)
        {
            ProductOrderDAL dal = new ProductOrderDAL();
            List<int> list = new List<int>();
            list = dal.FindProductIDs();
            foreach(int id in list)
            cmb_addorderid.Items.Add(id);

            cmb_addorderqty.Items.Add(1);
            cmb_addorderqty.Items.Add(2);
            cmb_addorderqty.Items.Add(3);
            cmb_addorderqty.Items.Add(4);
        }

        private void txt_addorderprice_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btn_addorder_Click(object sender, EventArgs e)
        {
            string email = txt_addorderemailid.Text;
            string pid = cmb_addorderid.Text;
            string price = txt_addorderprice.Text;
            string qty = cmb_addorderqty.Text;
            if(email==string.Empty)
            {
                lbl_addorderstatus.Text = "Enter email ID";
            }
            else if(pid==string.Empty)
            {
                lbl_addorderstatus.Text = "Enter product ID";
            }
            else if(price==string.Empty)
            {
                lbl_addorderstatus.Text = "Enter price";
            }
            else if(qty==string.Empty)
            {
                lbl_addorderstatus.Text = "Select Quantity";
            }
            else
            {
                try
                {
                    Orders o = new Orders();
                    o.CustomerEmailID = email;
                    o.ProductID = Convert.ToInt16(pid);
                    o.ProductPrice = Convert.ToInt32(price);
                    o.ProductQty = Convert.ToInt32(qty);
                    ProductOrderDAL dal = new ProductOrderDAL();
                    int id = dal.AddOrder(o);
                    lbl_addorderstatus.Text = "Order ID:" + id;
                }
                catch(Exception exp2)
                {
                    MessageBox.Show(exp2.Message);
                }
            }
        }

        private void cmb_addorderqty_SelectedIndexChanged(object sender, EventArgs e)
        {
            string price = txt_addorderprice.Text;
            string qty = cmb_addorderqty.Text;
            if(price==string.Empty)
            {
                lbl_addorderstatus.Text = "Enter price";
            }
            else if(qty==string.Empty)
            {
                lbl_addorderstatus.Text = "Enter quantity";
            }
            else
            {
                try
                {
                    Orders o = new Orders();
                    int p = Convert.ToInt32(price);
                    int q = Convert.ToInt32(qty);
                    int total = o.Total(p, q);
                    txt_addordertotal.Text = total.ToString();
                }
                catch(Exception exp3)
                {
                    MessageBox.Show(exp3.Message);
                }
            }
            

        }
    }
}
