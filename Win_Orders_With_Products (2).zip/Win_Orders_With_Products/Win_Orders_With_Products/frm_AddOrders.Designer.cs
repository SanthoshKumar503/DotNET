﻿namespace Win_Orders_With_Products
{
    partial class frm_AddOrders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_addorderemail = new System.Windows.Forms.Label();
            this.lbl_addorderproductid = new System.Windows.Forms.Label();
            this.lbl_addorderproductprice = new System.Windows.Forms.Label();
            this.lbl_addorderquantity = new System.Windows.Forms.Label();
            this.txt_addorderemailid = new System.Windows.Forms.TextBox();
            this.cmb_addorderid = new System.Windows.Forms.ComboBox();
            this.txt_addorderprice = new System.Windows.Forms.TextBox();
            this.cmb_addorderqty = new System.Windows.Forms.ComboBox();
            this.txt_addordertotal = new System.Windows.Forms.TextBox();
            this.lbl_addordertotal = new System.Windows.Forms.Label();
            this.btn_addorder = new System.Windows.Forms.Button();
            this.lbl_addorderstatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(292, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "ADD ORDERS";
            // 
            // lbl_addorderemail
            // 
            this.lbl_addorderemail.AutoSize = true;
            this.lbl_addorderemail.Location = new System.Drawing.Point(99, 114);
            this.lbl_addorderemail.Name = "lbl_addorderemail";
            this.lbl_addorderemail.Size = new System.Drawing.Size(193, 20);
            this.lbl_addorderemail.TabIndex = 1;
            this.lbl_addorderemail.Text = "Enter Customer Email ID :";
            // 
            // lbl_addorderproductid
            // 
            this.lbl_addorderproductid.AutoSize = true;
            this.lbl_addorderproductid.Location = new System.Drawing.Point(103, 177);
            this.lbl_addorderproductid.Name = "lbl_addorderproductid";
            this.lbl_addorderproductid.Size = new System.Drawing.Size(136, 20);
            this.lbl_addorderproductid.TabIndex = 2;
            this.lbl_addorderproductid.Text = "Enter Product ID :";
            // 
            // lbl_addorderproductprice
            // 
            this.lbl_addorderproductprice.AutoSize = true;
            this.lbl_addorderproductprice.Location = new System.Drawing.Point(107, 235);
            this.lbl_addorderproductprice.Name = "lbl_addorderproductprice";
            this.lbl_addorderproductprice.Size = new System.Drawing.Size(154, 20);
            this.lbl_addorderproductprice.TabIndex = 3;
            this.lbl_addorderproductprice.Text = "Enter Product Price :";
            // 
            // lbl_addorderquantity
            // 
            this.lbl_addorderquantity.AutoSize = true;
            this.lbl_addorderquantity.Location = new System.Drawing.Point(103, 297);
            this.lbl_addorderquantity.Name = "lbl_addorderquantity";
            this.lbl_addorderquantity.Size = new System.Drawing.Size(178, 20);
            this.lbl_addorderquantity.TabIndex = 4;
            this.lbl_addorderquantity.Text = "Enter Product Quantity :";
            // 
            // txt_addorderemailid
            // 
            this.txt_addorderemailid.Location = new System.Drawing.Point(338, 114);
            this.txt_addorderemailid.Name = "txt_addorderemailid";
            this.txt_addorderemailid.Size = new System.Drawing.Size(238, 26);
            this.txt_addorderemailid.TabIndex = 5;
            // 
            // cmb_addorderid
            // 
            this.cmb_addorderid.FormattingEnabled = true;
            this.cmb_addorderid.Location = new System.Drawing.Point(338, 177);
            this.cmb_addorderid.Name = "cmb_addorderid";
            this.cmb_addorderid.Size = new System.Drawing.Size(238, 28);
            this.cmb_addorderid.TabIndex = 6;
            this.cmb_addorderid.SelectedIndexChanged += new System.EventHandler(this.cmb_addorderid_SelectedIndexChanged);
            // 
            // txt_addorderprice
            // 
            this.txt_addorderprice.Location = new System.Drawing.Point(338, 235);
            this.txt_addorderprice.Name = "txt_addorderprice";
            this.txt_addorderprice.Size = new System.Drawing.Size(238, 26);
            this.txt_addorderprice.TabIndex = 7;
            this.txt_addorderprice.TextChanged += new System.EventHandler(this.txt_addorderprice_TextChanged);
            // 
            // cmb_addorderqty
            // 
            this.cmb_addorderqty.FormattingEnabled = true;
            this.cmb_addorderqty.Location = new System.Drawing.Point(338, 297);
            this.cmb_addorderqty.Name = "cmb_addorderqty";
            this.cmb_addorderqty.Size = new System.Drawing.Size(238, 28);
            this.cmb_addorderqty.TabIndex = 8;
            this.cmb_addorderqty.SelectedIndexChanged += new System.EventHandler(this.cmb_addorderqty_SelectedIndexChanged);
            // 
            // txt_addordertotal
            // 
            this.txt_addordertotal.Location = new System.Drawing.Point(338, 381);
            this.txt_addordertotal.Name = "txt_addordertotal";
            this.txt_addordertotal.Size = new System.Drawing.Size(238, 26);
            this.txt_addordertotal.TabIndex = 9;
            // 
            // lbl_addordertotal
            // 
            this.lbl_addordertotal.AutoSize = true;
            this.lbl_addordertotal.Location = new System.Drawing.Point(141, 386);
            this.lbl_addordertotal.Name = "lbl_addordertotal";
            this.lbl_addordertotal.Size = new System.Drawing.Size(112, 20);
            this.lbl_addordertotal.TabIndex = 10;
            this.lbl_addordertotal.Text = "Total Amount :";
            // 
            // btn_addorder
            // 
            this.btn_addorder.Location = new System.Drawing.Point(364, 448);
            this.btn_addorder.Name = "btn_addorder";
            this.btn_addorder.Size = new System.Drawing.Size(188, 43);
            this.btn_addorder.TabIndex = 11;
            this.btn_addorder.Text = "Place Order";
            this.btn_addorder.UseVisualStyleBackColor = true;
            this.btn_addorder.Click += new System.EventHandler(this.btn_addorder_Click);
            // 
            // lbl_addorderstatus
            // 
            this.lbl_addorderstatus.AutoSize = true;
            this.lbl_addorderstatus.Location = new System.Drawing.Point(313, 551);
            this.lbl_addorderstatus.Name = "lbl_addorderstatus";
            this.lbl_addorderstatus.Size = new System.Drawing.Size(64, 20);
            this.lbl_addorderstatus.TabIndex = 12;
            this.lbl_addorderstatus.Text = "Status :";
            // 
            // frm_AddOrders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(723, 590);
            this.Controls.Add(this.lbl_addorderstatus);
            this.Controls.Add(this.btn_addorder);
            this.Controls.Add(this.lbl_addordertotal);
            this.Controls.Add(this.txt_addordertotal);
            this.Controls.Add(this.cmb_addorderqty);
            this.Controls.Add(this.txt_addorderprice);
            this.Controls.Add(this.cmb_addorderid);
            this.Controls.Add(this.txt_addorderemailid);
            this.Controls.Add(this.lbl_addorderquantity);
            this.Controls.Add(this.lbl_addorderproductprice);
            this.Controls.Add(this.lbl_addorderproductid);
            this.Controls.Add(this.lbl_addorderemail);
            this.Controls.Add(this.label1);
            this.Name = "frm_AddOrders";
            this.Text = "frm_AddOrders";
            this.Load += new System.EventHandler(this.frm_AddOrders_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_addorderemail;
        private System.Windows.Forms.Label lbl_addorderproductid;
        private System.Windows.Forms.Label lbl_addorderproductprice;
        private System.Windows.Forms.Label lbl_addorderquantity;
        private System.Windows.Forms.TextBox txt_addorderemailid;
        private System.Windows.Forms.ComboBox cmb_addorderid;
        private System.Windows.Forms.TextBox txt_addorderprice;
        private System.Windows.Forms.ComboBox cmb_addorderqty;
        private System.Windows.Forms.TextBox txt_addordertotal;
        private System.Windows.Forms.Label lbl_addordertotal;
        private System.Windows.Forms.Button btn_addorder;
        private System.Windows.Forms.Label lbl_addorderstatus;
    }
}