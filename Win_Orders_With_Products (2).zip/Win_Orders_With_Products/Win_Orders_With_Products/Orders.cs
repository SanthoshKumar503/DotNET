﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Orders_With_Products
{
    class Orders
    {
        public int OrderID { get; set; }
        public string CustomerEmailID { get; set; }
        public int ProductID { get; set; }
        public int ProductPrice { get; set; }
        public int ProductQty { get; set; }
        public string OrderDate { get; set; }


        public int Total(int price,int qty)
        {
            return price * qty;
        }
    }
}
