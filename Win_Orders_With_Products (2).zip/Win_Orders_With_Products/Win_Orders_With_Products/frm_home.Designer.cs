﻿namespace Win_Orders_With_Products
{
    partial class frm_home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btn_addproduct = new System.Windows.Forms.Button();
            this.btn_addorders = new System.Windows.Forms.Button();
            this.btn_showorders = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(397, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "HOME PAGE";
            // 
            // btn_addproduct
            // 
            this.btn_addproduct.Location = new System.Drawing.Point(153, 256);
            this.btn_addproduct.Name = "btn_addproduct";
            this.btn_addproduct.Size = new System.Drawing.Size(151, 34);
            this.btn_addproduct.TabIndex = 1;
            this.btn_addproduct.Text = "Add Product";
            this.btn_addproduct.UseVisualStyleBackColor = true;
            this.btn_addproduct.Click += new System.EventHandler(this.btn_addproduct_Click);
            // 
            // btn_addorders
            // 
            this.btn_addorders.Location = new System.Drawing.Point(423, 255);
            this.btn_addorders.Name = "btn_addorders";
            this.btn_addorders.Size = new System.Drawing.Size(138, 35);
            this.btn_addorders.TabIndex = 2;
            this.btn_addorders.Text = "Add Orders";
            this.btn_addorders.UseVisualStyleBackColor = true;
            this.btn_addorders.Click += new System.EventHandler(this.btn_addorders_Click);
            // 
            // btn_showorders
            // 
            this.btn_showorders.Location = new System.Drawing.Point(677, 256);
            this.btn_showorders.Name = "btn_showorders";
            this.btn_showorders.Size = new System.Drawing.Size(138, 34);
            this.btn_showorders.TabIndex = 3;
            this.btn_showorders.Text = "Show Orders";
            this.btn_showorders.UseVisualStyleBackColor = true;
            this.btn_showorders.Click += new System.EventHandler(this.btn_showorders_Click);
            // 
            // frm_home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 628);
            this.Controls.Add(this.btn_showorders);
            this.Controls.Add(this.btn_addorders);
            this.Controls.Add(this.btn_addproduct);
            this.Controls.Add(this.label1);
            this.Name = "frm_home";
            this.Text = "frm_home";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_addproduct;
        private System.Windows.Forms.Button btn_addorders;
        private System.Windows.Forms.Button btn_showorders;
    }
}