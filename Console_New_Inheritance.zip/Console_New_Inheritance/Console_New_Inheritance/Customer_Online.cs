﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_New_Inheritance
{
    class Customer_Online : Customer
    {
        private string PaymentType;
        private string DeliveryAddress;
        private string MobileNo;
        public Customer_Online(string CustomerName,string CustomerGender,
            string PaymentType,string DeliveryAddress, string MobileNo):base(CustomerName,CustomerGender)
        {
            this.PaymentType = PaymentType;
            this.DeliveryAddress = DeliveryAddress;
            this.MobileNo = MobileNo;
            Console.WriteLine("Customer_Online Customer");
        }
        public string PPaymentType
        {
            get
            {
                return this.PaymentType;
            }
            set
            {
                this.PaymentType = value;
            }
        }
        public string PDeliveryAddress
        {
            get
            {
                return this.DeliveryAddress;
            }
            set
            {
                this.DeliveryAddress = value;
            }
        }
        public string PMobileNo
        {
            get
            {
                return this.MobileNo;
            }
            set
            {
                this.MobileNo = value;
            }
        }

    }
}
