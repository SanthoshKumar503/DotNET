﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_New_Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Customer ob = new Customer("John", "Male");
            Console.WriteLine(ob.PCustomerId);
            Console.WriteLine(ob.PCustomerName);
            Console.WriteLine(ob.PCustomerGender);
            */
            Customer temp;
            Customer_Online co1 = new Customer_Online("san", "male", "online", "Ctr", "9642653256");
            temp = co1;
            Customer_Online co = (Customer_Online)temp;// also-> Customer_Online co= temp as Customer_Online
            Console.WriteLine(co.PCustomerId);
            Console.WriteLine(co.PCustomerName);
            Console.WriteLine(co.PCustomerGender);
            Console.WriteLine(co.PPaymentType);
            Console.WriteLine(co.PDeliveryAddress);
            Console.WriteLine(co.PMobileNo);

            Console.ReadLine();

        }
    }
}
