﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_New_Inheritance
{
    class Customer
    {
        private int CustomerId;
        private string CustomerName;
        private string CustomerGender;
        private static int Count=0;
        public Customer(string CustomerName,string CustomerGender)
        {
            this.CustomerName = CustomerName;
            this.CustomerGender = CustomerGender;
            this.CustomerId = ++Customer.Count;
            Console.WriteLine("Customer Constructor");
        } 

        public int PCustomerId
        {
            get
            {
                return this.CustomerId;
            }
            set
            {
                this.CustomerId = value;
            }
        }

        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
            set
            {
                this.CustomerName = value;
            }
        }

        public string PCustomerGender
        {
            get
            {
                return this.CustomerGender;
            }
            set
            {
                this.CustomerGender = value;
            }
        }
            

    }
}
