﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Switch
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the first number:");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the second number:");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            do
            {
                Console.WriteLine("1:Sum 2:Sub 3:Mul");
                Console.WriteLine("4:Div 5:Modu 6:Exit");
                Console.WriteLine();
                Console.WriteLine("Enter the your choice:");
                int n = Convert.ToInt32(Console.ReadLine());
                switch (n)
                {
                    case 1:
                        {
                            int r = a + b;
                            Console.WriteLine("Sum is:" + r);
                            break;
                        }
                    case 2:
                        {
                            int r = a - b;
                            Console.WriteLine("Sub is:" + r);
                            break;
                        }
                    case 3:
                        {
                            int r = a * b;
                            Console.WriteLine("Mul is:" + r);
                            break;
                        }
                    case 4:
                        {
                            int r = a / b;
                            Console.WriteLine("Div is:" + r);
                            break;
                        }
                    case 5:
                        {
                            int r = a % b;
                            Console.WriteLine("Modu is:" + r);
                            break;
                        }
                    case 6:
                        {
                            return;
                        }
                    default:
                        {
                            Console.WriteLine("Invalid choice");
                            break;
                        }
                }
                Console.WriteLine();
                Console.WriteLine("Enter any key to continue");
                Console.WriteLine();
            } while (true);


            Console.ReadLine();
        }
    }
}
