﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    class ProductA : IProduct , ITesting
    {
        private int PId;
        private string PName;
        private int PPrice;
        public ProductA(int PId,string PName,int PPrice)
        {
            this.PId = PId;
            this.PName = PName;
            this.PPrice = PPrice;
        }

        public string GetName()
        {
            return this.PName;
        }

        public int GetPrice()
        {
            return this.PPrice;
        }

        public void Start()
        {
            Console.WriteLine("Product A started");
        }
        public void Stop()
        {
            Console.WriteLine("Product A stopped");
        }
    }
}
