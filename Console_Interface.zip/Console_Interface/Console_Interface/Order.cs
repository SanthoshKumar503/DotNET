﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    class Order
    {
        private int OrderId;
        private string CustomerName;
        public Order(int OrderId,string CustomerName)
        {
            this.OrderId = OrderId;
            this.CustomerName = CustomerName;
        }
        public void AddProduct(IProduct p)
        {
            string name = p.GetName();
            int price=p.GetPrice();
            Console.WriteLine("Product details:" + name + ", " + price);
        }
    }
}
