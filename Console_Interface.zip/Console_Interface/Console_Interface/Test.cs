﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    class Test
    {
        public void Testing(ITesting t)
        {
            t.Start();
            t.Stop();
        }
    }
}
