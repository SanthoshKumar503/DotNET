﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    interface IProduct
    {
        string GetName();
        int GetPrice();
    }
}
