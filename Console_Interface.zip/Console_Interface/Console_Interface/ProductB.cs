﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    class ProductB : IProduct , ITesting
    {
        private int BId;
        private string BName;
        private int BPrice;
        public ProductB(int BId,string BName,int BPrice)
        {
            this.BId = BId;
            this.BName = BName;
            this.BPrice = BPrice;
        }

        public string GetName()
        {
            return this.BName;
        }

        public int GetPrice()
        {
            return this.BPrice;
        }

        public void Start()
        {
            Console.WriteLine("Product B started");

        }
        public void Stop()
        {
            Console.WriteLine("Product B stopped");
        }
    }
}
