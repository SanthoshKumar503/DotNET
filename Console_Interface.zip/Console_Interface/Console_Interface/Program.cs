﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Id:");
            int id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter product name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter price");
            int price = Convert.ToInt32(Console.ReadLine());

            ProductA a = new ProductA(id, name, price);
            ProductB b = new ProductB(id, name, price);

            Order o1 = new Order(1, "John");
            o1.AddProduct(a);
            o1.AddProduct(b);

            Test t1 = new Test();
            t1.Testing(a);
            t1.Testing(b);

            Console.ReadLine();
        }
    }
}
