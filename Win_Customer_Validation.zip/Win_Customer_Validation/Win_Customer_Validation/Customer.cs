﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_Customer_Validation
{
    class Customer
    {
        public int CustomerID { get; }
        public string CustomerEmail { get; set; }
        public string CustomerName { get; set; }
        public string CustomerCity { get; set; }
        public string CustomerGender { get; set; }
        private static int count = 1000;
        public Customer(string CustomerEmail, string CustomerName,
            string CustomerCity, string CustomerGender)
        {
            this.CustomerID = ++Customer.count;
            this.CustomerEmail = CustomerEmail;
            this.CustomerName = CustomerName;
            this.CustomerCity = CustomerCity;
            this.CustomerGender = CustomerGender;

        }

    }
}
