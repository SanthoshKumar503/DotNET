﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Customer_Validation
{
    public partial class frm_newcustomer : Form
    {
        public static int CID;
        public frm_newcustomer()
        {
            InitializeComponent();
        }

        private void frm_newcustomer_Load(object sender, EventArgs e)
        {
            cmb_city.Items.Add("Bangalore");
            cmb_city.Items.Add("Pune");
            cmb_city.Items.Add("Mumbai");
            cmb_city.Items.Add("Tirupati");


        }

        private void btn_register_Click(object sender, EventArgs e)
        {
            
            string email = txt_email.Text;
            string name = txt_name.Text;
            string city = cmb_city.Text;
            bool male = rdb_male.Checked;
            bool female = rdb_female.Checked;
            string gender;
            if(email==string.Empty)
            {
                MessageBox.Show("Enter Email");
            }
            else if(name==string.Empty)
            {
                MessageBox.Show("Enter Name");
            }
            else if(city==string.Empty)
            {
                MessageBox.Show("Select City");
            }
            else if(male==false && female==false)
            {
                MessageBox.Show("Select Gender");
            }
            else
            {
                if(male==true)
                {
                    gender = "male";
                }
                else
                {
                    gender = "female";
                }
                lbl_status.Text = "Register Successful";
                Customer c = new Customer(email,name,city,gender);
                CID = c.CustomerID;
            }
        }
    }
}
