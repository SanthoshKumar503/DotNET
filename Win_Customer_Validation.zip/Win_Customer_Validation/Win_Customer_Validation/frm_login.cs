﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_Customer_Validation
{
    public partial class frm_login : Form
    {
        public frm_login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            string email = txt_loginid.Text;
            string pass = txt_password.Text;
            if (email == "Admin")
            {
                MessageBox.Show("Enter Login ID");
            }
            else if (pass != "san@123")
            {
                MessageBox.Show("Enter Password");
            }
            else
            {
                frm_home h = new frm_home();
                h.Show();
            }
        }

        private void btn_signup_Click(object sender, EventArgs e)
        {
            frm_newcustomer c = new frm_newcustomer();
            c.Show();
            
        }

        private void frm_login_Load(object sender, EventArgs e)
        {

        }
    }
}
