﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Console_Collection
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList marks = new ArrayList();
            int i = 50;
            int j = 54;
            string s = "san";
            marks.Add(i);
            marks.Add(j);
            marks.Add(s);

            int c = marks.Count;
            Console.WriteLine(c);

            marks.RemoveAt(0);
            c = marks.Count;
            Console.WriteLine(c);
            marks.Remove("san");
            c = marks.Count;
            Console.WriteLine(c);

            int x = Convert.ToInt32(marks[0]);
            Console.WriteLine(x);
            Console.ReadLine();

        }
    }
}
