﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_1stDay
{
    class Program
    {
        static void Main(string[] args)
        {
            /*int? x=100;
             /* 
            //convertion
            String s1 = "1001";
            int i1 = Convert.ToInt32(s1);
            int i2 = int.Parse(s1);
            int i3 = Convert.ToInt32(null);//print 0
            //int i4 = int.Parse(null);//error

            //Int16  , Int32,  Int64  -> short, int, long
            Console.WriteLine("Enter number 1:");
            int num1=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter number 2:");
            int num2 = Convert.ToInt32(Console.ReadLine());//string(cmd line take as string) to int
            int total = num1 + num2;
            Console.WriteLine("Total value is:" + total);
            string t = total.ToString();//int to string
            Console.WriteLine(t);
            */
            Console.WriteLine("Welcome to path front");
            Console.WriteLine("Enter the username:");
            string uname = Console.ReadLine();

            Console.WriteLine("Enter the password:");
            string pass = Console.ReadLine();
            if(uname=="user1" && pass=="san@123")
            {
                Console.WriteLine("Valid user");
            }else
                {
                Console.WriteLine("Invalid user");
            }
            
            Console.ReadLine();
        }
    }
}
