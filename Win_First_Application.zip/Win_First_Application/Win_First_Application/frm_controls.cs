﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_First_Application
{
    public partial class frm_controls : Form
    {
        public frm_controls()
        {
            InitializeComponent();
        }

        private void frm_controls_Load(object sender, EventArgs e)
        {
            cmb_cities.Items.Add("Mumbai");
            cmb_cities.Items.Add("Chennai");
            cmb_cities.Items.Add("Pune");
            cmb_cities.Items.Add("Bangalore");


            lst_technologies.Items.Add("DotNet");
            lst_technologies.Items.Add("Java");
            lst_technologies.Items.Add("Sql Server");
        }

        private void btn_controls_Click(object sender, EventArgs e)
        {
            string city = cmb_cities.Text;
            string tech = lst_technologies.Text;
            bool b_male = rdb_male.Checked;
            bool b_female = rdb_female.Checked;
            bool status = chk_tc.Checked;
            if(city==string.Empty)
            {
                MessageBox.Show("Select city");
            }
            else if(tech==string.Empty)
            {
                MessageBox.Show("Select Technologies");
            }
            else if(b_male==false && b_female==false)
            {
                MessageBox.Show("Select gender");
            }
            else
            {
                string gender = string.Empty;
                if(b_male==true)
                {
                    gender = "Male";
                }
                else
                {
                    gender = "Female";
                }
            }
            if(status==false)
            {
                MessageBox.Show("Not checked");
            }
           

        }

        private void cmb_cities_SelectedIndexChanged(object sender, EventArgs e)
        {
            string city = cmb_cities.Text;
            txt_city.Text = city;
        }
    }
}
