﻿namespace Win_First_Application
{
    partial class frm_controls
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmb_cities = new System.Windows.Forms.ComboBox();
            this.btn_controls = new System.Windows.Forms.Button();
            this.lst_technologies = new System.Windows.Forms.ListBox();
            this.rdb_male = new System.Windows.Forms.RadioButton();
            this.rdb_female = new System.Windows.Forms.RadioButton();
            this.chk_tc = new System.Windows.Forms.CheckBox();
            this.txt_city = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // cmb_cities
            // 
            this.cmb_cities.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_cities.FormattingEnabled = true;
            this.cmb_cities.Location = new System.Drawing.Point(142, 69);
            this.cmb_cities.Name = "cmb_cities";
            this.cmb_cities.Size = new System.Drawing.Size(277, 37);
            this.cmb_cities.TabIndex = 0;
            this.cmb_cities.SelectedIndexChanged += new System.EventHandler(this.cmb_cities_SelectedIndexChanged);
            // 
            // btn_controls
            // 
            this.btn_controls.Location = new System.Drawing.Point(177, 431);
            this.btn_controls.Name = "btn_controls";
            this.btn_controls.Size = new System.Drawing.Size(119, 39);
            this.btn_controls.TabIndex = 1;
            this.btn_controls.Text = "Add";
            this.btn_controls.UseVisualStyleBackColor = true;
            this.btn_controls.Click += new System.EventHandler(this.btn_controls_Click);
            // 
            // lst_technologies
            // 
            this.lst_technologies.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst_technologies.FormattingEnabled = true;
            this.lst_technologies.ItemHeight = 29;
            this.lst_technologies.Location = new System.Drawing.Point(142, 131);
            this.lst_technologies.Name = "lst_technologies";
            this.lst_technologies.Size = new System.Drawing.Size(277, 120);
            this.lst_technologies.TabIndex = 2;
            // 
            // rdb_male
            // 
            this.rdb_male.AutoSize = true;
            this.rdb_male.Location = new System.Drawing.Point(142, 290);
            this.rdb_male.Name = "rdb_male";
            this.rdb_male.Size = new System.Drawing.Size(68, 24);
            this.rdb_male.TabIndex = 3;
            this.rdb_male.TabStop = true;
            this.rdb_male.Text = "Male";
            this.rdb_male.UseVisualStyleBackColor = true;
            // 
            // rdb_female
            // 
            this.rdb_female.AutoSize = true;
            this.rdb_female.Location = new System.Drawing.Point(292, 289);
            this.rdb_female.Name = "rdb_female";
            this.rdb_female.Size = new System.Drawing.Size(87, 24);
            this.rdb_female.TabIndex = 4;
            this.rdb_female.TabStop = true;
            this.rdb_female.Text = "Female";
            this.rdb_female.UseVisualStyleBackColor = true;
            // 
            // chk_tc
            // 
            this.chk_tc.AutoSize = true;
            this.chk_tc.Location = new System.Drawing.Point(142, 345);
            this.chk_tc.Name = "chk_tc";
            this.chk_tc.Size = new System.Drawing.Size(189, 24);
            this.chk_tc.TabIndex = 5;
            this.chk_tc.Text = "Terms and Conditions";
            this.chk_tc.UseVisualStyleBackColor = true;
            // 
            // txt_city
            // 
            this.txt_city.Location = new System.Drawing.Point(197, 391);
            this.txt_city.Name = "txt_city";
            this.txt_city.Size = new System.Drawing.Size(100, 26);
            this.txt_city.TabIndex = 6;
            // 
            // frm_controls
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 511);
            this.Controls.Add(this.txt_city);
            this.Controls.Add(this.chk_tc);
            this.Controls.Add(this.rdb_female);
            this.Controls.Add(this.rdb_male);
            this.Controls.Add(this.lst_technologies);
            this.Controls.Add(this.btn_controls);
            this.Controls.Add(this.cmb_cities);
            this.Name = "frm_controls";
            this.Text = "frm_controls";
            this.Load += new System.EventHandler(this.frm_controls_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmb_cities;
        private System.Windows.Forms.Button btn_controls;
        private System.Windows.Forms.ListBox lst_technologies;
        private System.Windows.Forms.RadioButton rdb_male;
        private System.Windows.Forms.RadioButton rdb_female;
        private System.Windows.Forms.CheckBox chk_tc;
        private System.Windows.Forms.TextBox txt_city;
    }
}