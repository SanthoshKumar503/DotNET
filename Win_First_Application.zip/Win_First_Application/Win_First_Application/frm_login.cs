﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_First_Application
{
    public partial class frm_login : Form
    {
        public static string LoginID;
        public frm_login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            string loginid = txt_loginid.Text;
            string password = txt_password.Text;
            if(loginid==string.Empty)
            {
                lbl_status.Text = "Enter login ID";
            }
            else if(password==string.Empty)
            {
                lbl_status.Text = "Enter password";
            }
            else
            {
                if(loginid=="Santhosh" && password=="San@123")
                {
                    frm_login.LoginID = loginid;
                    lbl_status.Text = "Valid User";
                    frm_home obj = new frm_home();
                    obj.Show();
                }
                else
                {
                    lbl_status.Text = "Invalid user";
                }
            }
        }

        private void btn_newuser_Click(object sender, EventArgs e)
        {
            frm_newuser obj = new frm_newuser();
            obj.Show();
        }
    }
}
