﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Order
{
    class Order
    {
        private static int count = 100;
        private int OrderId;
        private string CustomerName;
        private string ItemName;
        private int ItemPrice;
        private int ItemQuantity;

        public Order(string CustomerName, string ItemName, int ItemPrice, int ItemQuantity)
        {
            this.CustomerName = CustomerName;
            this.ItemName = ItemName;
            this.ItemPrice = ItemPrice;
            this.ItemQuantity = ItemQuantity;
            this.OrderId = ++Order.count;
        }

        public int GetOrderAmount()
        {
            return this.ItemQuantity * this.ItemPrice;
        }

        public int POrderId
        {
            get
            {
                return this.OrderId;
            }
           /* set
            {
                this.OrderId = value;
            }*/
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }

        public string PItemName
        {
            get
            {
                return this.ItemName;
            }
        }

        public int PItemPrice
        {
            get
            {
                return this.ItemPrice;
            }
        }

        public int PItemQuantity
        {
            get
            {
                return this.ItemQuantity;
            }
            set
            {
                if(value>0)
                {
                    this.ItemQuantity = value;
                }
            }
        }

    }
}
