﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Order
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Customer Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Item Name");
            string iname = Console.ReadLine();
            Console.WriteLine("Enter Item Price");
            int price = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Item Quantity");
            int quantity= Convert.ToInt32(Console.ReadLine());
            Order o = new Order(name,iname,price,quantity);

            string r2 = o.PCustomerName;
            Console.WriteLine("Customer Name is:" + r2);

            string r3 = o.PItemName;
            Console.WriteLine("Item Name is:" + r3);

            int r4 = o.PItemPrice;
            Console.WriteLine("Item Price is:" + r4);

            int r5 = o.PItemQuantity;
            Console.WriteLine("Item quantity is:" + r5);

            int r1 = o.GetOrderAmount();
            Console.WriteLine("Total order Amount is:" + r1);
            
                Console.WriteLine("\t\tIf You Want Change quantity");
                Console.WriteLine("Enter New Quantity");
                quantity = Convert.ToInt32(Console.ReadLine());
                o.PItemQuantity = quantity;
                r1 = o.GetOrderAmount();
                Console.WriteLine("Total New order Amount is:" + r1);
            
            Console.ReadLine();
        }
    }
}
