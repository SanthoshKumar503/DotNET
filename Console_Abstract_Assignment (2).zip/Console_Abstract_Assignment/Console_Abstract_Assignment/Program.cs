﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Abstract_Assignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Customer Name");
            string name = Console.ReadLine();
            Console.WriteLine("Enter the Customer EmailId");
            string email = Console.ReadLine();
            Console.WriteLine("Enter the Customer MobileNo");
            string mobile = Console.ReadLine();
            Console.WriteLine("Enter the Loan Amount");
            int amt = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Duration");
            int duration = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Rate");
            int rate = Convert.ToInt32(Console.ReadLine());

            Loan l = null;
            Console.WriteLine("Enter your loan type");
            string type = Console.ReadLine();

            if(type=="home")
            {
                l = new HomeLoan(name, email, mobile, amt, duration, rate);
            }
            else if(type=="vehicle")
            {
                l = new VehicleLoan(name, email, mobile, amt, duration, rate);
            }
            if(l!=null)
            {
                Console.WriteLine("Loan ID:" + l.PLoanId);
                Console.WriteLine("Customer Name:" + l.PCustomerName);
                Console.WriteLine("Customer Email ID:" + l.PCustomerEmailId);
                Console.WriteLine("Mobile Number:" + l.PMobileNo);
                Console.WriteLine("Loan amount:" + l.PLoanAmount);
                Console.WriteLine("Loan Duration:" + l.PDuration);
                Console.WriteLine("Loan Rate:" + l.PRate);
                double Emi=l.PayEMI(l.PLoanAmount);
                Console.WriteLine("EMI is:" + Emi);
                double pen=l.PendingLoan();
                Console.WriteLine("Pending Loan is:" + pen);
            }
            else
            {
                Console.WriteLine("Invalid Type");
            }
            Console.ReadLine();
        }
    }
}
