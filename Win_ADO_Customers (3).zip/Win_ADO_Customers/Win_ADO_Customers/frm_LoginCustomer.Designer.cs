﻿namespace Win_ADO_Customers
{
    partial class frm_LoginCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_loginCustomer = new System.Windows.Forms.Label();
            this.lbl_loginid = new System.Windows.Forms.Label();
            this.lbl_loginpassword = new System.Windows.Forms.Label();
            this.txt_loginid = new System.Windows.Forms.TextBox();
            this.txt_loginpassword = new System.Windows.Forms.TextBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.lbl_loginstatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_loginCustomer
            // 
            this.lbl_loginCustomer.AutoSize = true;
            this.lbl_loginCustomer.Location = new System.Drawing.Point(291, 13);
            this.lbl_loginCustomer.Name = "lbl_loginCustomer";
            this.lbl_loginCustomer.Size = new System.Drawing.Size(154, 20);
            this.lbl_loginCustomer.TabIndex = 0;
            this.lbl_loginCustomer.Text = "CUSTOMER LOGIN";
            // 
            // lbl_loginid
            // 
            this.lbl_loginid.AutoSize = true;
            this.lbl_loginid.Location = new System.Drawing.Point(148, 123);
            this.lbl_loginid.Name = "lbl_loginid";
            this.lbl_loginid.Size = new System.Drawing.Size(107, 20);
            this.lbl_loginid.TabIndex = 1;
            this.lbl_loginid.Text = "Customer ID :";
            // 
            // lbl_loginpassword
            // 
            this.lbl_loginpassword.AutoSize = true;
            this.lbl_loginpassword.Location = new System.Drawing.Point(152, 198);
            this.lbl_loginpassword.Name = "lbl_loginpassword";
            this.lbl_loginpassword.Size = new System.Drawing.Size(86, 20);
            this.lbl_loginpassword.TabIndex = 2;
            this.lbl_loginpassword.Text = "Password :";
            // 
            // txt_loginid
            // 
            this.txt_loginid.Location = new System.Drawing.Point(295, 123);
            this.txt_loginid.Name = "txt_loginid";
            this.txt_loginid.Size = new System.Drawing.Size(200, 26);
            this.txt_loginid.TabIndex = 3;
            // 
            // txt_loginpassword
            // 
            this.txt_loginpassword.Location = new System.Drawing.Point(295, 191);
            this.txt_loginpassword.Name = "txt_loginpassword";
            this.txt_loginpassword.Size = new System.Drawing.Size(200, 26);
            this.txt_loginpassword.TabIndex = 4;
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(357, 271);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(75, 33);
            this.btn_login.TabIndex = 5;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(330, 436);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 34);
            this.button1.TabIndex = 6;
            this.button1.Text = "New Customer";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbl_loginstatus
            // 
            this.lbl_loginstatus.AutoSize = true;
            this.lbl_loginstatus.Location = new System.Drawing.Point(368, 340);
            this.lbl_loginstatus.Name = "lbl_loginstatus";
            this.lbl_loginstatus.Size = new System.Drawing.Size(64, 20);
            this.lbl_loginstatus.TabIndex = 7;
            this.lbl_loginstatus.Text = "Status :";
            // 
            // frm_LoginCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(776, 603);
            this.Controls.Add(this.lbl_loginstatus);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.txt_loginpassword);
            this.Controls.Add(this.txt_loginid);
            this.Controls.Add(this.lbl_loginpassword);
            this.Controls.Add(this.lbl_loginid);
            this.Controls.Add(this.lbl_loginCustomer);
            this.Name = "frm_LoginCustomer";
            this.Text = "frm_LoginCustomer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_loginCustomer;
        private System.Windows.Forms.Label lbl_loginid;
        private System.Windows.Forms.Label lbl_loginpassword;
        private System.Windows.Forms.TextBox txt_loginid;
        private System.Windows.Forms.TextBox txt_loginpassword;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lbl_loginstatus;
    }
}