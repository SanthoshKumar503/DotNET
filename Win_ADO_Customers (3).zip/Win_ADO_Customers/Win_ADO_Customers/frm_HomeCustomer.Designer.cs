﻿namespace Win_ADO_Customers
{
    partial class frm_HomeCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_home = new System.Windows.Forms.Label();
            this.lbl_homeid = new System.Windows.Forms.Label();
            this.lbl_homename = new System.Windows.Forms.Label();
            this.btn_homesearch = new System.Windows.Forms.Button();
            this.btn_homefind = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_home
            // 
            this.lbl_home.AutoSize = true;
            this.lbl_home.Location = new System.Drawing.Point(265, 29);
            this.lbl_home.Name = "lbl_home";
            this.lbl_home.Size = new System.Drawing.Size(201, 20);
            this.lbl_home.TabIndex = 0;
            this.lbl_home.Text = "CUSTOMER HOME PAGE";
            // 
            // lbl_homeid
            // 
            this.lbl_homeid.AutoSize = true;
            this.lbl_homeid.Location = new System.Drawing.Point(171, 104);
            this.lbl_homeid.Name = "lbl_homeid";
            this.lbl_homeid.Size = new System.Drawing.Size(107, 20);
            this.lbl_homeid.TabIndex = 1;
            this.lbl_homeid.Text = "Customer ID :";
            // 
            // lbl_homename
            // 
            this.lbl_homename.AutoSize = true;
            this.lbl_homename.Location = new System.Drawing.Point(146, 149);
            this.lbl_homename.Name = "lbl_homename";
            this.lbl_homename.Size = new System.Drawing.Size(132, 20);
            this.lbl_homename.TabIndex = 2;
            this.lbl_homename.Text = "Customer Name :";
            // 
            // btn_homesearch
            // 
            this.btn_homesearch.Location = new System.Drawing.Point(150, 274);
            this.btn_homesearch.Name = "btn_homesearch";
            this.btn_homesearch.Size = new System.Drawing.Size(155, 36);
            this.btn_homesearch.TabIndex = 3;
            this.btn_homesearch.Text = "Search Customer";
            this.btn_homesearch.UseVisualStyleBackColor = true;
            this.btn_homesearch.Click += new System.EventHandler(this.btn_homesearch_Click);
            // 
            // btn_homefind
            // 
            this.btn_homefind.Location = new System.Drawing.Point(388, 274);
            this.btn_homefind.Name = "btn_homefind";
            this.btn_homefind.Size = new System.Drawing.Size(156, 37);
            this.btn_homefind.TabIndex = 4;
            this.btn_homefind.Text = "Find Customer";
            this.btn_homefind.UseVisualStyleBackColor = true;
            this.btn_homefind.Click += new System.EventHandler(this.btn_homefind_Click);
            // 
            // frm_HomeCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(745, 592);
            this.Controls.Add(this.btn_homefind);
            this.Controls.Add(this.btn_homesearch);
            this.Controls.Add(this.lbl_homename);
            this.Controls.Add(this.lbl_homeid);
            this.Controls.Add(this.lbl_home);
            this.Name = "frm_HomeCustomer";
            this.Text = "frm_HomeCustomer";
            this.Load += new System.EventHandler(this.frm_HomeCustomer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_home;
        private System.Windows.Forms.Label lbl_homeid;
        private System.Windows.Forms.Label lbl_homename;
        private System.Windows.Forms.Button btn_homesearch;
        private System.Windows.Forms.Button btn_homefind;
    }
}