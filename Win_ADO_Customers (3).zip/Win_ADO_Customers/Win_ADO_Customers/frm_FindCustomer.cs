﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ADO_Customers
{
    public partial class frm_FindCustomer : Form
    {
        public frm_FindCustomer()
        {
            InitializeComponent();
        }

        private void btn_findcustomer_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(cmb_findcustomer.Text);
            CustomerDAL dal = new CustomerDAL();
            Customers c=dal.FindCustomer(id);
            if(c!=null)
            {
                txt_findname.Text = c.CustomerName;
                txt_findpassword.Text = c.CustomerPassword;
                txt_findcity.Text = c.CustomerCity;
                txt_findmobile.Text = c.CustomerMobileNo;
                txt_findemail.Text = c.CustomerEmailID;
            }
            else
            {
                lbl_findstatus.Text = "Customer not found";
            }
        }

        private void frm_FindCustomer_Load(object sender, EventArgs e)
        {
            CustomerDAL dal = new CustomerDAL();
            List<int> eids = dal.GetEmployeesIDs();
            foreach (int id in eids)
            {
                cmb_findcustomer.Items.Add(id);
            }
        }

        private void btn_findupdate_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(cmb_findcustomer.Text);
            string name = txt_findname.Text;
            string pass = txt_findpassword.Text;
            string city = txt_findcity.Text;
            string mob = txt_findmobile.Text;
            string email = txt_findemail.Text;
            CustomerDAL dal = new CustomerDAL();
            bool status = dal.UpdateCustomer(id,name,pass,city,mob,email);
            if (status == true)
            {
                lbl_findstatus.Text += "Updated successful";
            }
            else
            {
                lbl_findstatus.Text += "Not updated";
            }
        }

        private void btn_finddelete_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(cmb_findcustomer.Text);
            CustomerDAL dal = new CustomerDAL();
            bool status = dal.DeleteCustomer(id);
            if (status == true)
            {
                lbl_findstatus.Text = "Deleted";
            }
            else
            {
                lbl_findstatus.Text = "Not deleted";
            }
        }
    }
}
