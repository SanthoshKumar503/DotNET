﻿namespace Win_ADO_Customers
{
    partial class frm_AddCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_add = new System.Windows.Forms.Label();
            this.lbl_addname = new System.Windows.Forms.Label();
            this.lbl_addpassword = new System.Windows.Forms.Label();
            this.lbl_addcity = new System.Windows.Forms.Label();
            this.lbl_addmobileno = new System.Windows.Forms.Label();
            this.lbl_addemailid = new System.Windows.Forms.Label();
            this.txt_addname = new System.Windows.Forms.TextBox();
            this.txt_addpassword = new System.Windows.Forms.TextBox();
            this.txt_addcity = new System.Windows.Forms.TextBox();
            this.txt_addmobileno = new System.Windows.Forms.TextBox();
            this.txt_addemailid = new System.Windows.Forms.TextBox();
            this.btn_addcustomer = new System.Windows.Forms.Button();
            this.lbl_addstatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_add
            // 
            this.lbl_add.AutoSize = true;
            this.lbl_add.Location = new System.Drawing.Point(396, 35);
            this.lbl_add.Name = "lbl_add";
            this.lbl_add.Size = new System.Drawing.Size(139, 20);
            this.lbl_add.TabIndex = 0;
            this.lbl_add.Text = "ADD CUSTOMER";
            // 
            // lbl_addname
            // 
            this.lbl_addname.AutoSize = true;
            this.lbl_addname.Location = new System.Drawing.Point(170, 139);
            this.lbl_addname.Name = "lbl_addname";
            this.lbl_addname.Size = new System.Drawing.Size(175, 20);
            this.lbl_addname.TabIndex = 1;
            this.lbl_addname.Text = "Enter Customer Name :";
            // 
            // lbl_addpassword
            // 
            this.lbl_addpassword.AutoSize = true;
            this.lbl_addpassword.Location = new System.Drawing.Point(174, 198);
            this.lbl_addpassword.Name = "lbl_addpassword";
            this.lbl_addpassword.Size = new System.Drawing.Size(129, 20);
            this.lbl_addpassword.TabIndex = 2;
            this.lbl_addpassword.Text = "Enter Password :";
            // 
            // lbl_addcity
            // 
            this.lbl_addcity.AutoSize = true;
            this.lbl_addcity.Location = new System.Drawing.Point(178, 255);
            this.lbl_addcity.Name = "lbl_addcity";
            this.lbl_addcity.Size = new System.Drawing.Size(86, 20);
            this.lbl_addcity.TabIndex = 3;
            this.lbl_addcity.Text = "Enter City :";
            this.lbl_addcity.Click += new System.EventHandler(this.lbl_addcity_Click);
            // 
            // lbl_addmobileno
            // 
            this.lbl_addmobileno.AutoSize = true;
            this.lbl_addmobileno.Location = new System.Drawing.Point(174, 308);
            this.lbl_addmobileno.Name = "lbl_addmobileno";
            this.lbl_addmobileno.Size = new System.Drawing.Size(130, 20);
            this.lbl_addmobileno.TabIndex = 4;
            this.lbl_addmobileno.Text = "Enter Mobile No :";
            // 
            // lbl_addemailid
            // 
            this.lbl_addemailid.AutoSize = true;
            this.lbl_addemailid.Location = new System.Drawing.Point(174, 363);
            this.lbl_addemailid.Name = "lbl_addemailid";
            this.lbl_addemailid.Size = new System.Drawing.Size(120, 20);
            this.lbl_addemailid.TabIndex = 5;
            this.lbl_addemailid.Text = "Enter Email ID :";
            // 
            // txt_addname
            // 
            this.txt_addname.Location = new System.Drawing.Point(380, 139);
            this.txt_addname.Name = "txt_addname";
            this.txt_addname.Size = new System.Drawing.Size(270, 26);
            this.txt_addname.TabIndex = 6;
            // 
            // txt_addpassword
            // 
            this.txt_addpassword.Location = new System.Drawing.Point(380, 191);
            this.txt_addpassword.Name = "txt_addpassword";
            this.txt_addpassword.Size = new System.Drawing.Size(270, 26);
            this.txt_addpassword.TabIndex = 7;
            // 
            // txt_addcity
            // 
            this.txt_addcity.Location = new System.Drawing.Point(380, 255);
            this.txt_addcity.Name = "txt_addcity";
            this.txt_addcity.Size = new System.Drawing.Size(270, 26);
            this.txt_addcity.TabIndex = 8;
            // 
            // txt_addmobileno
            // 
            this.txt_addmobileno.Location = new System.Drawing.Point(380, 308);
            this.txt_addmobileno.Name = "txt_addmobileno";
            this.txt_addmobileno.Size = new System.Drawing.Size(270, 26);
            this.txt_addmobileno.TabIndex = 9;
            // 
            // txt_addemailid
            // 
            this.txt_addemailid.Location = new System.Drawing.Point(380, 363);
            this.txt_addemailid.Name = "txt_addemailid";
            this.txt_addemailid.Size = new System.Drawing.Size(270, 26);
            this.txt_addemailid.TabIndex = 10;
            // 
            // btn_addcustomer
            // 
            this.btn_addcustomer.Location = new System.Drawing.Point(452, 451);
            this.btn_addcustomer.Name = "btn_addcustomer";
            this.btn_addcustomer.Size = new System.Drawing.Size(154, 35);
            this.btn_addcustomer.TabIndex = 11;
            this.btn_addcustomer.Text = "ADD CUSTOMER";
            this.btn_addcustomer.UseVisualStyleBackColor = true;
            this.btn_addcustomer.Click += new System.EventHandler(this.btn_addcustomer_Click);
            // 
            // lbl_addstatus
            // 
            this.lbl_addstatus.AutoSize = true;
            this.lbl_addstatus.Location = new System.Drawing.Point(713, 458);
            this.lbl_addstatus.Name = "lbl_addstatus";
            this.lbl_addstatus.Size = new System.Drawing.Size(64, 20);
            this.lbl_addstatus.TabIndex = 12;
            this.lbl_addstatus.Text = "Status :";
            // 
            // frm_AddCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 576);
            this.Controls.Add(this.lbl_addstatus);
            this.Controls.Add(this.btn_addcustomer);
            this.Controls.Add(this.txt_addemailid);
            this.Controls.Add(this.txt_addmobileno);
            this.Controls.Add(this.txt_addcity);
            this.Controls.Add(this.txt_addpassword);
            this.Controls.Add(this.txt_addname);
            this.Controls.Add(this.lbl_addemailid);
            this.Controls.Add(this.lbl_addmobileno);
            this.Controls.Add(this.lbl_addcity);
            this.Controls.Add(this.lbl_addpassword);
            this.Controls.Add(this.lbl_addname);
            this.Controls.Add(this.lbl_add);
            this.Name = "frm_AddCustomer";
            this.Text = "frm_AddCustomer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_add;
        private System.Windows.Forms.Label lbl_addname;
        private System.Windows.Forms.Label lbl_addpassword;
        private System.Windows.Forms.Label lbl_addcity;
        private System.Windows.Forms.Label lbl_addmobileno;
        private System.Windows.Forms.Label lbl_addemailid;
        private System.Windows.Forms.TextBox txt_addname;
        private System.Windows.Forms.TextBox txt_addpassword;
        private System.Windows.Forms.TextBox txt_addcity;
        private System.Windows.Forms.TextBox txt_addmobileno;
        private System.Windows.Forms.TextBox txt_addemailid;
        private System.Windows.Forms.Button btn_addcustomer;
        private System.Windows.Forms.Label lbl_addstatus;
    }
}