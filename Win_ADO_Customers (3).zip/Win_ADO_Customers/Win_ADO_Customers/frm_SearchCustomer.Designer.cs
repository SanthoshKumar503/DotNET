﻿namespace Win_ADO_Customers
{
    partial class frm_SearchCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_searchcustomer = new System.Windows.Forms.Label();
            this.lbl_searchkey = new System.Windows.Forms.Label();
            this.txt_searchkey = new System.Windows.Forms.TextBox();
            this.btn_searchkey = new System.Windows.Forms.Button();
            this.gdv_search = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.gdv_search)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_searchcustomer
            // 
            this.lbl_searchcustomer.AutoSize = true;
            this.lbl_searchcustomer.Location = new System.Drawing.Point(255, 13);
            this.lbl_searchcustomer.Name = "lbl_searchcustomer";
            this.lbl_searchcustomer.Size = new System.Drawing.Size(172, 20);
            this.lbl_searchcustomer.TabIndex = 0;
            this.lbl_searchcustomer.Text = "SEARCH CUSTOMER";
            // 
            // lbl_searchkey
            // 
            this.lbl_searchkey.AutoSize = true;
            this.lbl_searchkey.Location = new System.Drawing.Point(113, 99);
            this.lbl_searchkey.Name = "lbl_searchkey";
            this.lbl_searchkey.Size = new System.Drawing.Size(163, 20);
            this.lbl_searchkey.TabIndex = 1;
            this.lbl_searchkey.Text = "Enter Key To Search :";
            // 
            // txt_searchkey
            // 
            this.txt_searchkey.Location = new System.Drawing.Point(316, 99);
            this.txt_searchkey.Name = "txt_searchkey";
            this.txt_searchkey.Size = new System.Drawing.Size(186, 26);
            this.txt_searchkey.TabIndex = 2;
            // 
            // btn_searchkey
            // 
            this.btn_searchkey.Location = new System.Drawing.Point(564, 99);
            this.btn_searchkey.Name = "btn_searchkey";
            this.btn_searchkey.Size = new System.Drawing.Size(75, 33);
            this.btn_searchkey.TabIndex = 3;
            this.btn_searchkey.Text = "Search";
            this.btn_searchkey.UseVisualStyleBackColor = true;
            this.btn_searchkey.Click += new System.EventHandler(this.btn_searchkey_Click);
            // 
            // gdv_search
            // 
            this.gdv_search.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gdv_search.Location = new System.Drawing.Point(126, 190);
            this.gdv_search.Name = "gdv_search";
            this.gdv_search.RowTemplate.Height = 28;
            this.gdv_search.Size = new System.Drawing.Size(513, 345);
            this.gdv_search.TabIndex = 4;
            // 
            // frm_SearchCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 598);
            this.Controls.Add(this.gdv_search);
            this.Controls.Add(this.btn_searchkey);
            this.Controls.Add(this.txt_searchkey);
            this.Controls.Add(this.lbl_searchkey);
            this.Controls.Add(this.lbl_searchcustomer);
            this.Name = "frm_SearchCustomer";
            this.Text = "frm_SearchCustomer";
            ((System.ComponentModel.ISupportInitialize)(this.gdv_search)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_searchcustomer;
        private System.Windows.Forms.Label lbl_searchkey;
        private System.Windows.Forms.TextBox txt_searchkey;
        private System.Windows.Forms.Button btn_searchkey;
        private System.Windows.Forms.DataGridView gdv_search;
    }
}