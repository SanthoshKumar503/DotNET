﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ADO_Customers
{
    public partial class frm_HomeCustomer : Form
    {
        public frm_HomeCustomer()
        {
            InitializeComponent();
        }

        private void btn_homesearch_Click(object sender, EventArgs e)
        {
            frm_SearchCustomer obj = new frm_SearchCustomer();
            obj.Show();
        }

        private void btn_homefind_Click(object sender, EventArgs e)
        {
            frm_FindCustomer obj = new frm_FindCustomer();
            obj.Show();
        }

        private void frm_HomeCustomer_Load(object sender, EventArgs e)
        {
            lbl_homeid.Text += frm_LoginCustomer.CstID;
            CustomerDAL dal = new CustomerDAL();
            string name=dal.GetName(frm_LoginCustomer.CstID);
            lbl_homename.Text += name;
        }
    }
}
