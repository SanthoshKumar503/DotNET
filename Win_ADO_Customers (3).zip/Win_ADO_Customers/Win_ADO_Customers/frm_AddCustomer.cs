﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ADO_Customers
{
    public partial class frm_AddCustomer : Form
    {
        public frm_AddCustomer()
        {
            InitializeComponent();
        }

        private void lbl_addcity_Click(object sender, EventArgs e)
        {

        }

        private void btn_addcustomer_Click(object sender, EventArgs e)
        {
            string name = txt_addname.Text;
            string pass = txt_addpassword.Text;
            string city = txt_addcity.Text;
            string mob = txt_addmobileno.Text;
            string email = txt_addemailid.Text;
            if(name==string.Empty)
            {
                lbl_addstatus.Text += "Enter name";
            }
            else if(pass==string.Empty)
            {
                lbl_addstatus.Text += "Enter password";
            }
            else if(city==string.Empty)
            {
                lbl_addstatus.Text += "Enter city";
            }
            else if(mob==string.Empty)
            {
                lbl_addstatus.Text += "Enter mobile number";
            }
            else if(email==string.Empty)
            {
                lbl_addstatus.Text += "Enter email";
            }
            else
            {
                Customers c = new Customers();
                c.CustomerName = name;
                c.CustomerPassword = pass;
                c.CustomerCity = city;
                c.CustomerMobileNo = mob;
                c.CustomerEmailID = email;
                CustomerDAL dal = new CustomerDAL();
                int id=dal.AddCustomer(c);
                lbl_addstatus.Text = "Record inserted and ID :" + id;
            }
        }
    }
}
