﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ADO_Customers
{
    public partial class frm_SearchCustomer : Form
    {
        public frm_SearchCustomer()
        {
            InitializeComponent();
        }

        private void btn_searchkey_Click(object sender, EventArgs e)
        {
            string key = txt_searchkey.Text;
            if(key==string.Empty)
            {
                MessageBox.Show("Enter Key");
            }
            else
            {
                CustomerDAL dal = new CustomerDAL();
                List<Customers> list = dal.SearchCustomers(key);
                gdv_search.DataSource = list;
            }
        }
    }
}
