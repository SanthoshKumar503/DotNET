﻿namespace Win_ADO_Customers
{
    partial class frm_FindCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_find = new System.Windows.Forms.Label();
            this.lbl_findcustno = new System.Windows.Forms.Label();
            this.lbl_findname = new System.Windows.Forms.Label();
            this.lbl_findcity = new System.Windows.Forms.Label();
            this.lbl_findpassword = new System.Windows.Forms.Label();
            this.lbl_findmobileno = new System.Windows.Forms.Label();
            this.lbl_findemail = new System.Windows.Forms.Label();
            this.txt_findname = new System.Windows.Forms.TextBox();
            this.txt_findpassword = new System.Windows.Forms.TextBox();
            this.txt_findcity = new System.Windows.Forms.TextBox();
            this.txt_findmobile = new System.Windows.Forms.TextBox();
            this.txt_findemail = new System.Windows.Forms.TextBox();
            this.cmb_findcustomer = new System.Windows.Forms.ComboBox();
            this.btn_findcustomer = new System.Windows.Forms.Button();
            this.btn_findupdate = new System.Windows.Forms.Button();
            this.btn_finddelete = new System.Windows.Forms.Button();
            this.lbl_findstatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_find
            // 
            this.lbl_find.AutoSize = true;
            this.lbl_find.Location = new System.Drawing.Point(342, 32);
            this.lbl_find.Name = "lbl_find";
            this.lbl_find.Size = new System.Drawing.Size(142, 20);
            this.lbl_find.TabIndex = 0;
            this.lbl_find.Text = "FIND CUSTOMER";
            // 
            // lbl_findcustno
            // 
            this.lbl_findcustno.AutoSize = true;
            this.lbl_findcustno.Location = new System.Drawing.Point(116, 98);
            this.lbl_findcustno.Name = "lbl_findcustno";
            this.lbl_findcustno.Size = new System.Drawing.Size(150, 20);
            this.lbl_findcustno.TabIndex = 1;
            this.lbl_findcustno.Text = "Enter Customer ID :";
            // 
            // lbl_findname
            // 
            this.lbl_findname.AutoSize = true;
            this.lbl_findname.Location = new System.Drawing.Point(120, 147);
            this.lbl_findname.Name = "lbl_findname";
            this.lbl_findname.Size = new System.Drawing.Size(132, 20);
            this.lbl_findname.TabIndex = 2;
            this.lbl_findname.Text = "Customer Name :";
            // 
            // lbl_findcity
            // 
            this.lbl_findcity.AutoSize = true;
            this.lbl_findcity.Location = new System.Drawing.Point(136, 256);
            this.lbl_findcity.Name = "lbl_findcity";
            this.lbl_findcity.Size = new System.Drawing.Size(116, 20);
            this.lbl_findcity.TabIndex = 3;
            this.lbl_findcity.Text = "Customer City :";
            // 
            // lbl_findpassword
            // 
            this.lbl_findpassword.AutoSize = true;
            this.lbl_findpassword.Location = new System.Drawing.Point(120, 196);
            this.lbl_findpassword.Name = "lbl_findpassword";
            this.lbl_findpassword.Size = new System.Drawing.Size(159, 20);
            this.lbl_findpassword.TabIndex = 4;
            this.lbl_findpassword.Text = "Customer Password :";
            // 
            // lbl_findmobileno
            // 
            this.lbl_findmobileno.AutoSize = true;
            this.lbl_findmobileno.Location = new System.Drawing.Point(124, 311);
            this.lbl_findmobileno.Name = "lbl_findmobileno";
            this.lbl_findmobileno.Size = new System.Drawing.Size(160, 20);
            this.lbl_findmobileno.TabIndex = 5;
            this.lbl_findmobileno.Text = "Customer Mobile No :";
            // 
            // lbl_findemail
            // 
            this.lbl_findemail.AutoSize = true;
            this.lbl_findemail.Location = new System.Drawing.Point(120, 372);
            this.lbl_findemail.Name = "lbl_findemail";
            this.lbl_findemail.Size = new System.Drawing.Size(129, 20);
            this.lbl_findemail.TabIndex = 6;
            this.lbl_findemail.Text = "Customer Email :";
            // 
            // txt_findname
            // 
            this.txt_findname.Location = new System.Drawing.Point(303, 147);
            this.txt_findname.Name = "txt_findname";
            this.txt_findname.Size = new System.Drawing.Size(213, 26);
            this.txt_findname.TabIndex = 8;
            // 
            // txt_findpassword
            // 
            this.txt_findpassword.Location = new System.Drawing.Point(303, 196);
            this.txt_findpassword.Name = "txt_findpassword";
            this.txt_findpassword.Size = new System.Drawing.Size(213, 26);
            this.txt_findpassword.TabIndex = 9;
            // 
            // txt_findcity
            // 
            this.txt_findcity.Location = new System.Drawing.Point(303, 256);
            this.txt_findcity.Name = "txt_findcity";
            this.txt_findcity.Size = new System.Drawing.Size(213, 26);
            this.txt_findcity.TabIndex = 10;
            // 
            // txt_findmobile
            // 
            this.txt_findmobile.Location = new System.Drawing.Point(303, 311);
            this.txt_findmobile.Name = "txt_findmobile";
            this.txt_findmobile.Size = new System.Drawing.Size(213, 26);
            this.txt_findmobile.TabIndex = 11;
            // 
            // txt_findemail
            // 
            this.txt_findemail.Location = new System.Drawing.Point(303, 372);
            this.txt_findemail.Name = "txt_findemail";
            this.txt_findemail.Size = new System.Drawing.Size(213, 26);
            this.txt_findemail.TabIndex = 12;
            // 
            // cmb_findcustomer
            // 
            this.cmb_findcustomer.FormattingEnabled = true;
            this.cmb_findcustomer.Location = new System.Drawing.Point(303, 89);
            this.cmb_findcustomer.Name = "cmb_findcustomer";
            this.cmb_findcustomer.Size = new System.Drawing.Size(213, 28);
            this.cmb_findcustomer.TabIndex = 13;
            // 
            // btn_findcustomer
            // 
            this.btn_findcustomer.Location = new System.Drawing.Point(595, 77);
            this.btn_findcustomer.Name = "btn_findcustomer";
            this.btn_findcustomer.Size = new System.Drawing.Size(96, 40);
            this.btn_findcustomer.TabIndex = 14;
            this.btn_findcustomer.Text = "Find";
            this.btn_findcustomer.UseVisualStyleBackColor = true;
            this.btn_findcustomer.Click += new System.EventHandler(this.btn_findcustomer_Click);
            // 
            // btn_findupdate
            // 
            this.btn_findupdate.Location = new System.Drawing.Point(595, 162);
            this.btn_findupdate.Name = "btn_findupdate";
            this.btn_findupdate.Size = new System.Drawing.Size(96, 38);
            this.btn_findupdate.TabIndex = 15;
            this.btn_findupdate.Text = "Update";
            this.btn_findupdate.UseVisualStyleBackColor = true;
            this.btn_findupdate.Click += new System.EventHandler(this.btn_findupdate_Click);
            // 
            // btn_finddelete
            // 
            this.btn_finddelete.Location = new System.Drawing.Point(595, 256);
            this.btn_finddelete.Name = "btn_finddelete";
            this.btn_finddelete.Size = new System.Drawing.Size(96, 40);
            this.btn_finddelete.TabIndex = 16;
            this.btn_finddelete.Text = "Delete";
            this.btn_finddelete.UseVisualStyleBackColor = true;
            this.btn_finddelete.Click += new System.EventHandler(this.btn_finddelete_Click);
            // 
            // lbl_findstatus
            // 
            this.lbl_findstatus.AutoSize = true;
            this.lbl_findstatus.Location = new System.Drawing.Point(362, 482);
            this.lbl_findstatus.Name = "lbl_findstatus";
            this.lbl_findstatus.Size = new System.Drawing.Size(64, 20);
            this.lbl_findstatus.TabIndex = 17;
            this.lbl_findstatus.Text = "Status :";
            // 
            // frm_FindCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(825, 595);
            this.Controls.Add(this.lbl_findstatus);
            this.Controls.Add(this.btn_finddelete);
            this.Controls.Add(this.btn_findupdate);
            this.Controls.Add(this.btn_findcustomer);
            this.Controls.Add(this.cmb_findcustomer);
            this.Controls.Add(this.txt_findemail);
            this.Controls.Add(this.txt_findmobile);
            this.Controls.Add(this.txt_findcity);
            this.Controls.Add(this.txt_findpassword);
            this.Controls.Add(this.txt_findname);
            this.Controls.Add(this.lbl_findemail);
            this.Controls.Add(this.lbl_findmobileno);
            this.Controls.Add(this.lbl_findpassword);
            this.Controls.Add(this.lbl_findcity);
            this.Controls.Add(this.lbl_findname);
            this.Controls.Add(this.lbl_findcustno);
            this.Controls.Add(this.lbl_find);
            this.Name = "frm_FindCustomer";
            this.Text = "frm_FindCustomer";
            this.Load += new System.EventHandler(this.frm_FindCustomer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_find;
        private System.Windows.Forms.Label lbl_findcustno;
        private System.Windows.Forms.Label lbl_findname;
        private System.Windows.Forms.Label lbl_findcity;
        private System.Windows.Forms.Label lbl_findpassword;
        private System.Windows.Forms.Label lbl_findmobileno;
        private System.Windows.Forms.Label lbl_findemail;
        private System.Windows.Forms.TextBox txt_findname;
        private System.Windows.Forms.TextBox txt_findpassword;
        private System.Windows.Forms.TextBox txt_findcity;
        private System.Windows.Forms.TextBox txt_findmobile;
        private System.Windows.Forms.TextBox txt_findemail;
        private System.Windows.Forms.ComboBox cmb_findcustomer;
        private System.Windows.Forms.Button btn_findcustomer;
        private System.Windows.Forms.Button btn_findupdate;
        private System.Windows.Forms.Button btn_finddelete;
        private System.Windows.Forms.Label lbl_findstatus;
    }
}