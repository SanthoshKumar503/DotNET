﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_ADO_Customers
{
    public partial class frm_LoginCustomer : Form
    {
        public static int CstID;
        public frm_LoginCustomer()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            string cid = txt_loginid.Text;
            string pass = txt_loginpassword.Text;
            if(cid==string.Empty)
            {
                lbl_loginstatus.Text = "Enter login ID";
            }
            else if(pass==string.Empty)
            {
                lbl_loginstatus.Text = "Enter password";
            }
            else
            {
                int id = Convert.ToInt32(cid);
                CustomerDAL dal = new CustomerDAL();
                bool status=dal.LoginCustomer(id, pass);
                if(status==true)
                {
                    frm_LoginCustomer.CstID = id;
                    MessageBox.Show("Valid user");
                    frm_HomeCustomer obj = new frm_HomeCustomer();
                    obj.Show();
                }
                else
                {
                    lbl_loginstatus.Text += "Invalid User";
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frm_AddCustomer obj = new frm_AddCustomer();
            obj.Show();
        }
    }
}
