﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Win_ADO_Customers
{
    class CustomerDAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["concust"].ConnectionString);   
        public int AddCustomer(Customers c)
        {
            SqlCommand com_add = new SqlCommand("p_addcustomer", con);
            com_add.CommandType = CommandType.StoredProcedure;
            com_add.Parameters.AddWithValue("@name", c.CustomerName);
            com_add.Parameters.AddWithValue("@psw", c.CustomerPassword);
            com_add.Parameters.AddWithValue("@city", c.CustomerCity);
            com_add.Parameters.AddWithValue("@mobileno", c.CustomerMobileNo);
            com_add.Parameters.AddWithValue("@email", c.CustomerEmailID);
            SqlParameter id = new SqlParameter();
            id.Direction = ParameterDirection.ReturnValue;
            com_add.Parameters.Add(id);
            con.Open();
            com_add.ExecuteNonQuery();
            con.Close();
            int rid = Convert.ToInt32(id.Value);
            return rid;
        }
        public Customers FindCustomer(int id)
        {
            SqlCommand com_find = new SqlCommand("p_findcustomer", con);
            com_find.CommandType = CommandType.StoredProcedure;
            com_find.Parameters.AddWithValue("@id", id);
            con.Open();
            SqlDataReader dr = com_find.ExecuteReader();
            if(dr.Read())
            {
                Customers c = new Customers();
                c.CustomerID = dr.GetInt32(0);
                c.CustomerName = dr.GetString(1);
                c.CustomerPassword = dr.GetString(2);
                c.CustomerCity = dr.GetString(3);
                c.CustomerMobileNo = dr.GetString(4);
                c.CustomerEmailID = dr.GetString(5);
                con.Close();
                return c;
            }
            else
            {
                con.Close();
                return null;
            }
        }
        public List<Customers> SearchCustomers(string key)
        {
            SqlCommand com_srh = new SqlCommand("p_searchcustomer", con);
            com_srh.CommandType = CommandType.StoredProcedure;
            com_srh.Parameters.AddWithValue("@key", key);
            con.Open();
            SqlDataReader dr = com_srh.ExecuteReader();
            List<Customers> list = new List<Customers>();
            while(dr.Read())
            {
                Customers c = new Customers();
                c.CustomerID = dr.GetInt32(0);
                c.CustomerName = dr.GetString(1);
                c.CustomerPassword = dr.GetString(2);
                c.CustomerCity = dr.GetString(3);
                c.CustomerMobileNo = dr.GetString(4);
                c.CustomerEmailID = dr.GetString(5);
                list.Add(c);
            }
            con.Close();
            return list;
        }
        public bool UpdateCustomer(int id,string name,string psw,string city,string mob,string email)
        {
            SqlCommand com_updt = new SqlCommand("p_updatecustomer", con);
            com_updt.CommandType = CommandType.StoredProcedure;
            com_updt.Parameters.AddWithValue("@id", id);
            com_updt.Parameters.AddWithValue("@name", name);
            com_updt.Parameters.AddWithValue("@psw", psw);
            com_updt.Parameters.AddWithValue("@city", city);
            com_updt.Parameters.AddWithValue("@mobileno", mob);
            com_updt.Parameters.AddWithValue("@email", email);
            SqlParameter p_count = new SqlParameter();
            p_count.Direction = ParameterDirection.ReturnValue;
            com_updt.Parameters.Add(p_count);
            con.Open();
            com_updt.ExecuteNonQuery();
            int count = Convert.ToInt32(p_count.Value);
            if(count==1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool DeleteCustomer(int id)
        {
            SqlCommand com_del = new SqlCommand("p_deletecustomer", con);
            com_del.CommandType = CommandType.StoredProcedure;
            com_del.Parameters.AddWithValue("@id", id);
            SqlParameter p_row = new SqlParameter();
            p_row.Direction = ParameterDirection.ReturnValue;
            com_del.Parameters.Add(p_row);
            con.Open();
            com_del.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(p_row.Value);
            if(count==1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool LoginCustomer(int id,string psw)
        {
            SqlCommand com_login = new SqlCommand("p_logincustomer", con);
            com_login.CommandType = CommandType.StoredProcedure;
            com_login.Parameters.AddWithValue("@id", id);
            com_login.Parameters.AddWithValue("@psw", psw);
            SqlParameter p_count = new SqlParameter();
            p_count.Direction = ParameterDirection.ReturnValue;
            com_login.Parameters.Add(p_count);
            con.Open();
            com_login.ExecuteNonQuery();
            con.Close();
            int count = Convert.ToInt32(p_count.Value);
            if (count == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public string GetName(int id)
        {
            SqlCommand com_getname = new SqlCommand("p_getname", con);
            com_getname.CommandType = CommandType.StoredProcedure;
            com_getname.Parameters.AddWithValue("@id", id);
            con.Open();
            SqlDataReader dr = com_getname.ExecuteReader();
            if (dr.Read())
            {
                string name = dr.GetString(0);
                con.Close();
                return name;
            }
            else
            {
                con.Close();
                return string.Empty;
            }
        }
        public List<int> GetEmployeesIDs()
        {
            SqlCommand com_ids = new SqlCommand("p_getcustomersids", con);
            com_ids.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_ids.ExecuteReader();
            List<int> ids = new List<int>();
            while (dr.Read())
            {
                int id = dr.GetInt32(0);
                ids.Add(id);
            }
            con.Close();
            return ids;
        }
    }
}
















