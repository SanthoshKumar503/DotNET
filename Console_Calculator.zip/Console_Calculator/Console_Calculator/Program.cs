﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the first number");
            int n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the second number");
            int n2 = Convert.ToInt32(Console.ReadLine());

            Calculator.Arithmetic a = new Calculator.Arithmetic();
            int res=a.GetSum(n1, n2);
            Console.WriteLine("Sum of two numbers is:" + res);
            res = a.GetSubtract(n1, n2);
            Console.WriteLine("Subtraction of two numbers is:" + res);
            res = a.GetMultiply(n1, n2);
            Console.WriteLine("Multiplication of two numbers is:" + res);
            res = a.GetDivision(n1, n2);
            Console.WriteLine("Division of two numbers is:" + res);

            Console.ReadLine();
        }
    }
}
