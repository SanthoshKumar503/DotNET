﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Bank_System
{
        class Program
        {
            static void Main(string[] args)
            {
                int amt;
                Boolean b = true;
                Console.WriteLine("\tCreate Account");
                Console.WriteLine("Enter your Account ID:");
                int id=Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Create Your Password:");
                string password = Console.ReadLine();
                Console.WriteLine("Enter your Name:");
                string name =Console.ReadLine();
                Console.WriteLine("Enter your Address:");
                string addr = Console.ReadLine();
                Console.WriteLine("Enter Type of Account:");
                string type = Console.ReadLine();
                Console.WriteLine("Enter Initial Account balance:");
                amt = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine();
                Console.WriteLine("\tFind Your Account");
                Console.WriteLine("Enter your account Number");
                int acc=Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("Enter your Password:");
                string pass = Console.ReadLine();
            if (acc == id && password==pass)
                {
                    do
                    {
                        Console.WriteLine("\t\t1:Deposit 2:Withdraw 3:Check balance 4:Exit");
                        Console.WriteLine();
                        Console.WriteLine("Enter the your choice:");
                        int n = Convert.ToInt32(Console.ReadLine());
                        switch (n)
                        {
                            case 1:
                                {
                                    Console.WriteLine("Enter the amount to deposit:");
                                    int r = Convert.ToInt32(Console.ReadLine());
                                    if (r >= 500)
                                    {
                                        amt = amt + r;
                                    Console.WriteLine("Amount Deposited");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Amount should be above 500");
                                    }
                                    break;
                                }
                            case 2:
                                {
                                    Console.WriteLine("Enter the amount to withdraw:");
                                    int r = Convert.ToInt32(Console.ReadLine());
                                    if (r >= 500)
                                    {
                                        amt = amt - r;
                                    Console.WriteLine("Amount withdrawn");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Withdraw should be above 500");
                                    }
                                    break;
                                }
                            case 3:
                                {
                                    Console.WriteLine("Account ID:" + id);
                                    Console.WriteLine("Account Name:" + name);
                                    Console.WriteLine("Account Address:" + addr);
                                    Console.WriteLine("Account Type:" + type);
                                    Console.WriteLine("Account Balance:" + amt);
                                    break;
                                }
                            case 4:
                                {
                                    b=false;
                                    break;
                                }
                            default:
                                {
                                    Console.WriteLine("Invalid choice");
                                    break;
                                }
                        }
                        Console.WriteLine();
                        
                    } while (b);
                }
                else
                {
                    Console.WriteLine("Invalid account");
                }

                Console.ReadLine();
            }
        }
    }

