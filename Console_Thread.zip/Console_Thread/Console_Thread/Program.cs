﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Threading;

namespace Console_Thread
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            int id = Thread.CurrentThread.ManagedThreadId;
            Console.WriteLine("Main thread work and ID:"+id);
            Test t = new Test();

            Thread th1 = new Thread(t.MyTask1);
            th1.Start();

            Thread th2 = new Thread(t.MyTask2);
            th2.Start();
            //t.MyTask1();
            //t.MyTask2();

            th1.Join();

            Console.WriteLine("Main thread completed");
            */

            // task 
            Task t = Task.Run(() =>{
                Console.WriteLine("Task1 started");
                Thread.Sleep(2000);
                Console.WriteLine("Task1 completed");
            });

            Console.WriteLine("Main thread work");

            Console.ReadLine();
        }
    }
}
