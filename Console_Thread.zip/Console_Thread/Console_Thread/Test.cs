﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Threading;//for thread

namespace Console_Thread
{
    class Test
    {
        public void MyTask1()
        {
            int id=Thread.CurrentThread.ManagedThreadId;
            Console.WriteLine("MyTask1 started..."+id);
            Thread.Sleep(2000);
            Console.WriteLine("MyTask1 complete...");
        }
        public void MyTask2()
        {
            int id = Thread.CurrentThread.ManagedThreadId;
            Console.WriteLine("MyTask2 started..."+id);
            Thread.Sleep(2000);
            Console.WriteLine("MyTask2 completed...");
        }
    }
}
