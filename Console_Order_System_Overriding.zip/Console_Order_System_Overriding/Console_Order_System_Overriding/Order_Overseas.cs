﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Order_System_Overriding
{
    class Order_Overseas : Order
    {
        public Order_Overseas(string CustomerName, int ItemQuantity, int ItemPrice)
            :base(CustomerName,ItemQuantity,ItemPrice)
        {

        }
        public override double GetOrderValue()
        {
            int total = this.PItemQuantity * this.PItemPrice;
            double percent = (0.1 * total);
            return percent+total;
        }
    }
}
