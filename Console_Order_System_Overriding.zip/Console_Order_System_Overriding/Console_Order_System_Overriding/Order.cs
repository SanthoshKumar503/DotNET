﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Order_System_Overriding
{
    class Order
    {
        private int OrderId;
        private string CustomerName;
        private int ItemQuantity;
        private int ItemPrice;
        private static int count = 10000;
        public Order(string CustomerName,int ItemQuantity,int ItemPrice)
        {
            this.CustomerName = CustomerName;
            this.ItemQuantity = ItemQuantity;
            this.ItemPrice = ItemPrice;
            this.OrderId = ++Order.count;
        }
        public int POrderId
        {
            get
            {
                return this.OrderId;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public int PItemQuantity
        {
            get
            {
                return this.ItemQuantity;
            }
        }
        public int PItemPrice
        {
            get
            {
                return this.ItemPrice;
            }
        }
        public virtual double GetOrderValue()
        {
            return this.ItemPrice * this.ItemQuantity;
        }
    }
}
