﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Order_System_Overriding
{
    class Program
    {
        static void Main(string[] args)
        {
            string c;
            do
            {
                Console.WriteLine("Enter the Customer Name");
                string name = Console.ReadLine();
                Console.WriteLine("Enter the Item quantity");
                int quantity = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the Itge price");
                int price = Convert.ToInt32(Console.ReadLine());

                Order o = null;
                Console.WriteLine("Enter the Customer Type");
                string customer = Console.ReadLine();
                if (customer == "Local")
                {
                    o = new Order(name, quantity, price);
                }
                else if (customer == "Oversease")
                {
                    o = new Order_Overseas(name, quantity, price);
                }

                if (o != null)
                {
                    Console.WriteLine("--------------------");
                    Console.WriteLine("Order ID:" + o.POrderId);
                    Console.WriteLine("Customer Name:" + o.PCustomerName);
                    Console.WriteLine("Item Quantity:" + o.PItemQuantity);
                    Console.WriteLine("Item Price:" + o.PItemPrice);
                    double total = o.GetOrderValue();
                    Console.WriteLine("Total Value:" + total);
                    Console.WriteLine("--------------------");
                }
                else
                {
                    Console.WriteLine("Invalid Customer");
                }
                Console.WriteLine("y for Continue");
                c = Console.ReadLine();
            } while (c == "y");
            Console.ReadLine();
        }
    }
}

