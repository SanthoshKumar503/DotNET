﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

using System.Xml.Serialization;

namespace Win_IU_Serialization
{
    public partial class frm_Serialization : Form
    {
        public frm_Serialization()
        {
            InitializeComponent();
        }

        private void btn_serialize_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/test/prod.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter binary = new BinaryFormatter();

            Product p = new Product();
            p.ProductID = 1001;
            p.ProductName = "Mobile";
            p.ProductPrice = 20000;

            binary.Serialize(fs, p);
            fs.Close();
            MessageBox.Show("Product object has been serialized");
        }

        private void btn_deserialization_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/test/prod.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryFormatter binary = new BinaryFormatter();
            Product p = binary.Deserialize(fs) as Product;
            fs.Close();
            MessageBox.Show(p.ProductID + " " + p.ProductName + " " + p.ProductPrice);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/test/myproduct.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            Product p = new Product();
            p.ProductID = 1001;
            p.ProductName = "Mobile";
            p.ProductPrice = 20000;

            XmlSerializer xml = new XmlSerializer(typeof(Product));
            xml.Serialize(fs, p);
            fs.Close();
            MessageBox.Show("Produc object has serialized as XML");
        }

        private void btn_xmldeserialization_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/test/myproduct.xml", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            XmlSerializer xml = new XmlSerializer(typeof(Product));
            Product p = xml.Deserialize(fs) as Product;
            fs.Close();
            MessageBox.Show(p.ProductID + " " + p.ProductName + " " + p.ProductPrice);

        }
    }
}
