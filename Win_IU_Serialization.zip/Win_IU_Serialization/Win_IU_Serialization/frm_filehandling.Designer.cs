﻿namespace Win_IU_Serialization
{
    partial class frm_filehandling
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_writebinary = new System.Windows.Forms.Button();
            this.btn_readbinary = new System.Windows.Forms.Button();
            this.btn_streamwriter = new System.Windows.Forms.Button();
            this.btn_streamreader = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_writebinary
            // 
            this.btn_writebinary.Location = new System.Drawing.Point(105, 87);
            this.btn_writebinary.Name = "btn_writebinary";
            this.btn_writebinary.Size = new System.Drawing.Size(127, 52);
            this.btn_writebinary.TabIndex = 0;
            this.btn_writebinary.Text = "Write Binary";
            this.btn_writebinary.UseVisualStyleBackColor = true;
            this.btn_writebinary.Click += new System.EventHandler(this.btn_writebinary_Click);
            // 
            // btn_readbinary
            // 
            this.btn_readbinary.Location = new System.Drawing.Point(105, 188);
            this.btn_readbinary.Name = "btn_readbinary";
            this.btn_readbinary.Size = new System.Drawing.Size(127, 51);
            this.btn_readbinary.TabIndex = 1;
            this.btn_readbinary.Text = "Read Binary";
            this.btn_readbinary.UseVisualStyleBackColor = true;
            this.btn_readbinary.Click += new System.EventHandler(this.btn_readbinary_Click);
            // 
            // btn_streamwriter
            // 
            this.btn_streamwriter.Location = new System.Drawing.Point(379, 87);
            this.btn_streamwriter.Name = "btn_streamwriter";
            this.btn_streamwriter.Size = new System.Drawing.Size(141, 52);
            this.btn_streamwriter.TabIndex = 2;
            this.btn_streamwriter.Text = "Stream Writer";
            this.btn_streamwriter.UseVisualStyleBackColor = true;
            this.btn_streamwriter.Click += new System.EventHandler(this.btn_streamwriter_Click);
            // 
            // btn_streamreader
            // 
            this.btn_streamreader.Location = new System.Drawing.Point(379, 202);
            this.btn_streamreader.Name = "btn_streamreader";
            this.btn_streamreader.Size = new System.Drawing.Size(135, 51);
            this.btn_streamreader.TabIndex = 3;
            this.btn_streamreader.Text = "Stream Reader";
            this.btn_streamreader.UseVisualStyleBackColor = true;
            this.btn_streamreader.Click += new System.EventHandler(this.btn_streamreader_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(582, 551);
            this.Controls.Add(this.btn_streamreader);
            this.Controls.Add(this.btn_streamwriter);
            this.Controls.Add(this.btn_readbinary);
            this.Controls.Add(this.btn_writebinary);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_writebinary;
        private System.Windows.Forms.Button btn_readbinary;
        private System.Windows.Forms.Button btn_streamwriter;
        private System.Windows.Forms.Button btn_streamreader;
    }
}

