﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Win_IU_Serialization
{
    public partial class frm_filehandling : Form
    {
        public frm_filehandling()
        {
            InitializeComponent();
        }

        private void btn_writebinary_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/test/abc.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryWriter bw = new BinaryWriter(fs);
            int x = 100;
            bw.Write(x);
            bw.Flush();
            fs.Close();
            MessageBox.Show("File created and written");
        }

        private void btn_readbinary_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/test/abc.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            BinaryReader br = new BinaryReader(fs);
            int a = br.ReadInt32();
            fs.Close();
            MessageBox.Show("Value :" + a);
        }

        private void btn_streamwriter_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/test/xyz.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamWriter sw = new StreamWriter(fs);
            string str = "Hello Pathfront";
            sw.WriteLine(str);
            sw.Flush();
            fs.Close();
            MessageBox.Show("Stream file created and written");
        }

        private void btn_streamreader_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("c:/test/xyz.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamReader sr = new StreamReader(fs);
            string str = sr.ReadToEnd();
            fs.Close();
            MessageBox.Show("String :" + str);
        }
    }
}
