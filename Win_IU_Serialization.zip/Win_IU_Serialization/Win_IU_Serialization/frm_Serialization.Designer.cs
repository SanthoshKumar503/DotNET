﻿namespace Win_IU_Serialization
{
    partial class frm_Serialization
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_serialize = new System.Windows.Forms.Button();
            this.btn_deserialization = new System.Windows.Forms.Button();
            this.btn_xmldeserialization = new System.Windows.Forms.Button();
            this.btn_xmlserialization = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_serialize
            // 
            this.btn_serialize.Location = new System.Drawing.Point(102, 86);
            this.btn_serialize.Name = "btn_serialize";
            this.btn_serialize.Size = new System.Drawing.Size(134, 38);
            this.btn_serialize.TabIndex = 0;
            this.btn_serialize.Text = "Serialization";
            this.btn_serialize.UseVisualStyleBackColor = true;
            this.btn_serialize.Click += new System.EventHandler(this.btn_serialize_Click);
            // 
            // btn_deserialization
            // 
            this.btn_deserialization.Location = new System.Drawing.Point(317, 86);
            this.btn_deserialization.Name = "btn_deserialization";
            this.btn_deserialization.Size = new System.Drawing.Size(149, 42);
            this.btn_deserialization.TabIndex = 1;
            this.btn_deserialization.Text = "Deseialization";
            this.btn_deserialization.UseVisualStyleBackColor = true;
            this.btn_deserialization.Click += new System.EventHandler(this.btn_deserialization_Click);
            // 
            // btn_xmldeserialization
            // 
            this.btn_xmldeserialization.Location = new System.Drawing.Point(331, 320);
            this.btn_xmldeserialization.Name = "btn_xmldeserialization";
            this.btn_xmldeserialization.Size = new System.Drawing.Size(178, 42);
            this.btn_xmldeserialization.TabIndex = 3;
            this.btn_xmldeserialization.Text = "XML Deseialization";
            this.btn_xmldeserialization.UseVisualStyleBackColor = true;
            this.btn_xmldeserialization.Click += new System.EventHandler(this.btn_xmldeserialization_Click);
            // 
            // btn_xmlserialization
            // 
            this.btn_xmlserialization.Location = new System.Drawing.Point(121, 324);
            this.btn_xmlserialization.Name = "btn_xmlserialization";
            this.btn_xmlserialization.Size = new System.Drawing.Size(176, 38);
            this.btn_xmlserialization.TabIndex = 2;
            this.btn_xmlserialization.Text = "XML Serialization";
            this.btn_xmlserialization.UseVisualStyleBackColor = true;
            this.btn_xmlserialization.Click += new System.EventHandler(this.button2_Click);
            // 
            // frm_Serialization
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(641, 554);
            this.Controls.Add(this.btn_xmldeserialization);
            this.Controls.Add(this.btn_xmlserialization);
            this.Controls.Add(this.btn_deserialization);
            this.Controls.Add(this.btn_serialize);
            this.Name = "frm_Serialization";
            this.Text = "frm_Serialization";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_serialize;
        private System.Windows.Forms.Button btn_deserialization;
        private System.Windows.Forms.Button btn_xmldeserialization;
        private System.Windows.Forms.Button btn_xmlserialization;
    }
}